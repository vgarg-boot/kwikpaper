<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KwikPaper - Buy & Sell Study Notes</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Hero Section */
        .hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 4rem 0 3rem;
            position: relative;
            overflow: hidden;
        }
        
        .hero::before {
            content: '';
            position: absolute;
            width: 600px;
            height: 600px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -300px;
            right: -200px;
            animation: float 6s ease-in-out infinite;
        }
        
        .hero::after {
            content: '';
            position: absolute;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            bottom: -200px;
            left: -100px;
            animation: float 8s ease-in-out infinite reverse;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px) translateX(0px); }
            50% { transform: translateY(-30px) translateX(30px); }
        }
        
        .hero .container {
            position: relative;
            z-index: 1;
        }
        
        .hero-wrapper {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 3rem;
            align-items: center;
            margin-bottom: 3rem;
        }
        
        .hero-content {
            text-align: left;
            color: white;
            animation: fadeInUp 0.8s ease-out;
        }
        
        .hero-image {
            position: relative;
            animation: fadeInRight 0.8s ease-out;
        }
        
        .hero-image-container {
            position: relative;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 30px;
            padding: 2rem;
            backdrop-filter: blur(10px);
            border: 2px solid rgba(255, 255, 255, 0.2);
        }
        
        .hero-image img {
            width: 100%;
            height: auto;
            border-radius: 20px;
            filter: drop-shadow(0 20px 40px rgba(0, 0, 0, 0.3));
        }
        
        .floating-badge {
            position: absolute;
            background: white;
            padding: 0.75rem 1.5rem;
            border-radius: 50px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            font-weight: 600;
            animation: floatBadge 3s ease-in-out infinite;
        }
        
        .badge-1 {
            top: 10%;
            left: -5%;
            color: #667eea;
        }
        
        .badge-2 {
            bottom: 15%;
            right: -5%;
            color: #764ba2;
        }
        
        @keyframes floatBadge {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
        }
        
        @keyframes fadeInRight {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .hero-content h2 {
            font-size: 3.5rem;
            margin-bottom: 1rem;
            font-weight: 700;
            line-height: 1.2;
        }
        
        .hero-content p {
            font-size: 1.4rem;
            margin-bottom: 2rem;
            opacity: 0.95;
        }
        
        .hero-buttons {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        .btn-primary, .btn-secondary {
            padding: 1rem 2.5rem;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            text-decoration: none;
            transition: all 0.3s;
            display: inline-block;
        }
        
        .btn-primary {
            background: white;
            color: #667eea;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
        }
        
        .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 12px 35px rgba(0, 0, 0, 0.3);
        }
        
        .btn-secondary {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 2px solid white;
            backdrop-filter: blur(10px);
        }
        
        .btn-secondary:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-3px);
        }
        
        .hero-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
        }
        
        .stat {
            background: rgba(255, 255, 255, 0.15);
            padding: 2rem;
            border-radius: 15px;
            text-align: center;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: white;
            transition: all 0.3s;
            animation: fadeInUp 0.8s ease-out;
        }
        
        .stat:nth-child(1) { animation-delay: 0.1s; }
        .stat:nth-child(2) { animation-delay: 0.2s; }
        .stat:nth-child(3) { animation-delay: 0.3s; }
        
        .stat:hover {
            transform: translateY(-5px);
            background: rgba(255, 255, 255, 0.25);
        }
        
        .stat h3 {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }
        
        .stat p {
            font-size: 1rem;
            opacity: 0.9;
        }
        
        /* Features Section */
        .features {
            padding: 5rem 0;
            background: #f8f9fa;
        }
        
        .features h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 3rem;
            color: #2c3e50;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
        }
        
        .feature-card {
            background: white;
            padding: 2.5rem 2rem;
            border-radius: 15px;
            text-align: center;
            transition: all 0.3s;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.2);
        }
        
        .feature-card .icon {
            font-size: 4rem;
            margin-bottom: 1.5rem;
        }
        
        .feature-card h3 {
            font-size: 1.5rem;
            margin-bottom: 1rem;
            color: #2c3e50;
        }
        
        .feature-card p {
            color: #6c757d;
            line-height: 1.6;
        }
        
        /* Featured Notes Section */
        .featured-notes {
            padding: 5rem 0;
            position: relative;
            overflow: hidden;
        }
        
        /* Popular Notes - Warm flowing gradient background */
        .popular-notes {
            background: linear-gradient(-45deg, #ffe4e1, #fff0f5, #f0f9ff, #f0fdf4);
            background-size: 400% 400%;
            animation: gradientFlow 25s ease infinite;
            position: relative;
        }
        
        .popular-notes::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: 
                radial-gradient(circle at 20% 50%, rgba(255, 240, 245, 0.5) 0%, transparent 30%),
                radial-gradient(circle at 80% 20%, rgba(255, 230, 230, 0.4) 0%, transparent 30%),
                radial-gradient(circle at 40% 80%, rgba(240, 253, 244, 0.4) 0%, transparent 30%);
            animation: float 30s ease-in-out infinite;
        }
        
        .popular-notes::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                linear-gradient(transparent 0%, rgba(255, 255, 255, 0.2) 50%, transparent 100%);
            animation: shimmer 12s linear infinite;
        }
        
        .popular-notes h2 {
            color: #2c3e50;
            text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.9);
        }
        
        /* Latest Notes - Cool flowing gradient background */
        .latest-notes {
            background: linear-gradient(-45deg, #ede9fe, #dbeafe, #e0f2fe, #ecfdf5);
            background-size: 400% 400%;
            animation: gradientFlow 28s ease infinite;
            position: relative;
        }
        
        .latest-notes::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: 
                radial-gradient(circle at 70% 30%, rgba(237, 233, 254, 0.5) 0%, transparent 30%),
                radial-gradient(circle at 30% 70%, rgba(219, 234, 254, 0.4) 0%, transparent 30%),
                radial-gradient(circle at 50% 50%, rgba(236, 253, 245, 0.4) 0%, transparent 30%);
            animation: float 35s ease-in-out infinite reverse;
        }
        
        .latest-notes::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                repeating-linear-gradient(
                    90deg,
                    transparent,
                    transparent 100px,
                    rgba(255, 255, 255, 0.08) 100px,
                    rgba(255, 255, 255, 0.08) 200px
                );
            animation: slide 20s linear infinite;
        }
        
        .latest-notes h2 {
            color: #2c3e50;
            text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.9);
        }
        
        .latest-notes .section-subtitle {
            color: #4b5563;
            text-shadow: 1px 1px 1px rgba(255, 255, 255, 0.7);
        }
        
        /* Flowing gradient animation */
        @keyframes gradientFlow {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        
        /* Floating particles animation */
        @keyframes float {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            25% { transform: translate(-20px, -20px) rotate(5deg); }
            50% { transform: translate(20px, 20px) rotate(-5deg); }
            75% { transform: translate(-10px, 10px) rotate(3deg); }
        }
        
        /* Shimmer effect */
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        /* Sliding background pattern */
        @keyframes slide {
            0% { transform: translateX(0); }
            100% { transform: translateX(200px); }
        }
        
        .featured-notes .container {
            position: relative;
            z-index: 1;
        }
        
        .featured-notes h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 2rem;
            color: #2c3e50;
        }
        
        /* Loading text styling for colored backgrounds */
        .popular-notes .notes-grid > p,
        .latest-notes .notes-grid > p {
            color: #4b5563;
            text-align: center;
            grid-column: 1 / -1;
            font-size: 1.1rem;
            padding: 2rem;
            font-weight: 500;
            text-shadow: 1px 1px 1px rgba(255, 255, 255, 0.7);
        }
        
        /* Enhanced shadows for cards on colored backgrounds */
        .popular-notes .note-card,
        .latest-notes .note-card {
            box-shadow: 0 3px 15px rgba(0, 0, 0, 0.08);
            backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.8);
        }
        
        .popular-notes .note-card:hover,
        .latest-notes .note-card:hover {
            box-shadow: 0 6px 25px rgba(0, 0, 0, 0.12);
            transform: translateY(-5px);
        }
        
        /* Image Banner Section */
        .image-banner {
            padding: 0;
            margin: 4rem 0;
            position: relative;
            overflow: hidden;
        }
        
        .banner-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            align-items: center;
            gap: 3rem;
            max-width: 1400px;
            margin: 0 auto;
            padding: 4rem 2rem;
        }
        
        .banner-content {
            padding: 2rem;
        }
        
        .banner-content h2 {
            font-size: 2.8rem;
            color: #2c3e50;
            margin-bottom: 1.5rem;
            line-height: 1.3;
        }
        
        .banner-content h2 .highlight {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-weight: 800;
        }
        
        .banner-content p {
            font-size: 1.2rem;
            color: #6c757d;
            margin-bottom: 1rem;
            line-height: 1.8;
        }
        
        .banner-content ul {
            list-style: none;
            padding: 0;
            margin: 2rem 0;
        }
        
        .banner-content ul li {
            padding: 0.75rem 0;
            font-size: 1.1rem;
            color: #495057;
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .banner-content ul li::before {
            content: "✅";
            font-size: 1.3rem;
        }
        
        .banner-image-wrapper {
            position: relative;
            border-radius: 30px;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
            transform: perspective(1000px) rotateY(-5deg);
            transition: all 0.4s ease;
            min-height: 450px;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .banner-image-wrapper:hover {
            transform: perspective(1000px) rotateY(0deg);
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.2);
        }
        
        .banner-image-wrapper img {
            width: 100%;
            height: 100%;
            min-height: 450px;
            display: block;
            object-fit: cover;
        }
        
        .banner-badge {
            position: absolute;
            background: white;
            padding: 1rem 1.5rem;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            font-weight: 600;
            animation: floatBadge 3s ease-in-out infinite;
        }
        
        .banner-badge-1 {
            top: 10%;
            left: -3%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .banner-badge-2 {
            bottom: 10%;
            right: -3%;
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: #065c3b;
        }
        
        @media (max-width: 1024px) {
            .banner-container {
                grid-template-columns: 1fr;
                text-align: center;
            }
            
            .banner-image-wrapper {
                transform: none;
            }
            
            .banner-content h2 {
                font-size: 2.2rem;
            }
        }
        
        .notes-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 0.8rem;
            margin-bottom: 2rem;
        }
        
        .note-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.3s;
            position: relative;
        }
        
        .note-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(102, 126, 234, 0.15);
        }
        
        .note-badge {
            position: absolute;
            top: 0.5rem;
            right: 0.5rem;
            padding: 0.2rem 0.5rem;
            border-radius: 12px;
            font-size: 0.6rem;
            font-weight: 600;
            z-index: 1;
        }
        
        .note-badge.popular {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }
        
        .note-badge.new {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            right: auto;
            left: 0.5rem;
        }
        
        .note-image {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1.5rem;
            text-align: center;
            font-size: 2rem;
        }
        
        .note-card h3 {
            padding: 0.8rem 0.8rem 0.3rem;
            font-size: 0.85rem;
            color: #2c3e50;
            min-height: 40px;
            line-height: 1.2;
        }
        
        .note-card p {
            padding: 0 0.8rem;
            color: #6c757d;
            font-size: 0.7rem;
            line-height: 1.4;
            min-height: 35px;
        }
        
        .note-meta {
            padding: 0.6rem 0.8rem;
            display: flex;
            justify-content: space-between;
            font-size: 0.65rem;
            color: #6c757d;
            border-top: 1px solid #e9ecef;
        }
        
        .note-meta .rating {
            color: #ffc107;
        }
        
        .note-footer {
            padding: 0.6rem 0.8rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8f9fa;
        }
        
        .note-footer .price {
            font-size: 0.95rem;
            font-weight: 700;
            color: #667eea;
        }
        
        .note-footer button {
            padding: 0.35rem 0.8rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.7rem;
            transition: all 0.3s;
        }
        
        .note-footer button:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        /* Top Earners Section */
        .top-earners {
            padding: 5rem 0;
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
        }
        
        .top-earners h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            color: #2c3e50;
        }
        
        .section-subtitle {
            text-align: center;
            color: #6c757d;
            margin-bottom: 3rem;
            font-size: 1.1rem;
        }
        
        .earners-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 2rem;
            margin-bottom: 3rem;
        }
        
        .earner-card {
            background: white;
            padding: 2rem 1.5rem;
            border-radius: 15px;
            text-align: center;
            transition: all 0.3s;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            position: relative;
            text-decoration: none;
            color: inherit;
            display: block;
        }
        
        .earner-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(102, 126, 234, 0.2);
        }
        
        .rank-badge {
            position: absolute;
            top: -15px;
            right: -15px;
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.2rem;
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .rank-1 .rank-badge {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        
        .rank-2 .rank-badge {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }
        
        .rank-3 .rank-badge {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        }
        
        .earner-avatar {
            font-size: 4rem;
            margin-bottom: 1rem;
        }
        
        .earner-card h3 {
            font-size: 1.3rem;
            margin-bottom: 0.5rem;
            color: #2c3e50;
        }
        
        .earner-subject {
            color: #6c757d;
            font-size: 0.9rem;
            margin-bottom: 1.5rem;
        }
        
        .earner-earnings {
            margin-bottom: 1rem;
        }
        
        .earnings-amount {
            display: block;
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .earnings-label {
            color: #6c757d;
            font-size: 0.85rem;
        }
        
        .earner-stats {
            color: #6c757d;
            font-size: 0.9rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #e9ecef;
        }
        
        .earner-cta {
            text-align: center;
            font-size: 1.2rem;
            color: #2c3e50;
            margin-bottom: 1.5rem;
        }
        
        /* Reviews Section */
        .reviews {
            padding: 5rem 0;
            background: white;
        }
        
        .reviews h2 {
            text-align: center;
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
            color: #2c3e50;
        }
        
        .reviews-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 2rem;
            margin-top: 3rem;
        }
        
        .review-card {
            background: #f8f9fa;
            padding: 2rem;
            border-radius: 15px;
            transition: all 0.3s;
            border: 2px solid transparent;
        }
        
        .review-card:hover {
            border-color: #667eea;
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.15);
        }
        
        .review-rating {
            color: #ffc107;
            font-size: 1.5rem;
            margin-bottom: 1rem;
        }
        
        .review-text {
            color: #2c3e50;
            line-height: 1.7;
            margin-bottom: 1.5rem;
            font-style: italic;
        }
        
        .review-author {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .author-avatar {
            font-size: 3rem;
        }
        
        .author-info h4 {
            color: #2c3e50;
            margin-bottom: 0.2rem;
        }
        
        .author-info p {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        /* CTA Section */
        .cta-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 5rem 0;
            text-align: center;
            color: white;
        }
        
        .cta-section h2 {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
        
        .cta-section p {
            font-size: 1.3rem;
            margin-bottom: 2rem;
            opacity: 0.95;
        }
        
        .btn-primary-large {
            display: inline-block;
            padding: 1.3rem 3rem;
            background: white;
            color: #667eea;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 700;
            font-size: 1.3rem;
            transition: all 0.3s;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }
        
        .btn-primary-large:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.3);
        }
        
        .text-center {
            text-align: center;
        }
        
        /* Button styling on colored backgrounds */
        .popular-notes .text-center .btn-primary,
        .latest-notes .text-center .btn-primary {
            background: rgba(255, 255, 255, 0.98);
            color: #667eea;
            font-weight: 700;
            font-size: 1.1rem;
            padding: 0.9rem 2.5rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            border: 2px solid rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
        }
        
        .popular-notes .text-center .btn-primary:hover,
        .latest-notes .text-center .btn-primary:hover {
            transform: translateY(-2px) scale(1.03);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
            background: white;
            border-color: white;
        }
        
        /* Responsive Design */
        @media (max-width: 1024px) {
            .notes-grid {
                grid-template-columns: repeat(4, 1fr);
            }
            
            .hero-wrapper {
                grid-template-columns: 1fr;
                gap: 2rem;
            }
            
            .hero-content {
                text-align: center;
            }
            
            .hero-buttons {
                justify-content: center;
            }
        }
        
        @media (max-width: 768px) {
            .hero-content h2 {
                font-size: 2.5rem;
            }
            
            .hero-content p {
                font-size: 1.1rem;
            }
            
            .hero-image-container {
                padding: 1rem;
            }
            
            .floating-badge {
                font-size: 0.85rem;
                padding: 0.5rem 1rem;
            }
            
            .badge-1 {
                left: 0;
            }
            
            .badge-2 {
                right: 0;
            }
            
            .features h2,
            .featured-notes h2,
            .top-earners h2,
            .reviews h2 {
                font-size: 2rem;
            }
            
            .cta-section h2 {
                font-size: 2.2rem;
            }
            
            .notes-grid,
            .features-grid,
            .earners-grid,
            .reviews-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>KwikPaper</h1>
            </div>
            <nav>
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <a href="upload.php">Upload</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="dashboard.php">Dashboard</a>
                <?php endif; ?>
            </nav>
            <div class="nav-search">
                <input type="text" placeholder="Search notes..." id="navSearch">
            </div>
            <nav class="nav-right">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <span class="user-welcome">👋 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <a href="dashboard.php" class="btn-dashboard">Dashboard</a>
                    <a href="api/auth/logout.php" class="btn-logout">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="btn-login">Login</a>
                    <a href="register.php" class="btn-register">Register</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    
    <section class="hero">
        <div class="container">
            <div class="hero-wrapper">
                <div class="hero-content">
                    <h2>Buy & Sell Quality Study Notes</h2>
                    <p>Access thousands of study notes from top students or earn money sharing your own!</p>
                    <div class="hero-buttons">
                        <a href="browse.php" class="btn-primary">Browse Notes</a>
                        <a href="upload.php" class="btn-secondary">Upload Notes</a>
                    </div>
                </div>
                <div class="hero-image">
                    <div class="hero-image-container">
                        <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&h=600&fit=crop&q=80" alt="Students studying together" onerror="this.onerror=null; this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22800%22 height=%22600%22%3E%3Crect fill=%22%23f0f0f0%22 width=%22800%22 height=%22600%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2240%22 fill=%22%23667eea%22 text-anchor=%22middle%22 dy=%22.3em%22%3E📚 Students Studying%3C/text%3E%3C/svg%3E';">
                        <div class="floating-badge badge-1">📚 10,000+ Notes</div>
                        <div class="floating-badge badge-2">⭐ Top Rated</div>
                    </div>
                </div>
            </div>
            <div class="hero-stats">
                <div class="stat">
                    <h3 id="totalNotes">10,000+</h3>
                    <p>Notes Available</p>
                </div>
                <div class="stat">
                    <h3 id="totalUsers">5,000+</h3>
                    <p>Active Students</p>
                </div>
                <div class="stat">
                    <h3>50+</h3>
                    <p>Subjects</p>
                </div>
            </div>
        </div>
    </section>
    
    <section class="features">
        <div class="container">
            <h2>Why Choose KwikPaper?</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="icon">🎓</div>
                    <h3>Quality Notes</h3>
                    <p>All notes are reviewed and verified by our team to ensure high quality.</p>
                </div>
                <div class="feature-card">
                    <div class="icon">💰</div>
                    <h3>Earn Money</h3>
                    <p>Upload your notes and earn money every time someone downloads them.</p>
                </div>
                <div class="feature-card">
                    <div class="icon">🔒</div>
                    <h3>Secure Payment</h3>
                    <p>Safe and secure payment processing for all transactions.</p>
                </div>
                <div class="feature-card">
                    <div class="icon">⚡</div>
                    <h3>Instant Access</h3>
                    <p>Download purchased notes immediately after payment.</p>
                </div>
            </div>
        </div>
    </section>
    
    <section class="featured-notes popular-notes">
        <div class="container">
            <h2>🔥 Popular Notes</h2>
            <div class="notes-grid" id="featuredNotes">
                <p>Loading popular notes...</p>
            </div>
            <div class="text-center">
                <a href="browse.php" class="btn-primary">View All Notes</a>
            </div>
        </div>
    </section>
    
    <section class="image-banner">
        <div class="banner-container">
            <div class="banner-content">
                <h2>Join Thousands of <span class="highlight">Successful Students</span></h2>
                <p>Access premium study materials from top-performing students at universities worldwide. Get ahead in your studies with comprehensive, well-organized notes.</p>
                <ul>
                    <li>High-quality, verified study notes</li>
                    <li>Notes from multiple universities</li>
                    <li>All major subjects covered</li>
                    <li>Instant access to purchased notes</li>
                </ul>
                <a href="browse.php" class="btn-primary" style="display: inline-block; padding: 1rem 2.5rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 12px; font-weight: 600; transition: all 0.3s; box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);">Start Browsing</a>
            </div>
            <div class="banner-image-wrapper">
                <div style="width: 100%; height: 100%; min-height: 450px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); display: flex; align-items: center; justify-content: center; position: relative;">
                    <div style="text-align: center; color: white; z-index: 1; padding: 3rem;">
                        <div style="font-size: 8rem; margin-bottom: 1rem; line-height: 1;">📚</div>
                        <h3 style="font-size: 2.5rem; margin: 1rem 0; font-weight: 700; text-shadow: 0 2px 10px rgba(0,0,0,0.2);">10,000+ Quality Notes</h3>
                        <p style="font-size: 1.3rem; opacity: 0.95;">From Top Students Worldwide</p>
                    </div>
                    <div style="position: absolute; width: 300px; height: 300px; background: rgba(255,255,255,0.1); border-radius: 50%; top: -100px; right: -100px;"></div>
                    <div style="position: absolute; width: 200px; height: 200px; background: rgba(255,255,255,0.1); border-radius: 50%; bottom: -50px; left: -50px;"></div>
                </div>
                <div class="banner-badge banner-badge-1">📖 Expert Notes</div>
                <div class="banner-badge banner-badge-2">🎯 100% Success</div>
            </div>
        </div>
    </section>
    
    <section class="featured-notes latest-notes">
        <div class="container">
            <h2>⚡ Latest Notes</h2>
            <p class="section-subtitle">Fresh notes uploaded in the last 7 days</p>
            <div class="notes-grid" id="latestNotes">
                <p>Loading latest notes...</p>
            </div>
            <div class="text-center">
                <a href="browse.php" class="btn-primary">View All Notes</a>
            </div>
        </div>
    </section>
    
    <section class="top-earners">
        <div class="container">
            <h2>🏆 Top 5 Earners This Month</h2>
            <p class="section-subtitle">Our most successful note sellers of February 2026</p>
            <div class="earners-grid">
                <a href="profile.php?id=1" class="earner-card rank-1">
                    <div class="rank-badge">1</div>
                    <div class="earner-avatar">👩‍🎓</div>
                    <h3>Sarah Williams</h3>
                    <p class="earner-subject">Biology & Chemistry</p>
                    <div class="earner-earnings">
                        <span class="earnings-amount">$1,247</span>
                        <span class="earnings-label">earned</span>
                    </div>
                    <p class="earner-stats">📝 47 notes • ⭐ 4.9</p>
                </a>
                <a href="profile.php?id=2" class="earner-card rank-2">
                    <div class="rank-badge">2</div>
                    <div class="earner-avatar">👨‍🎓</div>
                    <h3>Alex Johnson</h3>
                    <p class="earner-subject">Computer Science</p>
                    <div class="earner-earnings">
                        <span class="earnings-amount">$1,089</span>
                        <span class="earnings-label">earned</span>
                    </div>
                    <p class="earner-stats">📝 38 notes • ⭐ 4.8</p>
                </a>
                <a href="profile.php?id=3" class="earner-card rank-3">
                    <div class="rank-badge">3</div>
                    <div class="earner-avatar">👩‍🎓</div>
                    <h3>Emma Rodriguez</h3>
                    <p class="earner-subject">Mathematics & Physics</p>
                    <div class="earner-earnings">
                        <span class="earnings-amount">$986</span>
                        <span class="earnings-label">earned</span>
                    </div>
                    <p class="earner-stats">📝 52 notes • ⭐ 4.9</p>
                </a>
                <a href="profile.php?id=4" class="earner-card">
                    <div class="rank-badge">4</div>
                    <div class="earner-avatar">👨‍🎓</div>
                    <h3>Ryan Lee</h3>
                    <p class="earner-subject">Business & Economics</p>
                    <div class="earner-earnings">
                        <span class="earnings-amount">$842</span>
                        <span class="earnings-label">earned</span>
                    </div>
                    <p class="earner-stats">📝 34 notes • ⭐ 4.7</p>
                </a>
                <a href="profile.php?id=5" class="earner-card">
                    <div class="rank-badge">5</div>
                    <div class="earner-avatar">👩‍🎓</div>
                    <h3>Olivia Brown</h3>
                    <p class="earner-subject">Psychology & Sociology</p>
                    <div class="earner-earnings">
                        <span class="earnings-amount">$765</span>
                        <span class="earnings-label">earned</span>
                    </div>
                    <p class="earner-stats">📝 29 notes • ⭐ 4.8</p>
                </a>
            </div>
            <div class="text-center">
                <p class="earner-cta">💡 Start uploading your notes today and join our top 5 earners!</p>
                <a href="upload.php" class="btn-primary">Upload Your Notes</a>
            </div>
        </div>
    </section>
    
    <section class="reviews">
        <div class="container">
            <h2>What Students Say</h2>
            <p class="section-subtitle">Join thousands of satisfied students who trust KwikPaper</p>
            <div class="reviews-grid">
                <div class="review-card">
                    <div class="review-rating">★★★★★</div>
                    <p class="review-text">"KwikPaper saved my semester! The notes I bought were incredibly detailed and helped me ace my finals. Highly recommend!"</p>
                    <div class="review-author">
                        <div class="author-avatar">👨‍🎓</div>
                        <div class="author-info">
                            <h4>Michael Chen</h4>
                            <p>Computer Science Major</p>
                        </div>
                    </div>
                </div>
                <div class="review-card">
                    <div class="review-rating">★★★★★</div>
                    <p class="review-text">"I've earned over $500 selling my notes! It's a great way to help other students while making money from my hard work."</p>
                    <div class="review-author">
                        <div class="author-avatar">👩‍🎓</div>
                        <div class="author-info">
                            <h4>Jessica Martinez</h4>
                            <p>Biology Major</p>
                        </div>
                    </div>
                </div>
                <div class="review-card">
                    <div class="review-rating">★★★★★</div>
                    <p class="review-text">"The quality of notes here is outstanding. Every set I've purchased has been well-organized and easy to understand. Amazing platform!"</p>
                    <div class="review-author">
                        <div class="author-avatar">👨‍🎓</div>
                        <div class="author-info">
                            <h4>David Thompson</h4>
                            <p>Engineering Student</p>
                        </div>
                    </div>
                </div>
                <div class="review-card">
                    <div class="review-rating">★★★★★</div>
                    <p class="review-text">"Fast, secure, and reliable. I love how easy it is to find notes for any subject. This site is a lifesaver during exam season!"</p>
                    <div class="review-author">
                        <div class="author-avatar">👩‍🎓</div>
                        <div class="author-info">
                            <h4>Priya Patel</h4>
                            <p>Pre-Med Student</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <section class="cta-section">
        <div class="container">
            <h2>Ready to Get Started?</h2>
            <p>Join thousands of students buying and selling quality study notes</p>
            <a href="register.php" class="btn-primary-large">Sign Up Free</a>
        </div>
    </section>
    
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">How It Works</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Twitter</a></li>
                        <li><a href="#">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
    <script>
        // Load popular notes (top 10 by downloads)
        async function loadFeaturedNotes() {
            const container = document.getElementById('featuredNotes');
            
            try {
                const result = await NotesAPI.getFeatured(10);
                
                if (result.success && result.data && result.data.length > 0) {
                    container.innerHTML = result.data.map((note, index) => {
                        const badges = [];
                        if (note.views > 100) badges.push('<div class="note-badge popular">Popular</div>');
                        if (new Date(note.created_at) > new Date(Date.now() - 7*24*60*60*1000)) badges.push('<div class="note-badge new">New</div>');
                        
                        const noteIcons = {
                            'Science': '⚗️',
                            'Math': '📐',
                            'Mathematics': '📐',
                            'Programming': '💻',
                            'Computer Science': '💻',
                            'Business': '📈',
                            'History': '🌍',
                            'Biology': '🧬',
                            'Psychology': '🧠',
                            'Statistics': '📊',
                            'Engineering': '⚙️',
                            'Physics': '⚛️',
                            'Chemistry': '🧪'
                        };
                        const icon = noteIcons[note.category] || '📚';
                        const title = Utils.escapeHtml(note.title || 'Untitled');
                        const description = note.description ? Utils.escapeHtml(note.description.substring(0, 80)) + '...' : 'Comprehensive study notes';
                        const username = Utils.escapeHtml(note.username || 'Anonymous');
                        const rating = note.rating && !isNaN(note.rating) ? parseFloat(note.rating) : 4.5;
                        const starRating = '★'.repeat(Math.floor(rating)) + (rating % 1 >= 0.5 ? '★' : '☆');
                        
                        return `
                        <div class="note-card">
                            ${badges.join('')}
                            <div class="note-image">${icon}</div>
                            <h3>${title}</h3>
                            <p>${description}</p>
                            <div class="note-meta">
                                <span class="author">By ${username}</span>
                                <span class="rating">${starRating}</span>
                            </div>
                            <div class="note-footer">
                                <span class="price">${Utils.formatPrice(note.price)}</span>
                                <button onclick="location.href='note-detail.php?id=${note.id}'">View Details</button>
                            </div>
                        </div>
                    `;
                    }).join('');
                } else {
                    // Show message if no popular notes
                    container.innerHTML = '<p style="text-align: center; color: #6c757d; grid-column: 1 / -1; padding: 3rem;">No popular notes available yet. Be the first to upload!</p>';
                }
            } catch (error) {
                console.error('Error loading popular notes:', error);
                container.innerHTML = '<p style="text-align: center; color: #e74c3c; grid-column: 1 / -1; padding: 3rem;">Failed to load popular notes. Please try again later.</p>';
            }
        }
        
        // Load latest notes (uploaded in last 7 days)
        async function loadLatestNotes() {
            const container = document.getElementById('latestNotes');
            
            try {
                const result = await NotesAPI.getLatest(10);
                
                if (result.success && result.data && result.data.length > 0) {
                    container.innerHTML = result.data.map((note, index) => {
                        const badges = [];
                        // All notes in this section are new (within 7 days)
                        badges.push('<div class="note-badge new">New</div>');
                        
                        const noteIcons = {
                            'Science': '⚗️',
                            'Math': '📐',
                            'Mathematics': '📐',
                            'Programming': '💻',
                            'Computer Science': '💻',
                            'Business': '📈',
                            'History': '🌍',
                            'Biology': '🧬',
                            'Psychology': '🧠',
                            'Statistics': '📊',
                            'Engineering': '⚙️',
                            'Physics': '⚛️',
                            'Chemistry': '🧪'
                        };
                        const icon = noteIcons[note.category] || '📚';
                        const title = Utils.escapeHtml(note.title || 'Untitled');
                        const description = note.description ? Utils.escapeHtml(note.description.substring(0, 80)) + '...' : 'Comprehensive study notes';
                        const username = Utils.escapeHtml(note.username || 'Anonymous');
                        const rating = note.rating && !isNaN(note.rating) ? parseFloat(note.rating) : 4.5;
                        const starRating = '★'.repeat(Math.floor(rating)) + (rating % 1 >= 0.5 ? '★' : '☆');
                        
                        return `
                        <div class="note-card">
                            ${badges.join('')}
                            <div class="note-image">${icon}</div>
                            <h3>${title}</h3>
                            <p>${description}</p>
                            <div class="note-meta">
                                <span class="author">By ${username}</span>
                                <span class="rating">${starRating}</span>
                            </div>
                            <div class="note-footer">
                                <span class="price">${Utils.formatPrice(note.price)}</span>
                                <button onclick="location.href='note-detail.php?id=${note.id}'">View Details</button>
                            </div>
                        </div>
                    `;
                    }).join('');
                } else {
                    // Show message if no recent notes
                    container.innerHTML = '<p style="text-align: center; color: #6c757d; grid-column: 1 / -1;">No new notes uploaded in the last 7 days. Check back soon!</p>';
                }
            } catch (error) {
                console.error('Error loading latest notes:', error);
                container.innerHTML = '<p style="text-align: center; color: #e74c3c; grid-column: 1 / -1;">Failed to load latest notes. Please try again later.</p>';
            }
        }
        
        // Update stats dynamically
        async function updateStats() {
            try {
                const result = await NotesAPI.list(1, 1, 'all', '');
                if (result.success && result.pagination) {
                    const total = result.pagination.total_records;
                    if (total > 0) {
                        document.getElementById('totalNotes').textContent = total.toLocaleString() + '+';
                    }
                }
            } catch (error) {
                console.log('Could not load stats');
            }
        }
        
        // Load on page ready
        document.addEventListener('DOMContentLoaded', () => {
            loadFeaturedNotes();
            loadLatestNotes();
            updateStats();
        });
    </script>
</body>
</html>
