/**
 * API Helper Functions
 * Reusable functions for integrating with the PHP API
 */

const API_BASE_URL = 'api/';

// Helper function for making API requests
async function apiRequest(endpoint, options = {}) {
    try {
        const response = await fetch(API_BASE_URL + endpoint, {
            ...options,
            credentials: 'include', // Important: Send cookies with request
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            }
        });
        
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('API Error:', error);
        return {
            success: false,
            message: 'Network error. Please try again.'
        };
    }
}

// Authentication APIs
const AuthAPI = {
    // Register new user
    async register(username, email, password) {
        return await apiRequest('auth/register.php', {
            method: 'POST',
            body: JSON.stringify({ username, email, password })
        });
    },

    // Login user
    async login(username, password) {
        const result = await apiRequest('auth/login.php', {
            method: 'POST',
            body: JSON.stringify({ username, password })
        });
        
        if (result.success) {
            localStorage.setItem('user', JSON.stringify(result.user));
            localStorage.setItem('session_token', result.session_token);
        }
        
        return result;
    },

    // Logout user
    async logout() {
        const result = await apiRequest('auth/logout.php', {
            method: 'POST'
        });
        
        if (result.success) {
            localStorage.removeItem('user');
            localStorage.removeItem('session_token');
        }
        
        return result;
    },

    // Check session
    async checkSession() {
        return await apiRequest('auth/session.php');
    },

    // Get current user from localStorage
    getCurrentUser() {
        const userStr = localStorage.getItem('user');
        return userStr ? JSON.parse(userStr) : null;
    },

    // Check if user is logged in
    isLoggedIn() {
        return this.getCurrentUser() !== null;
    }
};

// Notes APIs
const NotesAPI = {
    // Browse/list notes with filters
    async list(page = 1, limit = 12, category = 'all', search = '') {
        const params = new URLSearchParams({
            page,
            limit,
            category,
            search
        });
        return await apiRequest(`notes/list.php?${params}`);
    },

    // Get note details
    async getDetail(noteId) {
        return await apiRequest(`notes/detail.php?id=${noteId}`);
    },

    // Upload new note
    async create(formData) {
        try {
            const response = await fetch(API_BASE_URL + 'notes/create.php', {
                method: 'POST',
                credentials: 'include', // Important: Send cookies with request
                body: formData // FormData object with file
            });
            return await response.json();
        } catch (error) {
            console.error('Upload Error:', error);
            return {
                success: false,
                message: 'Failed to upload note'
            };
        }
    },

    // Get user's notes
    async getUserNotes(userId = null) {
        const url = userId 
            ? `notes/user-notes.php?user_id=${userId}`
            : 'notes/user-notes.php';
        return await apiRequest(url);
    },

    // Get popular notes (top by downloads)
    async getFeatured(limit = 10) {
        return await apiRequest(`notes/featured.php?limit=${limit}`);
    },

    // Get latest notes (uploaded in last 7 days)
    async getLatest(limit = 10) {
        return await apiRequest(`notes/latest.php?limit=${limit}`);
    }
};

// User Profile APIs
const UserAPI = {
    // Get user profile
    async getProfile(userId) {
        return await apiRequest(`user/profile.php?user_id=${userId}`);
    },

    // Update profile
    async updateProfile(profileData) {
        return await apiRequest('user/update-profile.php', {
            method: 'PUT',
            body: JSON.stringify(profileData)
        });
    },

    // Get user statistics
    async getStats() {
        return await apiRequest('user/stats.php');
    }
};

// Utility Functions
const Utils = {
    // Escape HTML to prevent XSS
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    // Show notification/alert
    showNotification(message, type = 'info') {
        // You can customize this to use a better notification system
        alert(message);
    },

    // Format price
    formatPrice(price) {
        return `$${parseFloat(price).toFixed(2)}`;
    },

    // Format date
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    },

    // Redirect to login if not authenticated
    requireAuth() {
        if (!AuthAPI.isLoggedIn()) {
            alert('Please login to access this page');
            window.location.href = 'login.html';
            return false;
        }
        return true;
    },

    // Update UI for logged in user
    updateAuthUI() {
        const user = AuthAPI.getCurrentUser();
        const loginBtn = document.querySelector('.btn-login');
        
        if (user && loginBtn) {
            loginBtn.textContent = user.username;
            loginBtn.href = 'dashboard.html';
        }
    }
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { AuthAPI, NotesAPI, UserAPI, Utils };
}
