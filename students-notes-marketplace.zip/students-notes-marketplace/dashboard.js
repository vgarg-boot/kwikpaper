// Dashboard logic for displaying user info and logout

document.addEventListener('DOMContentLoaded', function() {
    const userNameSpan = document.getElementById('userName');
    const logoutBtn = document.getElementById('logoutBtn');
    const currentUser = localStorage.getItem('currentUser');

    // Check if user is logged in
    if (!currentUser) {
        alert('⚠️ Please login to access the dashboard');
        window.location.href = 'login.html';
        return;
    }

    // Display user information
    userNameSpan.textContent = currentUser;
    
    // Get user data
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    const userData = users[currentUser];
    
    if (userData) {
        document.getElementById('notesUploaded').textContent = userData.notesUploaded || 0;
        document.getElementById('notesPurchased').textContent = userData.notesPurchased || 0;
        document.getElementById('totalEarnings').textContent = '$' + (userData.earnings || 0).toFixed(2);
    }

    // Logout functionality
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to logout?')) {
                localStorage.removeItem('currentUser');
                alert('✅ Logged out successfully!');
                window.location.href = 'index.html';
            }
        });
    }
});
