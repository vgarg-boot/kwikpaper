<?php
session_start();

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get note ID from URL
$note_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($note_id === 0) {
    header('Location: my-notes.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Note - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <!-- PDF.js Library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
    <style>
        * {
            scroll-behavior: smooth;
        }
        
        body {
            background: #f5f7fa;
            margin: 0;
            padding: 0;
        }
        
        /* Reader Header */
        .reader-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 1rem 0;
            box-shadow: 0 4px 20px rgba(102, 126, 234, 0.3);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .reader-header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 2rem;
        }
        
        .note-info {
            flex: 1;
            min-width: 0;
        }
        
        .note-title-reader {
            font-size: 1.5rem;
            font-weight: 700;
            margin: 0;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .note-meta-reader {
            display: flex;
            gap: 1rem;
            margin-top: 0.5rem;
            font-size: 0.9rem;
            opacity: 0.95;
        }
        
        .reader-actions {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .btn-back {
            padding: 0.7rem 1.5rem;
            background: rgba(255, 255, 255, 0.2);
            color: white;
            border: 2px solid rgba(255, 255, 255, 0.4);
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.95rem;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-back:hover {
            background: rgba(255, 255, 255, 0.3);
            border-color: rgba(255, 255, 255, 0.6);
            transform: translateY(-2px);
        }
        
        .page-controls {
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .page-info {
            font-size: 0.95rem;
            font-weight: 600;
            padding: 0.5rem 1rem;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            white-space: nowrap;
        }
        
        /* Reader Container */
        .reader-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 2rem 4rem;
        }
        
        /* Loading State */
        .loading-reader {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }
        
        .loading-spinner {
            width: 60px;
            height: 60px;
            border: 5px solid #e9ecef;
            border-top-color: #667eea;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 1.5rem;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* PDF Viewer */
        .pdf-viewer {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            overflow: hidden;
            min-height: 600px;
            position: relative;
        }
        
        .pdf-page-container {
            position: relative;
            margin: 0;
        }
        
        .pdf-page-wrapper {
            padding: 2rem;
            border-bottom: 2px solid #e9ecef;
            position: relative;
            display: none;
            animation: fadeIn 0.3s ease-in-out;
            background: #fafbfc;
        }
        
        .pdf-page-wrapper:nth-child(odd) {
            background: white;
        }
        
        .pdf-page-wrapper:nth-child(even) {
            background: #f8f9fa;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .pdf-page-wrapper.visible {
            display: block;
        }
        
        .pdf-page-wrapper.visible:not(:last-of-type) {
            margin-bottom: 0;
        }
        
        .pdf-page-wrapper:last-child {
            border-bottom: none;
        }
        
        .page-number-badge {
            position: sticky;
            top: 80px;
            display: inline-block;
            padding: 0.5rem 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.9rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 10px rgba(102, 126, 234, 0.3);
            z-index: 10;
        }
        
        .pdf-canvas {
            display: block;
            margin: 0 auto;
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.12);
            background: white;
        }
        
        /* Navigation Controls */
        .navigation-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            padding: 1rem 2rem;
            box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 1rem;
            z-index: 999;
        }
        
        .nav-btn {
            padding: 0.8rem 1.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.95rem;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .nav-btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .nav-btn:disabled {
            background: linear-gradient(135deg, #cbd5e0 0%, #a0aec0 100%);
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .scroll-top-btn {
            position: fixed;
            bottom: 5rem;
            right: 2rem;
            padding: 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            cursor: pointer;
            font-size: 1.2rem;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            display: none;
            z-index: 998;
        }
        
        .scroll-top-btn.visible {
            display: block;
        }
        
        .scroll-top-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
        }
        
        /* Access Denied */
        .access-denied {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
        }
        
        .access-denied-icon {
            font-size: 5rem;
            margin-bottom: 1.5rem;
        }
        
        .access-denied h2 {
            font-size: 2rem;
            color: #2c3e50;
            margin-bottom: 1rem;
        }
        
        .access-denied p {
            color: #6c757d;
            font-size: 1.1rem;
            margin-bottom: 2rem;
        }
        
        .btn-action {
            padding: 1rem 2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .reader-header-content {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
            
            .reader-actions {
                width: 100%;
                justify-content: space-between;
            }
            
            .note-title-reader {
                font-size: 1.2rem;
            }
            
            .page-controls {
                flex-wrap: wrap;
            }
            
            .navigation-footer {
                padding: 0.8rem 1rem;
            }
            
            .scroll-top-btn {
                bottom: 4.5rem;
                right: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Reader Header -->
    <div class="reader-header">
        <div class="reader-header-content">
            <div class="note-info">
                <h1 class="note-title-reader" id="noteTitle">Loading...</h1>
                <div class="note-meta-reader" id="noteMeta">
                    <span id="noteCategory"></span>
                    <span id="noteAuthor"></span>
                </div>
            </div>
            <div class="reader-actions">
                <div class="page-controls">
                    <span class="page-info" id="pageInfo">Page 0 of 0</span>
                </div>
                <a href="my-notes.php?tab=purchased" class="btn-back">
                    <span>←</span>
                    <span>Back to My Notes</span>
                </a>
            </div>
        </div>
    </div>
    
    <!-- Reader Container -->
    <div class="reader-container">
        <div id="loadingReader" class="loading-reader">
            <div class="loading-spinner"></div>
            <h3>Loading your note...</h3>
            <p style="color: #6c757d; margin-top: 0.5rem;">Please wait while we prepare the content</p>
        </div>
        
        <div id="pdfViewer" class="pdf-viewer" style="display: none;">
            <!-- PDF pages will be rendered here -->
        </div>
        
        <div id="accessDenied" class="access-denied" style="display: none;">
            <div class="access-denied-icon">🔒</div>
            <h2>Access Denied</h2>
            <p>You don't have permission to view this note. Please add it to your library first.</p>
            <a href="browse.php" class="btn-action">Browse Notes</a>
        </div>
    </div>
    
    <!-- Scroll to Top Button -->
    <button class="scroll-top-btn" id="scrollTopBtn" onclick="scrollToTop()">↑</button>
    
    <!-- Navigation Footer -->
    <div class="navigation-footer" id="navFooter" style="display: none;">
        <button class="nav-btn" id="prevBtn" onclick="scrollToPreviousPage()" disabled>
            <span>⬅️</span>
            <span>Previous</span>
        </button>
        <span style="color: #6c757d; font-weight: 600;" id="footerPageInfo">Page 1 of 1</span>
        <button class="nav-btn" id="nextBtn" onclick="scrollToNextPage()">
            <span>Next</span>
            <span>➡️</span>
        </button>
    </div>
    
    <script>
        console.log('View note script loaded');
        const noteId = <?php echo $note_id; ?>;
        console.log('Note ID from PHP:', noteId);
        let currentPageIndex = 0; // Index for which pair of pages to show (0 = pages 1-2, 1 = pages 3-4, etc.)
        let totalPages = 0;
        let pageElements = [];
        const PAGES_PER_VIEW = 2;
        
        // Load note and check access
        async function loadNote() {
            try {
                console.log('Loading note with ID:', noteId);
                
                // Check if user has access
                const accessResponse = await fetch(`api/notes/check-access.php?id=${noteId}`);
                const accessData = await accessResponse.json();
                
                console.log('Access check response:', accessData);
                
                if (!accessData.success || !accessData.has_access) {
                    console.log('Access denied');
                    document.getElementById('loadingReader').style.display = 'none';
                    document.getElementById('accessDenied').style.display = 'block';
                    return;
                }
                
                // Load note details
                const noteResponse = await fetch(`api/notes/detail.php?id=${noteId}`);
                const noteData = await noteResponse.json();
                
                console.log('Note details response:', noteData);
                
                if (!noteData.success || !noteData.data) {
                    throw new Error('Note not found');
                }
                
                const note = noteData.data;
                
                // Update header info
                document.getElementById('noteTitle').textContent = note.title;
                document.getElementById('noteCategory').innerHTML = `📂 ${note.category}`;
                document.getElementById('noteAuthor').innerHTML = `👤 ${note.username}`;
                document.title = `${note.title} - KwikPaper`;
                
                console.log('Rendering PDF from path:', note.file_path);
                
                // Render PDF
                await renderFullPDF(note.file_path);
                
            } catch (error) {
                console.error('Error loading note:', error);
                document.getElementById('loadingReader').innerHTML = `
                    <div style="font-size: 3rem; margin-bottom: 1rem;">⚠️</div>
                    <h3>Error Loading Note</h3>
                    <p style="color: #6c757d; margin-top: 0.5rem;">${error.message}</p>
                    <a href="my-notes.php" class="btn-action" style="margin-top: 1rem;">Back to My Notes</a>
                `;
            }
        }
        
        // Render full PDF
        async function renderFullPDF(filePath) {
            try {
                console.log('renderFullPDF called with:', filePath);
                
                // Convert database path to web-accessible path
                if (filePath && filePath.startsWith('../../uploads/')) {
                    filePath = filePath.replace('../../', '');
                }
                
                console.log('Converted path:', filePath);
                
                if (!filePath || !filePath.endsWith('.pdf')) {
                    throw new Error('Invalid file path or file type');
                }
                
                // Configure PDF.js worker
                pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
                
                console.log('Loading PDF document...');
                const loadingTask = pdfjsLib.getDocument(filePath);
                const pdf = await loadingTask.promise;
                
                totalPages = pdf.numPages;
                console.log('PDF loaded successfully. Total pages:', totalPages);
                
                // Hide loading, show viewer
                document.getElementById('loadingReader').style.display = 'none';
                document.getElementById('pdfViewer').style.display = 'block';
                document.getElementById('navFooter').style.display = 'flex';
                
                const viewer = document.getElementById('pdfViewer');
                viewer.innerHTML = '';
                
                // Render all pages
                for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
                    console.log(`Rendering page ${pageNum}...`);
                    const page = await pdf.getPage(pageNum);
                    
                    // Create page wrapper
                    const pageWrapper = document.createElement('div');
                    pageWrapper.className = 'pdf-page-wrapper';
                    pageWrapper.setAttribute('data-page', pageNum);
                    pageWrapper.id = `page-${pageNum}`;
                    
                    // Add page number badge
                    const badge = document.createElement('div');
                    badge.className = 'page-number-badge';
                    badge.textContent = `📄 Page ${pageNum} of ${totalPages}`;
                    pageWrapper.appendChild(badge);
                    
                    // Create canvas
                    const canvas = document.createElement('canvas');
                    canvas.className = 'pdf-canvas';
                    const context = canvas.getContext('2d');
                    
                    // Calculate scale to fit width
                    const viewport = page.getViewport({ scale: 1.5 });
                    canvas.width = viewport.width;
                    canvas.height = viewport.height;
                    
                    // Render PDF page
                    await page.render({
                        canvasContext: context,
                        viewport: viewport
                    }).promise;
                    
                    pageWrapper.appendChild(canvas);
                    viewer.appendChild(pageWrapper);
                    
                    pageElements.push(pageWrapper);
                }
                
                console.log('All pages rendered. Total page elements:', pageElements.length);
                
                // Show first 2 pages - this will also update page info and navigation buttons
                console.log('Showing first pages...');
                showPages(0);
                
                console.log('PDF rendering complete!');
            } catch (error) {
                console.error('Error in renderFullPDF:', error);
                throw error;
            }
        }
        
        // Show specific pair of pages
        function showPages(pageIndex) {
            console.log('showPages called with index:', pageIndex, 'pageElements length:', pageElements.length);
            currentPageIndex = pageIndex;
            
            // Hide all pages
            pageElements.forEach(el => el.classList.remove('visible'));
            
            // Show current 2 pages
            const startPage = pageIndex * PAGES_PER_VIEW;
            for (let i = 0; i < PAGES_PER_VIEW; i++) {
                const pageIdx = startPage + i;
                if (pageIdx < pageElements.length) {
                    console.log(`Making page ${pageIdx} visible`);
                    pageElements[pageIdx].classList.add('visible');
                }
            }
            
            // Update page info and buttons
            updatePageInfo();
            updateNavigationButtons();
            
            // Scroll to top of viewer
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
            
            console.log('showPages completed');
        }
        
        // Update page information display
        function updatePageInfo() {
            const startPage = (currentPageIndex * PAGES_PER_VIEW) + 1;
            const endPage = Math.min(startPage + PAGES_PER_VIEW - 1, totalPages);
            
            let pageText;
            if (startPage === endPage) {
                pageText = `Page ${startPage} of ${totalPages}`;
            } else {
                pageText = `Pages ${startPage}-${endPage} of ${totalPages}`;
            }
            
            document.getElementById('pageInfo').textContent = pageText;
            document.getElementById('footerPageInfo').textContent = pageText;
        }
        
        // Update navigation button states
        function updateNavigationButtons() {
            const isFirstPages = currentPageIndex === 0;
            const isLastPages = (currentPageIndex * PAGES_PER_VIEW + PAGES_PER_VIEW) >= totalPages;
            
            document.getElementById('prevBtn').disabled = isFirstPages;
            document.getElementById('nextBtn').disabled = isLastPages;
        }
        
        // Navigation functions
        function scrollToNextPage() {
            const maxIndex = Math.ceil(totalPages / PAGES_PER_VIEW) - 1;
            if (currentPageIndex < maxIndex) {
                showPages(currentPageIndex + 1);
            }
        }
        
        function scrollToPreviousPage() {
            if (currentPageIndex > 0) {
                showPages(currentPageIndex - 1);
            }
        }
        
        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
        
        // Show/hide scroll to top button
        window.addEventListener('scroll', () => {
            const scrollTopBtn = document.getElementById('scrollTopBtn');
            if (window.pageYOffset > 500) {
                scrollTopBtn.classList.add('visible');
            } else {
                scrollTopBtn.classList.remove('visible');
            }
        });
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                e.preventDefault();
                scrollToNextPage();
            } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                e.preventDefault();
                scrollToPreviousPage();
            } else if (e.key === 'Home') {
                e.preventDefault();
                showPages(0);
            } else if (e.key === 'End') {
                e.preventDefault();
                const lastIndex = Math.ceil(totalPages / PAGES_PER_VIEW) - 1;
                showPages(lastIndex);
            }
        });
        
        // Load note on page load
        console.log('Setting up DOMContentLoaded listener');
        document.addEventListener('DOMContentLoaded', loadNote);
        console.log('Script execution complete');
    </script>
</body>
</html>
