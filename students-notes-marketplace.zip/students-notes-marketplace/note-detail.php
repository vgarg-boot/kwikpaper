﻿<?php
session_start();

// Get note ID from URL
$note_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($note_id === 0) {
    header('Location: browse.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Note Details - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <!-- PDF.js Library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
    <style>
        * {
            scroll-behavior: smooth;
        }
        
        .breadcrumb {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem 0;
            box-shadow: 0 2px 10px rgba(102, 126, 234, 0.2);
        }
        .breadcrumb-nav {
            display: flex;
            gap: 0.5rem;
            align-items: center;
            font-size: 0.9rem;
        }
        .breadcrumb-nav a {
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            transition: color 0.3s;
            font-weight: 500;
        }
        .breadcrumb-nav a:hover {
            color: #ffffff;
        }
        .breadcrumb-nav span {
            color: rgba(255, 255, 255, 0.7);
        }
        
        .note-detail-grid {
            display: grid;
            grid-template-columns: 4fr 1fr;
            gap: 1.5rem;
            margin-top: 1rem;
        }
        
        .note-main-content {
            background: #fff;
            border-radius: 20px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.08);
            border: 1px solid rgba(102, 126, 234, 0.1);
        }
        
        .note-title {
            font-size: 2.3rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 0.8rem;
            line-height: 1.2;
            font-weight: 700;
        }
        
        .note-meta-badges {
            display: flex;
            gap: 0.8rem;
            flex-wrap: wrap;
            margin-bottom: 1.5rem;
        }
        
        .badge {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.6rem 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 30px;
            font-size: 0.95rem;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.25);
            transition: all 0.3s ease;
        }
        
        .badge:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.35);
        }
        
        .badge.category {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            box-shadow: 0 4px 15px rgba(240, 147, 251, 0.25);
        }
        
        .badge.category:hover {
            box-shadow: 0 6px 20px rgba(240, 147, 251, 0.35);
        }
        
        .badge.rating {
            background: linear-gradient(135deg, #ffd89b 0%, #fe9b45 100%);
            box-shadow: 0 4px 15px rgba(254, 155, 69, 0.25);
        }
        
        .badge.rating:hover {
            box-shadow: 0 6px 20px rgba(254, 155, 69, 0.35);
        }
        
        .badge.downloads {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            box-shadow: 0 4px 15px rgba(79, 172, 254, 0.25);
        }
        
        .badge.downloads:hover {
            box-shadow: 0 6px 20px rgba(79, 172, 254, 0.35);
        }
        
        .badge.views {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            box-shadow: 0 4px 15px rgba(67, 233, 123, 0.25);
        }
        
        .badge.views:hover {
            box-shadow: 0 6px 20px rgba(67, 233, 123, 0.35);
        }
        
        .author-info {
            display: flex;
            align-items: center;
            gap: 1.2rem;
            padding: 1.5rem;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            border-radius: 15px;
            margin-bottom: 1.5rem;
            border: 2px solid rgba(102, 126, 234, 0.2);
            transition: all 0.3s ease;
        }
        
        .author-info:hover {
            border-color: rgba(102, 126, 234, 0.4);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
            transform: translateY(-2px);
        }
        
        .author-avatar {
            font-size: 3rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50%;
            width: 70px;
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.3);
        }
        
        .author-details h4 {
            margin: 0;
            color: #2c3e50;
            font-size: 1.1rem;
        }
        
        .author-details p {
            margin: 0.3rem 0 0 0;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .description-section {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%);
            padding: 1.8rem;
            border-radius: 15px;
            margin-bottom: 1.5rem;
            border: 2px solid rgba(102, 126, 234, 0.1);
        }
        
        .description-section h3 {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-top: 0;
            margin-bottom: 1.2rem;
            display: flex;
            align-items: center;
            gap: 0.7rem;
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .description-section p {
            color: #2c3e50;
            line-height: 1.8;
            font-size: 1rem;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            margin-top: 1.5rem;
        }
        
        .info-item {
            background: white;
            padding: 1.2rem;
            border-radius: 12px;
            border: 2px solid rgba(102, 126, 234, 0.15);
            transition: all 0.3s ease;
        }
        
        .info-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.15);
            border-color: rgba(102, 126, 234, 0.3);
        }
        
        .info-item strong {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: block;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.8px;
            font-weight: 700;
        }
        
        .info-item span {
            color: #2c3e50;
            font-size: 1.15rem;
            font-weight: 600;
        }
        
        .note-sidebar {
            position: sticky;
            top: 100px;
            height: fit-content;
        }
        
        .purchase-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
            border-radius: 20px;
            padding: 1.8rem;
            box-shadow: 0 10px 40px rgba(102, 126, 234, 0.2);
            border: 3px solid rgba(102, 126, 234, 0.2);
            position: relative;
            overflow: hidden;
        }
        
        .purchase-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 50%, #667eea 100%);
            background-size: 200% 100%;
            animation: gradient-shift 3s ease infinite;
        }
        
        .price-display {
            text-align: center;
            margin-bottom: 2rem;
            padding: 1.5rem;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            border-radius: 15px;
        }
        
        .price-label {
            color: #6c757d;
            font-size: 1rem;
            margin-bottom: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .price-amount {
            font-size: 3.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1;
        }
        
        .purchase-features {
            margin-bottom: 2rem;
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem 0;
            border-bottom: 2px solid rgba(102, 126, 234, 0.1);
            transition: all 0.3s ease;
        }
        
        .feature-item:hover {
            padding-left: 0.5rem;
            background: rgba(102, 126, 234, 0.05);
            border-radius: 8px;
        }
        
        .feature-item:last-child {
            border-bottom: none;
        }
        
        .feature-icon {
            font-size: 1.5rem;
            filter: drop-shadow(0 2px 4px rgba(102, 126, 234, 0.3));
        }
        
        .feature-text {
            color: #2c3e50;
            font-size: 1rem;
            font-weight: 600;
        }
        
        .btn-purchase {
            width: 100%;
            padding: 1.2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 15px;
            font-size: 1.2rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 6px 25px rgba(102, 126, 234, 0.4);
            position: relative;
            overflow: hidden;
        }
        
        .btn-purchase::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }
        
        .btn-purchase:hover::before {
            width: 300px;
            height: 300px;
        }
        
        .btn-purchase:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 35px rgba(102, 126, 234, 0.5);
        }
        
        .btn-contact-seller {
            width: 100%;
            padding: 1.2rem;
            background: white;
            color: #667eea;
            border: 3px solid #667eea;
            border-radius: 15px;
            font-size: 1.1rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 1rem;
        }
        
        .btn-contact-seller:hover {
            background: #667eea;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3);
        }
        
        .seller-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
            border-radius: 20px;
            padding: 2.5rem;
            box-shadow: 0 8px 30px rgba(0,0,0,0.08);
            margin-top: 1.5rem;
            border: 2px solid rgba(102, 126, 234, 0.15);
        }
        
        .seller-card h3 {
            color: #2c3e50;
            margin-top: 0;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.7rem;
            font-size: 1.3rem;
            font-weight: 700;
        }
        
        .seller-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            margin-top: 1.5rem;
        }
        
        .stat-box {
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            padding: 1.3rem;
            border-radius: 12px;
            text-align: center;
            border: 2px solid rgba(102, 126, 234, 0.15);
            transition: all 0.3s ease;
        }
        
        .stat-box:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(102, 126, 234, 0.15);
            border-color: rgba(102, 126, 234, 0.3);
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            display: block;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #6c757d;
            margin-top: 0.5rem;
            font-weight: 600;
        }
        
        .reviews-section {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
            border-radius: 20px;
            padding: 3rem;
            box-shadow: 0 8px 30px rgba(0,0,0,0.08);
            margin-top: 2.5rem;
            border: 2px solid rgba(102, 126, 234, 0.15);
        }
        
        .reviews-section h3 {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-top: 0;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.7rem;
            font-size: 1.8rem;
            font-weight: 700;
        }
        
        .loading-spinner {
            text-align: center;
            padding: 3rem;
        }
        
        .preview-loading {
            text-align: center;
            padding: 3rem;
        }
        
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .preview-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.7rem;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 0.8rem 1.5rem;
            border-radius: 30px;
            font-size: 1rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 15px rgba(245, 87, 108, 0.3);
            animation: gentle-pulse 2s ease-in-out infinite;
        }
        
        /* Preview Section Styles - Enhanced */
        .preview-section {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
            border-radius: 20px;
            padding: 2.5rem;
            margin-bottom: 2.5rem;
            border: 3px solid rgba(102, 126, 234, 0.3);
            box-shadow: 0 10px 40px rgba(102, 126, 234, 0.12);
            position: relative;
            overflow: visible;
            display: block !important;
        }
        
        .preview-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, #667eea 0%, #764ba2 50%, #667eea 100%);
            background-size: 200% 100%;
            animation: gradient-shift 3s ease infinite;
        }
        
        @keyframes gradient-shift {
            0%, 100% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
        }
        
        .preview-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 3px solid rgba(102, 126, 234, 0.2);
        }
        
        .preview-header h3 {
            display: flex;
            align-items: center;
            gap: 0.7rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 0;
            font-size: 1.8rem;
            font-weight: 700;
        }
        
        .preview-lock-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: linear-gradient(135deg, #ffd89b 0%, #fe9b45 100%);
            color: white;
            padding: 0.7rem 1.3rem;
            border-radius: 25px;
            font-size: 0.9rem;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(254, 155, 69, 0.3);
            animation: gentle-pulse 2s ease-in-out infinite;
        }
        
        @keyframes gentle-pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        
        .preview-content {
            position: relative;
            background: transparent;
            padding: 0;
            border-radius: 15px;
            margin-bottom: 2rem;
            margin-top: 2rem;
            display: block !important;
            visibility: visible !important;
        }
        
        .preview-pages {
            display: block !important;
            width: 100%;
            margin: 0;
            visibility: visible !important;
            position: relative;
        }
        
        .preview-page {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            border: 3px solid #667eea;
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.2);
            transition: all 0.3s ease;
            position: relative;
            overflow: visible;
            display: none !important;
            visibility: visible !important;
            opacity: 1 !important;
            min-height: 200px;
            margin-bottom: 0;
        }
        
        .preview-page.active {
            display: block !important;
        }
        
        .preview-navigation {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 2rem;
            gap: 1rem;
        }
        
        .preview-nav-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 1rem 2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .preview-nav-btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .preview-nav-btn:disabled {
            background: linear-gradient(135deg, #cbd5e0 0%, #a0aec0 100%);
            cursor: not-allowed;
            opacity: 0.6;
        }
        
        .preview-page-indicator {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            font-size: 1rem;
            font-weight: 600;
            color: #2c3e50;
        }
        
        .preview-page-dots {
            display: flex;
            gap: 0.5rem;
        }
        
        .preview-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #cbd5e0;
            transition: all 0.3s ease;
        }
        
        .preview-dot.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            transform: scale(1.2);
        }
        
        .preview-page::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
        }
        
        .preview-page:hover {
            transform: translateX(5px);
            box-shadow: 0 8px 30px rgba(102, 126, 234, 0.15);
            border-color: rgba(102, 126, 234, 0.3);
        }
        
        .preview-page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.2rem;
            padding-bottom: 0.8rem;
            border-bottom: 2px solid #e9ecef;
        }
        
        .page-number {
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-size: 1rem;
        }
        
        .preview-page-content {
            color: #2c3e50;
            line-height: 1.9;
            font-size: 0.98rem;
            display: block;
            visibility: visible;
        }
        
        .preview-page-content h4 {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-top: 0;
            margin-bottom: 0.8rem;
            font-size: 1.3rem;
            font-weight: 700;
        }
        
        .preview-page-content ul {
            margin: 1rem 0;
            padding-left: 1.5rem;
        }
        
        .preview-page-content li {
            margin-bottom: 0.6rem;
            padding-left: 0.5rem;
        }
        
        .preview-page-content li::marker {
            color: #667eea;
        }
        
        .preview-page-content canvas {
            display: block;
            margin: 0 auto;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
        
        .preview-blur-overlay {
            position: relative;
        }
        
        .preview-blur-overlay::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 120px;
            background: linear-gradient(to bottom, transparent, white);
            pointer-events: none;
        }
        
        .locked-content {
            position: relative;
            filter: blur(6px);
            user-select: none;
            pointer-events: none;
            opacity: 0.6;
        }
        
        .unlock-overlay {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            z-index: 10;
        }
        
        .unlock-icon {
            font-size: 5rem;
            margin-bottom: 1rem;
            animation: unlock-pulse 2s ease-in-out infinite;
            filter: drop-shadow(0 5px 15px rgba(102, 126, 234, 0.4));
        }
        
        @keyframes unlock-pulse {
            0%, 100% { transform: scale(1) rotate(0deg); }
            25% { transform: scale(1.1) rotate(-5deg); }
            75% { transform: scale(1.1) rotate(5deg); }
        }
        
        .unlock-text {
            background: white;
            padding: 2rem 2.5rem;
            border-radius: 20px;
            box-shadow: 0 15px 50px rgba(0,0,0,0.25);
            border: 3px solid rgba(102, 126, 234, 0.2);
        }
        
        .unlock-text h4 {
            margin: 0 0 0.7rem 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .unlock-text p {
            margin: 0 0 1.5rem 0;
            color: #6c757d;
            font-size: 1rem;
        }
        
        .btn-unlock {
            display: inline-flex;
            align-items: center;
            gap: 0.7rem;
            padding: 1rem 2.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 15px;
            font-weight: 700;
            font-size: 1.1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-unlock:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.5);
        }
        
        .preview-info {
            display: flex;
            justify-content: center;
            gap: 3rem;
            padding: 1.8rem;
            background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
            border-radius: 15px;
            text-align: center;
            border: 2px solid rgba(102, 126, 234, 0.15);
        }
        
        .preview-info-item {
            display: flex;
            flex-direction: column;
        }
        
        .preview-info-item strong {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            font-size: 0.9rem;
            margin-bottom: 0.5rem;
            font-weight: 700;
        }
        
        .preview-info-item span {
            color: #2c3e50;
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        @media (max-width: 968px) {
            .note-detail-grid {
                grid-template-columns: 1fr;
            }
            
            .note-sidebar {
                position: static;
            }
            
            .info-grid {
                grid-template-columns: 1fr;
            }
            
            .note-title {
                font-size: 2rem;
            }
        }
        
        /* Pulse animation for purchase button */
        @keyframes pulse-scale {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.05);
            }
        }
        
        .pulse-animation {
            animation: pulse-scale 0.5s ease-in-out 3;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>KwikPaper</h1>
            </div>
            <nav>
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <a href="upload.php">Upload</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="dashboard.php">Dashboard</a>
                <?php endif; ?>
            </nav>
            <div class="nav-search">
                <input type="text" placeholder="Search notes..." id="navSearch">
            </div>
            <nav class="nav-right">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <span class="user-welcome">👋 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <a href="dashboard.php" class="btn-dashboard">Dashboard</a>
                    <a href="api/auth/logout.php" class="btn-logout">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="btn-login">Login</a>
                    <a href="register.php" class="btn-register">Register</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <div class="breadcrumb">
        <div class="container">
            <div class="breadcrumb-nav">
                <a href="index.php">Home</a>
                <span>›</span>
                <a href="browse.php">Browse Notes</a>
                <span>›</span>
                <span id="breadcrumbTitle">Note Details</span>
            </div>
        </div>
    </div>

    <section class="note-detail-section">
        <div class="container">
            <div id="noteDetailContainer" class="loading-spinner">
                <div class="spinner"></div>
                <p>Loading note details...</p>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">How It Works</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Twitter</a></li>
                        <li><a href="#">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
    <script>
        const noteId = <?php echo $note_id; ?>;
        
        async function loadNoteDetails() {
            const result = await NotesAPI.getDetail(noteId);
            const container = document.getElementById('noteDetailContainer');
            
            if (result.success && result.data) {
                const note = result.data;
                document.title = note.title + ' - KwikPaper';
                document.getElementById('breadcrumbTitle').textContent = note.title;
                
                container.innerHTML = `
                    <div class="note-detail-grid">
                        <!-- Main Content -->
                        <div class="note-main-content">
                            <div class="preview-badge">
                                <span>🔥</span>
                                <span>Premium Quality Notes</span>
                            </div>
                            
                            <h1 class="note-title">${note.title}</h1>
                            
                            <div class="note-meta-badges">
                                <div class="badge category">
                                    <span>📚</span>
                                    <span>${note.category}</span>
                                </div>
                                <div class="badge rating">
                                    <span>⭐</span>
                                    <span>${note.rating || '5.0'} (${note.total_ratings || 0} reviews)</span>
                                </div>
                                <div class="badge downloads">
                                    <span>🛒</span>
                                    <span>${note.purchased_count || 0} purchased</span>
                                </div>
                                <div class="badge views">
                                    <span>👁️</span>
                                    <span>${note.views || 0} views</span>
                                </div>
                            </div>
                            
                            <div class="author-info">
                                <div class="author-avatar">${note.avatar || '👤'}</div>
                                <div class="author-details">
                                    <h4>${note.username}</h4>
                                    <p>Verified Seller • ${note.subject || 'Academic Expert'}</p>
                                </div>
                            </div>
                            
                            <!-- Preview Section -->
                            <div class="preview-section">
                                <div class="preview-header">
                                    <h3>👁️ Notes Preview</h3>
                                    <span class="preview-lock-badge">
                                        <span>🔒</span>
                                        <span>Purchase to unlock full content</span>
                                    </span>
                                </div>
                                
                                <div class="preview-info">
                                    <div class="preview-info-item">
                                        <strong>📄 Total Pages</strong>
                                        <span>${note.pages || 10} pages</span>
                                    </div>
                                    <div class="preview-info-item">
                                        <strong>👀 Preview</strong>
                                        <span>First 3 pages</span>
                                    </div>
                                    <div class="preview-info-item">
                                        <strong>📊 Topics Covered</strong>
                                        <span>${note.pages ? Math.ceil(note.pages / 3) : 5}+ topics</span>
                                    </div>
                                </div>
                                
                                <div class="preview-content">
                                    <div id="pdfPreviewContainer" class="preview-pages">
                                        <!-- PDF pages will be rendered here -->
                                        <div class="preview-loading" id="previewLoading">
                                            <div class="spinner"></div>
                                            <p>Loading preview pages...</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div style="text-align: center; margin-top: 2rem; padding: 1.8rem; background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%); border-radius: 15px; border: 2px solid rgba(102, 126, 234, 0.2);">
                                    <p style="color: #2c3e50; margin: 0; font-size: 1.05rem; font-weight: 600; line-height: 1.6;">
                                        ✨ <strong style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">Purchase once, access forever!</strong> Get instant download of all ${note.pages || 10} pages with lifetime access.
                                    </p>
                                </div>
                            </div>
                            
                            <div class="description-section">
                                <h3>📝 Description</h3>
                                <p>${note.description || 'No description available'}</p>
                                
                                <div class="info-grid">
                                    ${note.pages ? `
                                        <div class="info-item">
                                            <strong>📄 Pages</strong>
                                            <span>${note.pages} pages</span>
                                        </div>
                                    ` : ''}
                                    <div class="info-item">
                                        <strong>📂 Category</strong>
                                        <span>${note.category}</span>
                                    </div>
                                    ${note.university ? `
                                        <div class="info-item">
                                            <strong>🎓 University</strong>
                                            <span>${note.university}</span>
                                        </div>
                                    ` : ''}
                                    <div class="info-item">
                                        <strong>📅 Upload Date</strong>
                                        <span>${note.created_at ? new Date(note.created_at).toLocaleDateString() : 'Recently'}</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="reviews-section">
                                <h3>⭐ Student Reviews</h3>
                                <p style="color: #6c757d; margin-bottom: 1.5rem;">
                                    ${note.total_ratings || 0} students have reviewed these notes
                                </p>
                                
                                ${note.total_ratings > 0 ? `
                                    <div style="text-align: center; padding: 2rem; background: #f8f9fa; border-radius: 10px;">
                                        <p style="color: #6c757d;">Reviews will be displayed here</p>
                                    </div>
                                ` : `
                                    <div style="text-align: center; padding: 2rem; background: #f8f9fa; border-radius: 10px;">
                                        <p style="color: #6c757d;">Be the first to review these notes!</p>
                                    </div>
                                `}
                            </div>
                        </div>
                        
                        <!-- Sidebar -->
                        <div class="note-sidebar">
                            <div class="purchase-card">
                                ${(note.is_free || !note.price || parseFloat(note.price) === 0) ? `
                                    <div class="price-display" style="background: linear-gradient(135deg, rgba(67, 233, 123, 0.2) 0%, rgba(56, 249, 215, 0.2) 100%);">
                                        <div class="price-label">🎁 Free Note</div>
                                        <div class="price-amount" style="font-size: 2.5rem; color: #065c3b; font-weight: 700;">FREE</div>
                                    </div>
                                    
                                    <div class="purchase-features">
                                        <div class="feature-item">
                                            <span class="feature-icon">✅</span>
                                            <span class="feature-text">View Complete Content</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon">🎯</span>
                                            <span class="feature-text">No Payment Required</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon">📱</span>
                                            <span class="feature-text">Access from My Notes</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon">💚</span>
                                            <span class="feature-text">View Anytime Online</span>
                                        </div>
                                    </div>
                                    
                                    <button onclick="addFreeNoteToLibrary(${note.id})" class="btn-purchase" style="background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: #065c3b;">
                                        �️ View Full Note (Free)
                                    </button>
                                ` : `
                                    <div class="price-display">
                                        <div class="price-label">Price</div>
                                        <div class="price-amount">${Utils.formatPrice(note.price)}</div>
                                    </div>
                                    
                                    <div class="purchase-features">
                                        <div class="feature-item">
                                            <span class="feature-icon">✅</span>
                                            <span class="feature-text">View Complete Content</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon">🔒</span>
                                            <span class="feature-text">Secure Payment</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon">💯</span>
                                            <span class="feature-text">Money Back Guarantee</span>
                                        </div>
                                        <div class="feature-item">
                                            <span class="feature-icon">📱</span>
                                            <span class="feature-text">Access from My Notes</span>
                                        </div>
                                    </div>
                                    
                                    <button onclick="purchaseNote(${note.id})" class="btn-purchase">
                                        �️ Purchase to View
                                    </button>
                                `}
                                </button>
                                
                                <button onclick="location.href='profile.php?id=${note.user_id}'" class="btn-contact-seller">
                                    👤 View Seller Profile
                                </button>
                            </div>
                            
                            <div class="seller-card">
                                <h3>👨‍🎓 About the Seller</h3>
                                <div class="author-info" style="margin-bottom: 0;">
                                    <div class="author-avatar">${note.avatar || '👤'}</div>
                                    <div class="author-details">
                                        <h4>${note.username}</h4>
                                        <p>${note.subject || 'Academic Expert'}</p>
                                    </div>
                                </div>
                                
                                <div class="seller-stats">
                                    <div class="stat-box">
                                        <span class="stat-number">${note.total_notes || 1}</span>
                                        <span class="stat-label">Notes</span>
                                    </div>
                                    <div class="stat-box">
                                        <span class="stat-number">${note.rating || '5.0'}</span>
                                        <span class="stat-label">Rating</span>
                                    </div>
                                    <div class="stat-box">
                                        <span class="stat-number">${note.purchased_count || 0}</span>
                                        <span class="stat-label">Purchased</span>
                                    </div>
                                    <div class="stat-box">
                                        <span class="stat-number">100%</span>
                                        <span class="stat-label">Positive</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
                
                // Always show only preview (3 pages) on note-detail page
                // Full note access is available through view-note.php after adding to library
                if (note.file_path) {
                    setTimeout(() => {
                        renderPDFPreview(note.file_path, note.pages, false);
                    }, 100);
                } else {
                    // No file uploaded
                    const container = document.getElementById('pdfPreviewContainer');
                    if (container) {
                        container.innerHTML = `
                            <div class="preview-page" style="text-align: center; padding: 3rem;">
                                <div style="font-size: 3rem; margin-bottom: 1rem;">📝</div>
                                <h4>No Preview Available</h4>
                                <p style="color: #6c757d;">This note doesn't have a preview file uploaded yet.</p>
                                <p style="margin-top: 1rem; font-size: 0.9rem;">Contact the seller for more information.</p>
                            </div>
                        `;
                    }
                }
            } else {
                container.innerHTML = `
                    <div style="text-align: center; padding: 60px; background: white; border-radius: 15px; box-shadow: 0 2px 15px rgba(0,0,0,0.06);">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">😢</div>
                        <h2 style="color: #2c3e50; margin-bottom: 1rem;">Note Not Found</h2>
                        <p style="color: #6c757d; margin-bottom: 2rem;">The note you're looking for doesn't exist or has been removed.</p>
                        <button onclick="location.href='browse.php'" class="btn-purchase" style="width: auto; padding: 1rem 2rem;">
                            📚 Browse All Notes
                        </button>
                    </div>
                `;
            }
        }
        
        // PDF Preview Rendering Function
        async function renderPDFPreview(filePath, totalPages, hasFullAccess = false) {
            const container = document.getElementById('pdfPreviewContainer');
            const loading = document.getElementById('previewLoading');
            
            // Convert database path to web-accessible path
            // Database stores: ../../uploads/notes/file.pdf (from api/notes/)
            // We need: uploads/notes/file.pdf (from root)
            if (filePath && filePath.startsWith('../../uploads/')) {
                filePath = filePath.replace('../../', '');
            }
            
            if (!filePath || !filePath.endsWith('.pdf')) {
                container.innerHTML = `
                    <div class="preview-page" style="text-align: center; padding: 3rem;">
                        <div style="font-size: 3rem; margin-bottom: 1rem;">📄</div>
                        <h4>Preview Not Available</h4>
                        <p style="color: #6c757d;">PDF preview is only available for PDF files.</p>
                        <p style="margin-top: 1rem;"><strong>File type:</strong> ${filePath ? filePath.split('.').pop().toUpperCase() : 'Unknown'}</p>
                    </div>
                `;
                return;
            }
            
            // Configure PDF.js worker
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
            
            console.log('Loading PDF from:', filePath, 'Full access:', hasFullAccess);
            
            try {
                // Load the PDF
                const pdf = await pdfjsLib.getDocument(filePath).promise;
                // Show all pages if user has access, otherwise show first 3 pages
                const numPages = hasFullAccess ? pdf.numPages : Math.min(3, pdf.numPages);
                
                console.log('PDF loaded successfully. Total pages:', pdf.numPages, 'Showing:', numPages);
                
                // Clear loading message
                container.innerHTML = '';
                
                // Render first 3 pages
                for (let pageNum = 1; pageNum <= numPages; pageNum++) {
                    const page = await pdf.getPage(pageNum);
                    
                    // Create canvas for this page
                    const canvas = document.createElement('canvas');
                    const context = canvas.getContext('2d');
                    
                    // Calculate scale to fit width
                    const viewport = page.getViewport({ scale: 1.5 });
                    canvas.width = viewport.width;
                    canvas.height = viewport.height;
                    
                    // Render PDF page to canvas
                    await page.render({
                        canvasContext: context,
                        viewport: viewport
                    }).promise;
                    
                    // Create preview page container
                    const pageContainer = document.createElement('div');
                    pageContainer.className = 'preview-page' + (pageNum === 1 ? ' active' : '');
                    pageContainer.setAttribute('data-page', pageNum);
                    pageContainer.innerHTML = `
                        <div class=\"preview-page-header\">
                            <span class=\"page-number\">📄 Page ${pageNum} of ${totalPages || pdf.numPages}</span>
                        </div>
                        <div class=\"preview-page-content\" style=\"text-align: center; padding: 0;\">
                        </div>
                    `;
                    
                    // Add canvas to page content
                    const content = pageContainer.querySelector('.preview-page-content');
                    canvas.style.maxWidth = '100%';
                    canvas.style.height = 'auto';
                    canvas.style.border = '1px solid #e9ecef';
                    canvas.style.borderRadius = '8px';
                    content.appendChild(canvas);
                    
                    container.appendChild(pageContainer);
                }
                
                // Add navigation controls after all pages
                const navControls = document.createElement('div');
                navControls.className = 'preview-navigation';
                navControls.innerHTML = `
                    <button class=\"preview-nav-btn\" id=\"prevPageBtn\" onclick=\"changePreviewPage(-1)\">
                        <span>⬅️</span>
                        <span>Previous</span>
                    </button>
                    <div class=\"preview-page-indicator\">
                        <div class=\"preview-page-dots\">
                            ${Array.from({length: numPages}, (_, i) => 
                                `<span class=\"preview-dot ${i === 0 ? 'active' : ''}\" data-dot=\"${i + 1}\"></span>`
                            ).join('')}
                        </div>
                        <span id=\"pageIndicator\">Page <strong>1</strong> of <strong>${numPages}</strong></span>
                    </div>
                    <button class=\"preview-nav-btn\" id=\"nextPageBtn\" onclick=\"changePreviewPage(1)\">
                        <span>Next</span>
                        <span>➡️</span>
                    </button>
                `;
                container.appendChild(navControls);
                
                // Initialize page navigation state
                window.currentPreviewPage = 1;
                window.totalPreviewPages = numPages;
                updateNavigationButtons();
                
                // Add locked preview for remaining pages
                if (pdf.numPages > 3) {
                    const lockedPreview = document.createElement('div');
                    lockedPreview.className = 'preview-page preview-blur-overlay';
                    lockedPreview.style.position = 'relative';
                    lockedPreview.style.minHeight = '400px';
                    lockedPreview.innerHTML = `
                        <div class=\"preview-page-content locked-content\" style=\"text-align: center; padding: 3rem;\">
                            <h4>More Pages Available</h4>
                            <p>This document contains ${pdf.numPages} total pages with comprehensive content covering all topics.</p>
                            <ul style=\"text-align: left; max-width: 500px; margin: 2rem auto;\">
                                <li>Detailed explanations and examples</li>
                                <li>Step-by-step problem solutions</li>
                                <li>Practice exercises and assessments</li>
                                <li>Summary notes and key takeaways</li>
                            </ul>
                        </div>
                        <div class=\"unlock-overlay\">
                            <div class=\"unlock-icon\">🔐</div>
                            <div class=\"unlock-text\">
                                <h4>🎓 Unlock ${pdf.numPages - 3} More Pages</h4>
                                <p>Get complete access to view all pages on this site!</p>
                                <button onclick=\"document.querySelector('.btn-purchase').scrollIntoView({behavior: 'smooth', block: 'center'}); setTimeout(() => document.querySelector('.btn-purchase').classList.add('pulse-animation'), 500);\" class=\"btn-unlock\">
                                    <span>📚</span>
                                    <span>Get Access</span>
                                </button>
                            </div>
                        </div>
                    `;
                    container.appendChild(lockedPreview);
                }
                
            } catch (error) {
                console.error('Error loading PDF:', error);
                container.innerHTML = `
                    <div class=\"preview-page\" style=\"text-align: center; padding: 3rem;\">
                        <div style=\"font-size: 3rem; margin-bottom: 1rem;\">⚠️</div>
                        <h4>Preview Loading Error</h4>
                        <p style=\"color: #6c757d;\">Unable to load PDF preview. The file may be corrupted or inaccessible.</p>
                        <p style=\"margin-top: 1rem; font-size: 0.9rem;\">Error: ${error.message}</p>
                    </div>
                `;
            }
        }
        
        function addFreeNoteToLibrary(noteId) {
            <?php if(isset($_SESSION['user_id'])): ?>
                // For free notes, add to library and redirect to full viewer
                console.log('Adding free note to library:', noteId);
                
                // Call API to add note to user's library
                fetch('api/notes/add-to-library.php?id=' + noteId, {
                    method: 'GET',
                    credentials: 'include'
                })
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        // Redirect to full note viewer
                        window.location.href = 'view-note.php?id=' + noteId;
                    } else {
                        alert('❌ ' + (data.message || 'Failed to add note to library'));
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('❌ An error occurred. Please try again.');
                });
            <?php else: ?>
                alert('🔐 Please login to get this note');
                window.location.href = 'login.php?redirect=' + encodeURIComponent(window.location.pathname + window.location.search);
            <?php endif; ?>
        }
        
        function purchaseNote(noteId) {
            <?php if(isset($_SESSION['user_id'])): ?>
                // Show a nice modal or confirmation
                if (confirm('🎉 Ready to purchase these notes?\n\nYou will be redirected to secure payment gateway.')) {
                    alert('💳 Payment functionality will be integrated with payment gateway.\n\nFor now, this is a demo message.');
                }
            <?php else: ?>
                alert('🔐 Please login to purchase notes');
                window.location.href = 'login.php?redirect=' + encodeURIComponent(window.location.pathname + window.location.search);
            <?php endif; ?>
        }
        
        // Preview page navigation functions
        function changePreviewPage(direction) {
            const newPage = window.currentPreviewPage + direction;
            
            if (newPage < 1 || newPage > window.totalPreviewPages) {
                return;
            }
            
            // Hide current page
            const currentPageEl = document.querySelector('.preview-page.active');
            if (currentPageEl) {
                currentPageEl.classList.remove('active');
            }
            
            // Show new page
            const newPageEl = document.querySelector(`.preview-page[data-page="${newPage}"]`);
            if (newPageEl) {
                newPageEl.classList.add('active');
            }
            
            // Update dots
            document.querySelectorAll('.preview-dot').forEach(dot => {
                dot.classList.remove('active');
            });
            const activeDot = document.querySelector(`.preview-dot[data-dot="${newPage}"]`);
            if (activeDot) {
                activeDot.classList.add('active');
            }
            
            // Update current page
            window.currentPreviewPage = newPage;
            
            // Update indicator text
            const indicator = document.getElementById('pageIndicator');
            if (indicator) {
                indicator.innerHTML = `Page <strong>${newPage}</strong> of <strong>${window.totalPreviewPages}</strong>`;
            }
            
            // Update buttons
            updateNavigationButtons();
            
            // Scroll to preview section smoothly
            const previewSection = document.querySelector('.preview-section');
            if (previewSection) {
                previewSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        }
        
        function updateNavigationButtons() {
            const prevBtn = document.getElementById('prevPageBtn');
            const nextBtn = document.getElementById('nextPageBtn');
            
            if (prevBtn) {
                prevBtn.disabled = window.currentPreviewPage === 1;
            }
            
            if (nextBtn) {
                nextBtn.disabled = window.currentPreviewPage === window.totalPreviewPages;
            }
        }
        
        // Load note details on page load
        loadNoteDetails();
    </script>
</body>
</html>
