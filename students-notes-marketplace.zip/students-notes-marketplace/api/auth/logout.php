<?php
/**
 * User Logout API Endpoint
 * POST: api/auth/logout.php
 * GET: Direct browser logout
 */

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Destroy session
session_unset();
session_destroy();

// Check if this is an API call or direct browser request
$isApiCall = isset($_SERVER['HTTP_X_REQUESTED_WITH']) || 
             (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false);

if ($isApiCall) {
    // API response
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST, GET");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => "Logged out successfully"
    ]);
} else {
    // Direct browser request - redirect to home page
    header("Location: ../../index.php");
    exit();
}
?>
