<?php
/**
 * Check Session API Endpoint
 * GET: api/auth/session.php
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../models/User.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if(isset($_SESSION['user_id'])) {
    $database = new Database();
    $db = $database->getConnection();
    $user = new User($db);
    
    $userData = $user->getUserById($_SESSION['user_id']);
    
    if($userData) {
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "logged_in" => true,
            "user" => $userData
        ]);
    } else {
        http_response_code(401);
        echo json_encode([
            "success" => false,
            "logged_in" => false,
            "message" => "Invalid session"
        ]);
    }
} else {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "logged_in" => false,
        "message" => "Not logged in"
    ]);
}
?>
