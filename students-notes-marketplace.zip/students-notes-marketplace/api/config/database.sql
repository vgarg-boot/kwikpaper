-- Database Creation Script for Notes Marketplace

CREATE DATABASE IF NOT EXISTS notes_marketplace;
USE notes_marketplace;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    avatar VARCHAR(10) DEFAULT '👤',
    bio TEXT,
    university VARCHAR(100),
    year VARCHAR(20),
    subject VARCHAR(100),
    notes_uploaded INT DEFAULT 0,
    notes_purchased INT DEFAULT 0,
    earnings DECIMAL(10, 2) DEFAULT 0.00,
    join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    active TINYINT(1) DEFAULT 1,
    INDEX idx_username (username),
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Notes Table
CREATE TABLE IF NOT EXISTS notes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    is_free TINYINT(1) DEFAULT 0,
    file_path VARCHAR(255),
    file_size INT,
    pages INT,
    downloads INT DEFAULT 0,
    views INT DEFAULT 0,
    rating DECIMAL(3, 2) DEFAULT 0.00,
    total_ratings INT DEFAULT 0,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'approved',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_is_free (is_free),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Purchases Table
CREATE TABLE IF NOT EXISTS purchases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    note_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE,
    UNIQUE KEY unique_purchase (user_id, note_id),
    INDEX idx_user_id (user_id),
    INDEX idx_note_id (note_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Reviews Table
CREATE TABLE IF NOT EXISTS reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    note_id INT NOT NULL,
    user_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_review (note_id, user_id),
    INDEX idx_note_id (note_id),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sessions Table (for session management)
CREATE TABLE IF NOT EXISTS sessions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_session_token (session_token),
    INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample data
INSERT INTO users (username, email, password, avatar, bio, university, year, subject, notes_uploaded, earnings) VALUES
('sarahw', 'sarah@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '👩‍🎓', 'Passionate Biology and Chemistry student', 'Stanford University', 'Senior', 'Biology & Chemistry Specialist', 47, 1247.00),
('alexj', 'alex@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '👨‍🎓', 'Computer Science major with a passion for algorithms', 'MIT', 'Junior', 'Computer Science Specialist', 38, 1089.00),
('emmar', 'emma@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '👩‍🎓', 'Mathematics and Physics enthusiast', 'Caltech', 'Senior', 'Mathematics & Physics Specialist', 52, 986.00);

INSERT INTO notes (user_id, title, description, category, price, is_free, pages, downloads, views, rating, total_ratings) VALUES
(1, 'Biology 101 Complete Notes', 'Comprehensive notes covering all chapters. Perfect for exam prep.', 'science', 15.99, 0, 120, 234, 1247, 4.9, 47),
(2, 'Data Structures and Algorithms', 'Complete guide with code examples and explanations.', 'cs', 19.99, 0, 95, 189, 986, 4.8, 38),
(3, 'Calculus II Full Course', 'Step-by-step solutions and detailed explanations.', 'math', 17.99, 0, 150, 298, 1543, 4.9, 52),
(1, 'Introduction to Chemistry - Free', 'Basic chemistry concepts for beginners. Free to download!', 'science', 0, 1, 45, 567, 2341, 4.7, 123),
(2, 'Programming Basics Guide', 'Learn programming fundamentals. Community contribution - completely free!', 'cs', 0, 1, 30, 892, 3456, 4.8, 201),
(3, 'Algebra Quick Reference', 'Essential algebra formulas and examples. Free for all students!', 'math', 0, 1, 25, 445, 1876, 4.6, 87);
