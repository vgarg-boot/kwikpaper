<?php
/**
 * Get Popular Notes API Endpoint (Top 10 by downloads)
 * GET: api/notes/featured.php?limit=10
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../models/Note.php';

$database = new Database();
$db = $database->getConnection();
$note = new Note($db);

// Get limit parameter (default 10 for popular notes)
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;

// Get popular notes (top by downloads)
$notes = $note->getFeatured($limit);

http_response_code(200);
echo json_encode([
    "success" => true,
    "data" => $notes,
    "count" => count($notes)
]);
?>
