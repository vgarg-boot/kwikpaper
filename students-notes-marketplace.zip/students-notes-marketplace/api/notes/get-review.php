<?php
/**
 * Get User Review API Endpoint
 * GET: api/notes/get-review.php?note_id=X
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Please login to view reviews"
    ]);
    exit();
}

if(!isset($_GET['note_id'])) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Note ID is required"
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];
$note_id = (int)$_GET['note_id'];

$database = new Database();
$db = $database->getConnection();

$query = "SELECT rating, comment, created_at 
          FROM reviews 
          WHERE user_id = :user_id AND note_id = :note_id";

$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $user_id);
$stmt->bindParam(':note_id', $note_id);
$stmt->execute();

if($stmt->rowCount() > 0) {
    $review = $stmt->fetch(PDO::FETCH_ASSOC);
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "data" => $review
    ]);
} else {
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "data" => null
    ]);
}
?>
