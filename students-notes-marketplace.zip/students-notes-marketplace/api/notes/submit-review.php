<?php
/**
 * Submit Review API Endpoint
 * POST: api/notes/submit-review.php
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Please login to submit a review"
    ]);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents("php://input"));

if(!isset($data->note_id) || !isset($data->rating)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Note ID and rating are required"
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];
$note_id = (int)$data->note_id;
$rating = (int)$data->rating;
$comment = isset($data->comment) ? trim($data->comment) : '';

// Validate rating
if($rating < 1 || $rating > 5) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Rating must be between 1 and 5"
    ]);
    exit();
}

$database = new Database();
$db = $database->getConnection();

// Check if note exists
$note_query = "SELECT id, user_id FROM notes WHERE id = :note_id";
$note_stmt = $db->prepare($note_query);
$note_stmt->bindParam(':note_id', $note_id);
$note_stmt->execute();

if($note_stmt->rowCount() == 0) {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "Note not found"
    ]);
    exit();
}

$note = $note_stmt->fetch(PDO::FETCH_ASSOC);

// Check if user owns the note (can't review own notes)
if($note['user_id'] == $user_id) {
    http_response_code(403);
    echo json_encode([
        "success" => false,
        "message" => "You cannot review your own notes"
    ]);
    exit();
}

// Check if user has purchased/downloaded this note
$purchase_query = "SELECT id FROM purchases WHERE user_id = :user_id AND note_id = :note_id";
$purchase_stmt = $db->prepare($purchase_query);
$purchase_stmt->bindParam(':user_id', $user_id);
$purchase_stmt->bindParam(':note_id', $note_id);
$purchase_stmt->execute();

if($purchase_stmt->rowCount() == 0) {
    http_response_code(403);
    echo json_encode([
        "success" => false,
        "message" => "You must purchase or download this note before reviewing it"
    ]);
    exit();
}

// Check if review already exists
$check_query = "SELECT id FROM reviews WHERE user_id = :user_id AND note_id = :note_id";
$check_stmt = $db->prepare($check_query);
$check_stmt->bindParam(':user_id', $user_id);
$check_stmt->bindParam(':note_id', $note_id);
$check_stmt->execute();

try {
    if($check_stmt->rowCount() > 0) {
        // Update existing review
        $update_query = "UPDATE reviews SET rating = :rating, comment = :comment, created_at = NOW() 
                        WHERE user_id = :user_id AND note_id = :note_id";
        $update_stmt = $db->prepare($update_query);
        $update_stmt->bindParam(':rating', $rating);
        $update_stmt->bindParam(':comment', $comment);
        $update_stmt->bindParam(':user_id', $user_id);
        $update_stmt->bindParam(':note_id', $note_id);
        $update_stmt->execute();
        
        $message = "Review updated successfully";
    } else {
        // Insert new review
        $insert_query = "INSERT INTO reviews (note_id, user_id, rating, comment) 
                        VALUES (:note_id, :user_id, :rating, :comment)";
        $insert_stmt = $db->prepare($insert_query);
        $insert_stmt->bindParam(':note_id', $note_id);
        $insert_stmt->bindParam(':user_id', $user_id);
        $insert_stmt->bindParam(':rating', $rating);
        $insert_stmt->bindParam(':comment', $comment);
        $insert_stmt->execute();
        
        $message = "Review submitted successfully";
    }
    
    // Update note's average rating
    $avg_query = "UPDATE notes n 
                  SET rating = (SELECT AVG(rating) FROM reviews WHERE note_id = :note_id),
                      total_ratings = (SELECT COUNT(*) FROM reviews WHERE note_id = :note_id2)
                  WHERE id = :note_id3";
    $avg_stmt = $db->prepare($avg_query);
    $avg_stmt->bindParam(':note_id', $note_id);
    $avg_stmt->bindParam(':note_id2', $note_id);
    $avg_stmt->bindParam(':note_id3', $note_id);
    $avg_stmt->execute();
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => $message
    ]);
    
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Failed to submit review: " . $e->getMessage()
    ]);
}
?>
