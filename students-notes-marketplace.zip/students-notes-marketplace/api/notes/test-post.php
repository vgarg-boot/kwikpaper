<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

session_start();

// Debug endpoint - just shows what we received
error_log("=== TEST POST ENDPOINT ===");
error_log("Method: " . $_SERVER['REQUEST_METHOD']);
error_log("Content-Type: " . (isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : 'NOT SET'));
error_log("POST: " . json_encode($_POST));
error_log("FILES: " . json_encode(array_keys($_FILES)));
error_log("========================");

echo json_encode([
    "success" => true,
    "received" => [
        "method" => $_SERVER['REQUEST_METHOD'],
        "content_type" => isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : 'NOT SET',
        "post_count" => count($_POST),
        "post_keys" => array_keys($_POST),
        "post_data" => $_POST,
        "files_count" => count($_FILES),
        "files_keys" => array_keys($_FILES),
        "session_active" => isset($_SESSION),
        "user_logged_in" => isset($_SESSION['user_id'])
    ]
]);
?>
