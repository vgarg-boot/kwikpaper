<?php
/**
 * Get User's Notes API Endpoint
 * GET: api/notes/user-notes.php?user_id=1
 */

// Start session first before any output
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Credentials: true");

include_once '../config/database.php';
include_once '../models/Note.php';

$database = new Database();
$db = $database->getConnection();

if($db === null) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed"
    ]);
    exit();
}

$note = new Note($db);

// Get user ID from query parameter or session
$user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : null;

// If no user_id in query, try to get from session
if(!$user_id) {
    if(isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
    } else {
        http_response_code(401);
        echo json_encode([
            "success" => false,
            "message" => "User not authenticated"
        ]);
        exit();
    }
}

// Get notes
$notes = $note->getByUserId($user_id);

http_response_code(200);
echo json_encode([
    "success" => true,
    "data" => $notes,
    "count" => count($notes)
]);
?>
