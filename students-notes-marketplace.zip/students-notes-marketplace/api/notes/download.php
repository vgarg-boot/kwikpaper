<?php
/**
 * Download Note API Endpoint - DISABLED
 * Downloads are no longer available. Users can view full notes on the site.
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

// Download functionality has been disabled
http_response_code(403);
echo json_encode([
    "success" => false,
    "message" => "Download functionality is no longer available. Please view notes directly on the site by visiting the note detail page and adding them to your library."
]);
exit();
?>
