<?php
/**
 * Get Purchased/Downloaded Notes API Endpoint
 * Returns all notes purchased or downloaded (free) by the user
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Please login to view purchased notes"
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];

$database = new Database();
$db = $database->getConnection();

// Get all purchased/downloaded notes (including free downloads)
$query = "SELECT n.*, u.username, u.avatar, p.purchase_date, p.amount as paid_amount
          FROM purchases p
          INNER JOIN notes n ON p.note_id = n.id
          LEFT JOIN users u ON n.user_id = u.id
          WHERE p.user_id = :user_id
          ORDER BY p.purchase_date DESC";

$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();

$notes = [];
while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $notes[] = [
        'id' => $row['id'],
        'title' => $row['title'],
        'description' => $row['description'],
        'category' => $row['category'],
        'subject' => $row['subject'],
        'year' => $row['year'],
        'university' => $row['university'],
        'price' => $row['price'],
        'is_free' => $row['is_free'],
        'downloads' => $row['downloads'],
        'views' => $row['views'],
        'rating' => $row['rating'],
        'file_path' => $row['file_path'],
        'thumbnail' => $row['thumbnail'],
        'upload_date' => $row['upload_date'],
        'username' => $row['username'],
        'avatar' => $row['avatar'],
        'purchase_date' => $row['purchase_date'],
        'paid_amount' => $row['paid_amount']
    ];
}

http_response_code(200);
echo json_encode([
    "success" => true,
    "count" => count($notes),
    "data" => $notes
]);
?>
