﻿<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Notes - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        .upload-page {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            padding: 3rem 0;
            min-height: calc(100vh - 300px);
        }
        
        .upload-header {
            text-align: center;
            margin-bottom: 3rem;
        }
        
        .upload-header h2 {
            font-size: 2.5rem;
            color: #2c3e50;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .upload-header p {
            font-size: 1.1rem;
            color: #6c757d;
        }
        
        .upload-container {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 2rem;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .upload-form-section {
            background: white;
            border-radius: 15px;
            padding: 2.5rem;
            box-shadow: 0 5px 25px rgba(0,0,0,0.08);
        }
        
        .form-section-title {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.3rem;
            color: #2c3e50;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e9ecef;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #2c3e50;
            font-weight: 600;
            font-size: 0.95rem;
        }
        
        .form-group label .required {
            color: #e74c3c;
            margin-left: 3px;
        }
        
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 0.9rem 1rem;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            font-size: 1rem;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s;
            background: #f8f9fa;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 120px;
        }
        
        .file-upload-area {
            border: 3px dashed #667eea;
            border-radius: 15px;
            padding: 3rem 2rem;
            text-align: center;
            background: linear-gradient(135deg, #667eea05 0%, #764ba205 100%);
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
        }
        
        .file-upload-area:hover {
            border-color: #5568d3;
            background: linear-gradient(135deg, #667eea10 0%, #764ba210 100%);
            transform: translateY(-2px);
        }
        
        .file-upload-area.dragover {
            border-color: #5568d3;
            background: linear-gradient(135deg, #667eea20 0%, #764ba220 100%);
            transform: scale(1.02);
        }
        
        .file-upload-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
        }
        
        .file-upload-text h4 {
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .file-upload-text p {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .file-upload-area input[type="file"] {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            opacity: 0;
            cursor: pointer;
        }
        
        .file-preview {
            margin-top: 1rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 10px;
            display: none;
        }
        
        .file-preview.active {
            display: block;
        }
        
        .file-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .file-icon {
            font-size: 2.5rem;
        }
        
        .file-details h5 {
            margin: 0;
            color: #2c3e50;
            font-size: 1rem;
        }
        
        .file-details p {
            margin: 0.3rem 0 0 0;
            color: #6c757d;
            font-size: 0.85rem;
        }
        
        .file-remove {
            margin-left: auto;
            background: #e74c3c;
            color: white;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .file-remove:hover {
            background: #c0392b;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        
        .btn-upload {
            width: 100%;
            padding: 1.2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            margin-top: 1rem;
        }
        
        .btn-upload:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-upload:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .upload-sidebar {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        
        .sidebar-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
        }
        
        .sidebar-card h3 {
            color: #2c3e50;
            margin-top: 0;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.2rem;
        }
        
        .guideline-item {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.2rem;
            padding-bottom: 1.2rem;
            border-bottom: 1px solid #e9ecef;
        }
        
        .guideline-item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
            border-bottom: none;
        }
        
        .guideline-icon {
            font-size: 1.5rem;
            flex-shrink: 0;
        }
        
        .guideline-content h4 {
            margin: 0 0 0.3rem 0;
            color: #2c3e50;
            font-size: 0.95rem;
        }
        
        .guideline-content p {
            margin: 0;
            color: #6c757d;
            font-size: 0.85rem;
            line-height: 1.5;
        }
        
        .earnings-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-align: center;
        }
        
        .earnings-card h3 {
            color: white;
        }
        
        .earnings-amount {
            font-size: 2.5rem;
            font-weight: 700;
            margin: 1rem 0;
        }
        
        .earnings-text {
            font-size: 0.9rem;
            opacity: 0.9;
        }
        
        .char-counter {
            text-align: right;
            font-size: 0.85rem;
            color: #6c757d;
            margin-top: 0.3rem;
        }
        
        .form-help-text {
            font-size: 0.85rem;
            color: #6c757d;
            margin-top: 0.3rem;
        }
        
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: none;
            border-left: 4px solid #28a745;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: none;
            border-left: 4px solid #dc3545;
        }
        
        @media (max-width: 968px) {
            .upload-container {
                grid-template-columns: 1fr;
            }
            
            .form-row {
                grid-template-columns: 1fr;
            }
            
            .upload-header h2 {
                font-size: 2rem;
            }
            
            .upload-sidebar {
                order: -1;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>KwikPaper</h1>
            </div>
            <nav>
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <a href="upload.php">Upload</a>
                <a href="dashboard.php">Dashboard</a>
            </nav>
            <div class="nav-search">
                <input type="text" placeholder="Search notes..." id="navSearch">
            </div>
            <nav class="nav-right">
                <span class="user-welcome">👋 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <a href="dashboard.php" class="btn-dashboard">Dashboard</a>
                <a href="api/auth/logout.php" class="btn-logout">Logout</a>
            </nav>
        </div>
    </header>
    <section class="upload-page">
        <div class="container">
            <div class="upload-header">
                <h2>📤 Upload Your Notes</h2>
                <p>Share your knowledge with students worldwide and earn money!</p>
            </div>
            
            <div class="upload-container">
                <!-- Main Upload Form -->
                <div class="upload-form-section">
                    <div class="success-message" id="successMessage">
                        ✅ Your notes have been uploaded successfully!
                    </div>
                    <div class="error-message" id="errorMessage">
                        ❌ <span id="errorText"></span>
                    </div>
                    
                    <form id="uploadForm" class="upload-form-page">
                        <!-- Basic Information -->
                        <div class="form-section-title">
                            📝 Basic Information
                        </div>
                        
                        <div class="form-group">
                            <label for="noteTitle">
                                Title<span class="required">*</span>
                            </label>
                            <input type="text" 
                                   id="noteTitle" 
                                   name="title" 
                                   placeholder="e.g., Biology 101 Complete Notes - Cell Structure & Functions"
                                   maxlength="100"
                                   required>
                            <div class="char-counter">
                                <span id="titleCounter">0</span>/100 characters
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="noteCategory">
                                Category<span class="required">*</span>
                            </label>
                            <select id="noteCategory" name="category" required>
                                <option value="" disabled selected>📚 Select a category</option>
                                <option value="science">🔬 Science</option>
                                <option value="math">➗ Mathematics</option>
                                <option value="history">📜 History</option>
                                <option value="language">🗣️ Language</option>
                                <option value="cs">💻 Computer Science</option>
                                <option value="engineering">⚙️ Engineering</option>
                                <option value="business">💼 Business</option>
                                <option value="arts">🎨 Arts</option>
                                <option value="other">📋 Other</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="noteDescription">
                                Description<span class="required">*</span>
                            </label>
                            <textarea id="noteDescription" 
                                      name="description" 
                                      rows="6" 
                                      placeholder="Describe what your notes include... Be specific about topics covered, quality of content, and what makes your notes valuable."
                                      maxlength="1000"
                                      required></textarea>
                            <div class="char-counter">
                                <span id="descCounter">0</span>/1000 characters
                            </div>
                        </div>
                        
                        <!-- File Upload -->
                        <div class="form-section-title" style="margin-top: 2rem;">
                            📎 Upload File
                        </div>
                        
                        <div class="form-group">
                            <div class="file-upload-area" id="fileUploadArea">
                                <div class="file-upload-icon">📄</div>
                                <div class="file-upload-text">
                                    <h4>Drag & Drop your file here</h4>
                                    <p>or click to browse</p>
                                    <p style="margin-top: 0.5rem; font-size: 0.8rem;">Supported formats: PDF, DOC, DOCX, TXT (Max 50MB)</p>
                                </div>
                                <input type="file" 
                                       id="noteFile" 
                                       name="file" 
                                       accept=".pdf,.docx,.doc,.txt">
                            </div>
                            
                            <div class="file-preview" id="filePreview">
                                <div class="file-info">
                                    <div class="file-icon" id="fileIcon">📄</div>
                                    <div class="file-details">
                                        <h5 id="fileName">document.pdf</h5>
                                        <p id="fileSize">2.5 MB</p>
                                    </div>
                                    <button type="button" class="file-remove" id="fileRemove">Remove</button>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Pricing & Details -->
                        <div class="form-section-title" style="margin-top: 2rem;">
                            💰 Pricing & Details
                        </div>
                        
                        <div class="form-group">
                            <label>Note Type<span class="required">*</span></label>
                            <div style="display: flex; gap: 2rem; margin-top: 0.8rem;">
                                <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-weight: normal;">
                                    <input type="radio" name="noteType" id="typePaid" value="paid" checked>
                                    <span>💵 Paid Note</span>
                                </label>
                                <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-weight: normal;">
                                    <input type="radio" name="noteType" id="typeFree" value="free">
                                    <span>🎁 Free Note</span>
                                </label>
                            </div>
                            <p class="form-help-text">Choose whether to share for free or set a price</p>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group" id="priceGroup">
                                <label for="notePrice">
                                    Price (USD)<span class="required">*</span>
                                </label>
                                <input type="number" 
                                       id="notePrice" 
                                       name="price" 
                                       placeholder="9.99" 
                                       min="0" 
                                       step="0.01"
                                       value="">
                                <p class="form-help-text">Recommended: $5-$15</p>
                            </div>
                            
                            <div class="form-group">
                                <label for="notePages">
                                    Number of Pages
                                </label>
                                <input type="number" 
                                       id="notePages" 
                                       name="pages" 
                                       placeholder="25" 
                                       min="1"
                                       value="">
                                <p class="form-help-text">Total pages in your notes</p>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="noteUniversity">
                                    University/College
                                </label>
                                <input type="text" 
                                       id="noteUniversity" 
                                       name="university" 
                                       placeholder="e.g., Harvard University"
                                       value="">
                            </div>
                            
                            <div class="form-group">
                                <label for="noteSubject">
                                    Subject Code
                                </label>
                                <input type="text" 
                                       id="noteSubject" 
                                       name="subject" 
                                       placeholder="e.g., BIO-101"
                                       value="">
                            </div>
                        </div>
                        
                        <button type="submit" class="btn-upload" id="uploadBtn">
                            🚀 Upload Notes
                        </button>
                    </form>
                </div>
                
                <!-- Sidebar -->
                <div class="upload-sidebar">
                    <!-- Earnings Potential -->
                    <div class="sidebar-card earnings-card">
                        <h3>💵 Potential Earnings</h3>
                        <div class="earnings-amount" id="potentialEarnings">$0</div>
                        <p class="earnings-text">
                            Based on average downloads, you could earn this much per month!
                        </p>
                    </div>
                    
                    <!-- Upload Guidelines -->
                    <div class="sidebar-card">
                        <h3>✨ Upload Guidelines</h3>
                        
                        <div class="guideline-item">
                            <div class="guideline-icon">✅</div>
                            <div class="guideline-content">
                                <h4>Quality Content</h4>
                                <p>Ensure your notes are clear, well-organized, and easy to understand.</p>
                            </div>
                        </div>
                        
                        <div class="guideline-item">
                            <div class="guideline-icon">📝</div>
                            <div class="guideline-content">
                                <h4>Detailed Description</h4>
                                <p>Write a comprehensive description of what's covered in your notes.</p>
                            </div>
                        </div>
                        
                        <div class="guideline-item">
                            <div class="guideline-icon">💎</div>
                            <div class="guideline-content">
                                <h4>Fair Pricing</h4>
                                <p>Price your notes fairly based on content quality and length.</p>
                            </div>
                        </div>
                        
                        <div class="guideline-item">
                            <div class="guideline-icon">🔒</div>
                            <div class="guideline-content">
                                <h4>Original Work</h4>
                                <p>Only upload notes that you created yourself or have rights to share.</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Tips for Success -->
                    <div class="sidebar-card">
                        <h3>💡 Tips for Success</h3>
                        
                        <div class="guideline-item">
                            <div class="guideline-icon">🎯</div>
                            <div class="guideline-content">
                                <h4>Catchy Titles</h4>
                                <p>Use clear, descriptive titles that help students find your notes.</p>
                            </div>
                        </div>
                        
                        <div class="guideline-item">
                            <div class="guideline-icon">📸</div>
                            <div class="guideline-content">
                                <h4>Add Details</h4>
                                <p>Include page count, university, and subject code for better visibility.</p>
                            </div>
                        </div>
                        
                        <div class="guideline-item">
                            <div class="guideline-icon">⭐</div>
                            <div class="guideline-content">
                                <h4>Get Reviews</h4>
                                <p>Quality notes get great reviews, leading to more sales!</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">How It Works</a></li>
                        <li><a href="#">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="#">Help Center</a></li>
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="#">Facebook</a></li>
                        <li><a href="#">Twitter</a></li>
                        <li><a href="#">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>
    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
    <script>
        // Note type toggle for free/paid
        const typePaid = document.getElementById('typePaid');
        const typeFree = document.getElementById('typeFree');
        const priceGroup = document.getElementById('priceGroup');
        const priceInputField = document.getElementById('notePrice');
        
        function togglePriceField() {
            if (typeFree.checked) {
                priceGroup.style.display = 'none';
                priceInputField.value = '0';
                priceInputField.removeAttribute('required');
            } else {
                priceGroup.style.display = 'block';
                priceInputField.setAttribute('required', 'required');
            }
        }
        
        typePaid.addEventListener('change', togglePriceField);
        typeFree.addEventListener('change', togglePriceField);
        
        // Character counters
        const titleInput = document.getElementById('noteTitle');
        const descInput = document.getElementById('noteDescription');
        const titleCounter = document.getElementById('titleCounter');
        const descCounter = document.getElementById('descCounter');
        
        titleInput.addEventListener('input', function() {
            titleCounter.textContent = this.value.length;
        });
        
        descInput.addEventListener('input', function() {
            descCounter.textContent = this.value.length;
        });
        
        // Potential earnings calculator
        const priceInput = document.getElementById('notePrice');
        const earningsDisplay = document.getElementById('potentialEarnings');
        
        priceInput.addEventListener('input', function() {
            const price = parseFloat(this.value) || 0;
            const avgDownloads = 50; // Average monthly downloads
            const earnings = (price * avgDownloads * 0.85).toFixed(2); // 85% commission
            earningsDisplay.textContent = '$' + earnings;
        });
        
        // File upload handling
        const fileUploadArea = document.getElementById('fileUploadArea');
        const fileInput = document.getElementById('noteFile');
        const filePreview = document.getElementById('filePreview');
        const fileName = document.getElementById('fileName');
        const fileSize = document.getElementById('fileSize');
        const fileIcon = document.getElementById('fileIcon');
        const fileRemove = document.getElementById('fileRemove');
        
        // Drag and drop
        fileUploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('dragover');
        });
        
        fileUploadArea.addEventListener('dragleave', function() {
            this.classList.remove('dragover');
        });
        
        fileUploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('dragover');
            
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                handleFileSelect(e.dataTransfer.files[0]);
            }
        });
        
        fileInput.addEventListener('change', function() {
            if (this.files.length) {
                handleFileSelect(this.files[0]);
            }
        });
        
        function handleFileSelect(file) {
            const maxSize = 50 * 1024 * 1024; // 50MB
            
            if (file.size > maxSize) {
                showError('File size exceeds 50MB limit. Please choose a smaller file.');
                fileInput.value = '';
                return;
            }
            
            // Show file preview
            fileName.textContent = file.name;
            fileSize.textContent = formatFileSize(file.size);
            
            // Set icon based on file type
            if (file.type.includes('pdf')) {
                fileIcon.textContent = '📕';
            } else if (file.type.includes('word') || file.name.endsWith('.doc') || file.name.endsWith('.docx')) {
                fileIcon.textContent = '📘';
            } else {
                fileIcon.textContent = '📄';
            }
            
            filePreview.classList.add('active');
            fileUploadArea.style.display = 'none';
        }
        
        fileRemove.addEventListener('click', function() {
            fileInput.value = '';
            filePreview.classList.remove('active');
            fileUploadArea.style.display = 'block';
        });
        
        function formatFileSize(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
        }
        
        function showSuccess(message) {
            const successMsg = document.getElementById('successMessage');
            successMsg.style.display = 'block';
            successMsg.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            setTimeout(() => {
                successMsg.style.display = 'none';
            }, 5000);
        }
        
        function showError(message) {
            const errorMsg = document.getElementById('errorMessage');
            const errorText = document.getElementById('errorText');
            errorText.textContent = message;
            errorMsg.style.display = 'block';
            errorMsg.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            setTimeout(() => {
                errorMsg.style.display = 'none';
            }, 5000);
        }
        
        // Form submission
        document.getElementById('uploadForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Client-side validation
            const titleInput = document.getElementById('noteTitle');
            const categoryInput = document.getElementById('noteCategory');
            const descriptionInput = document.getElementById('noteDescription');
            const priceInput = document.getElementById('notePrice');
            const fileInput = document.getElementById('noteFile');
            const noteType = document.querySelector('input[name="noteType"]:checked');
            
            console.log('Reading form values...');
            console.log('Title input exists:', !!titleInput);
            console.log('Title input value:', titleInput ? titleInput.value : 'INPUT NOT FOUND');
            
            const title = titleInput ? titleInput.value.trim() : '';
            const category = categoryInput ? categoryInput.value : '';
            const description = descriptionInput ? descriptionInput.value.trim() : '';
            const isFree = noteType && noteType.value === 'free';
            const price = isFree ? '0' : (priceInput ? priceInput.value : '');
            const file = fileInput ? fileInput.files[0] : null;
            
            console.log('Extracted values:');
            console.log('Title:', title, '(length:', title.length, ')');
            console.log('Category:', category);
            console.log('Description:', description.substring(0, 50) + '...');
            console.log('Price:', price);
            console.log('File:', file ? file.name : 'none');
            
            if (!title) {
                showError('Please enter a title for your notes');
                return;
            }
            
            if (!category) {
                showError('Please select a category');
                return;
            }
            
            if (!description) {
                showError('Please enter a description');
                return;
            }
            
            if (!isFree && (!price || price === '' || parseFloat(price) < 0)) {
                showError('Please enter a valid price for paid notes');
                return;
            }
            
            if (!file) {
                showError('Please select a file to upload');
                return;
            }
            
            // Check file size (PHP limit is now 50MB)
            const maxSize = 50 * 1024 * 1024; // 50MB in bytes
            if (file.size > maxSize) {
                showError(`File is too large (${(file.size / 1024 / 1024).toFixed(2)}MB). Maximum size is 50MB. Please choose a smaller file.`);
                return;
            }
            console.log('File size OK:', (file.size / 1024).toFixed(2), 'KB');
            
            const uploadBtn = document.getElementById('uploadBtn');
            const originalText = uploadBtn.textContent;
            uploadBtn.disabled = true;
            uploadBtn.textContent = '⏳ Uploading...';
            
            // Create FormData explicitly
            const formData = new FormData();
            console.log('FormData object created:', formData instanceof FormData);
            console.log('FormData constructor:', FormData.name);
            
            console.log('Creating FormData...');
            console.log('Appending title:', title);
            formData.append('title', title);
            
            console.log('Appending category:', category);
            formData.append('category', category);
            
            console.log('Appending description...');
            formData.append('description', description);
            
            console.log('Appending price:', price);
            formData.append('price', price);
            
            console.log('Appending is_free:', isFree ? '1' : '0');
            formData.append('is_free', isFree ? '1' : '0');
            
            console.log('Appending file:', file ? file.name : 'no file');
            if (file) {
                formData.append('file', file);
            }
            
            // Verify FormData was created correctly
            console.log('=== Verifying FormData entries ===');
            let hasTitle = false;
            for (let [key, value] of formData.entries()) {
                console.log('  -', key, ':', value instanceof File ? `[File: ${value.name}]` : `"${value}"`);
                if (key === 'title') hasTitle = true;
            }
            console.log('Title in FormData:', hasTitle);
            console.log('=== End FormData verification ===');
            
            // Add optional fields
            const pages = document.getElementById('notePages').value;
            const university = document.getElementById('noteUniversity').value;
            const subject = document.getElementById('noteSubject').value;
            
            if (pages) formData.append('pages', pages);
            if (university) formData.append('university', university);
            if (subject) formData.append('subject', subject);
            
            // Debug: Log form data
            console.log('Form data being sent:');
            console.log('Title:', title);
            console.log('Category:', category);
            console.log('Description:', description);
            console.log('Price:', price);
            console.log('File:', file ? file.name : 'No file');
            
            for (let [key, value] of formData.entries()) {
                console.log('FormData -', key + ':', value instanceof File ? `File: ${value.name}` : value);
            }
            
            try {
                // TEST: First try the test endpoint
                console.log('Testing with test-post.php first...');
                const testResponse = await fetch('api/notes/test-post.php', {
                    method: 'POST',
                    credentials: 'include',
                    body: formData
                });
                const testResult = await testResponse.json();
                console.log('Test endpoint response:', testResult);
                
                // Now try the real endpoint
                console.log('Now trying real create.php endpoint...');
                const response = await fetch('api/notes/create.php', {
                    method: 'POST',
                    credentials: 'include',
                    body: formData
                    // Don't set Content-Type - let browser set it with boundary for multipart/form-data
                });
                
                const result = await response.json();
                console.log('Server response:', result);
                
                if (result.success) {
                    showSuccess('Note uploaded successfully! Your notes are now available for sale.');
                    
                    // Reset form after 2 seconds
                    setTimeout(() => {
                        window.location.href = 'my-notes.php';
                    }, 2000);
                } else {
                    showError(result.message || 'Failed to upload notes. Please try again.');
                    uploadBtn.disabled = false;
                    uploadBtn.textContent = originalText;
                }
            } catch (error) {
                showError('An error occurred while uploading. Please try again.');
                uploadBtn.disabled = false;
                uploadBtn.textContent = originalText;
            }
        });
        
        // Validate form on input
        const form = document.getElementById('uploadForm');
        const inputs = form.querySelectorAll('input[required], select[required], textarea[required]');
        
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                if (!this.value.trim()) {
                    this.style.borderColor = '#e74c3c';
                } else {
                    this.style.borderColor = '#28a745';
                }
            });
        });
    </script>
</body>
</html>
