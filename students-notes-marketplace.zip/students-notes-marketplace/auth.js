// Simple localStorage-based authentication for demo purposes

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    // Login functionality
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('loginUsername').value.trim();
            const password = document.getElementById('loginPassword').value;
            
            const users = JSON.parse(localStorage.getItem('users') || '{}');
            
            if (users[username] && users[username].password === password) {
                localStorage.setItem('currentUser', username);
                alert('Login successful! Welcome back, ' + username + '! 🎉');
                window.location.href = 'dashboard.html';
            } else {
                alert('❌ Invalid username or password. Please try again.');
            }
        });
    }

    // Register functionality
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('registerUsername').value.trim();
            const email = document.getElementById('registerEmail').value.trim();
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            // Validation
            if (password !== confirmPassword) {
                alert('❌ Passwords do not match!');
                return;
            }
            
            if (password.length < 6) {
                alert('❌ Password must be at least 6 characters long!');
                return;
            }
            
            let users = JSON.parse(localStorage.getItem('users') || '{}');
            
            if (users[username]) {
                alert('❌ Username already exists! Please choose a different one.');
                return;
            }
            
            // Create new user
            users[username] = { 
                email: email, 
                password: password,
                joinDate: new Date().toISOString(),
                notesUploaded: 0,
                notesPurchased: 0,
                earnings: 0
            };
            
            localStorage.setItem('users', JSON.stringify(users));
            alert('✅ Registration successful! Please login with your credentials.');
            window.location.href = 'login.html';
        });
    }
});
