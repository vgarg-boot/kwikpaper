<?php
/**
 * Navigation Include File
 * Include this in all pages to show consistent navigation with admin support
 * Usage: <?php include 'includes/nav.php'; ?>
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<header>
    <div class="container">
        <div class="logo">
            <a href="index.php" style="text-decoration: none; color: inherit;">
                <h1>📚 Notes Marketplace</h1>
            </a>
        </div>
        <nav>
            <a href="index.php">Home</a>
            <a href="browse.php">Browse Notes</a>
            <a href="upload.php">Upload</a>
            <?php if(isset($_SESSION['user_id'])): ?>
                <a href="dashboard.php">Dashboard</a>
            <?php endif; ?>
        </nav>
        <div class="nav-search">
            <input type="text" placeholder="Search notes..." id="navSearch">
        </div>
        <nav class="nav-right">
            <?php if(isset($_SESSION['user_id'])): ?>
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <span class="admin-badge">ADMIN</span>
                <?php endif; ?>
                <span class="user-welcome">👋 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <a href="admin.php" class="btn-admin" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0.6rem 1.2rem; border-radius: 8px; text-decoration: none; font-weight: 600;">Admin</a>
                <?php endif; ?>
                <a href="dashboard.php" class="btn-dashboard">Dashboard</a>
                <a href="api/auth/logout.php" class="btn-logout">Logout</a>
            <?php else: ?>
                <a href="login.php" class="btn-login">Login</a>
                <a href="register.php" class="btn-register">Register</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
