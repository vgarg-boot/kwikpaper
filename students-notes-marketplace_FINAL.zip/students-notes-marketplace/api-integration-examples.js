/**
 * Example: Integrating API with Login Page
 * Replace the content in auth.js with this example
 */

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    // Login functionality using API
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = document.getElementById('loginEmail').value.trim();
            const password = document.getElementById('loginPassword').value;
            
            // Call API
            const result = await AuthAPI.login(email, password);
            
            if (result.success) {
                alert('Login successful! Welcome back, ' + result.user.username + '! 🎉');
                window.location.href = 'dashboard.html';
            } else {
                alert('❌ ' + result.message);
            }
        });
    }

    // Register functionality using API
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = document.getElementById('registerUsername').value.trim();
            const email = document.getElementById('registerEmail').value.trim();
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            // Client-side validation
            if (password !== confirmPassword) {
                alert('❌ Passwords do not match!');
                return;
            }
            
            if (password.length < 6) {
                alert('❌ Password must be at least 6 characters long!');
                return;
            }
            
            // Call API
            const result = await AuthAPI.register(username, email, password);
            
            if (result.success) {
                alert('✅ Registration successful! Please login with your credentials.');
                window.location.href = 'login.html';
            } else {
                alert('❌ ' + result.message);
            }
        });
    }
});

/**
 * Example: Integrating API with Browse Page
 * Add this to browse.js
 */

document.addEventListener('DOMContentLoaded', async function() {
    const searchInput = document.getElementById('searchInput');
    const categoryFilter = document.getElementById('categoryFilter');
    const notesGrid = document.getElementById('notesGrid');

    // Load notes from API
    async function loadNotes() {
        const category = categoryFilter.value;
        const search = searchInput.value;
        
        const result = await NotesAPI.list(1, 12, category, search);
        
        if (result.success) {
            displayNotes(result.data);
        } else {
            notesGrid.innerHTML = '<p>Failed to load notes</p>';
        }
    }

    // Display notes in grid
    function displayNotes(notes) {
        if (notes.length === 0) {
            notesGrid.innerHTML = '<p>No notes found</p>';
            return;
        }
        
        notesGrid.innerHTML = notes.map(note => `
            <div class="note-card" data-category="${note.category}">
                <h3>${note.title}</h3>
                <p>${note.description}</p>
                <div class="note-meta">
                    <span class="author">By ${note.username}</span>
                    <span class="price">${Utils.formatPrice(note.price)}</span>
                </div>
                <div class="note-stats">
                    <span>⭐ ${note.rating}</span>
                    <span>👁️ ${note.views}</span>
                </div>
                <a href="note-detail.html?id=${note.id}" class="btn-view">View Details</a>
            </div>
        `).join('');
    }

    // Event listeners
    searchInput.addEventListener('input', loadNotes);
    categoryFilter.addEventListener('change', loadNotes);

    // Initial load
    loadNotes();
});

/**
 * Example: Integrating API with Upload Page
 * Add this to a new upload.js file
 */

document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    if (!Utils.requireAuth()) return;

    const uploadForm = document.getElementById('uploadForm');

    if (uploadForm) {
        uploadForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            // Create FormData from form
            const formData = new FormData();
            formData.append('title', document.getElementById('noteTitle').value);
            formData.append('description', document.getElementById('noteDescription').value);
            formData.append('category', document.getElementById('noteCategory').value);
            formData.append('price', document.getElementById('notePrice').value);
            formData.append('pages', document.getElementById('notePages').value);
            
            // Add file if selected
            const fileInput = document.getElementById('noteFile');
            if (fileInput.files.length > 0) {
                formData.append('file', fileInput.files[0]);
            }

            // Call API
            const result = await NotesAPI.create(formData);

            if (result.success) {
                alert('✅ Note uploaded successfully!');
                window.location.href = 'my-notes.html';
            } else {
                alert('❌ ' + result.message);
            }
        });
    }
});

/**
 * Example: Integrating API with Dashboard
 * Replace dashboard.js with this
 */

document.addEventListener('DOMContentLoaded', async function() {
    // Check authentication
    if (!Utils.requireAuth()) return;

    const user = AuthAPI.getCurrentUser();
    const userNameSpan = document.getElementById('userName');
    const logoutBtn = document.getElementById('logoutBtn');

    // Display username
    if (userNameSpan) {
        userNameSpan.textContent = user.username;
    }

    // Load user stats from API
    const statsResult = await UserAPI.getStats();
    
    if (statsResult.success) {
        document.getElementById('notesUploaded').textContent = statsResult.data.notes_uploaded || 0;
        document.getElementById('notesPurchased').textContent = statsResult.data.notes_purchased || 0;
        document.getElementById('totalEarnings').textContent = Utils.formatPrice(statsResult.data.earnings || 0);
    }

    // Logout functionality
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async function(e) {
            e.preventDefault();
            
            if (confirm('Are you sure you want to logout?')) {
                const result = await AuthAPI.logout();
                
                if (result.success) {
                    alert('✅ Logged out successfully!');
                    window.location.href = 'index.html';
                }
            }
        });
    }
});

/**
 * Example: Integrating API with Profile Page
 * Add this to profile.js
 */

document.addEventListener('DOMContentLoaded', async function() {
    // Get user ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const userId = urlParams.get('id');

    if (!userId) {
        alert('Invalid profile');
        window.location.href = 'browse.html';
        return;
    }

    // Load profile data
    const result = await UserAPI.getProfile(userId);

    if (result.success) {
        const profile = result.data;
        
        // Update DOM elements
        document.getElementById('profileAvatar').textContent = profile.avatar;
        document.getElementById('profileName').textContent = profile.username;
        document.getElementById('profileBio').textContent = profile.bio || 'No bio available';
        document.getElementById('profileUniversity').textContent = profile.university || 'Not specified';
        document.getElementById('profileSubject').textContent = profile.subject || 'Not specified';
        document.getElementById('notesCount').textContent = profile.notes_uploaded;
        document.getElementById('earningsAmount').textContent = Utils.formatPrice(profile.earnings);
        
        // Load user's notes
        loadUserNotes(userId);
    } else {
        alert('Failed to load profile');
    }

    async function loadUserNotes(userId) {
        const notesResult = await NotesAPI.getUserNotes(userId);
        
        if (notesResult.success) {
            displayUserNotes(notesResult.data);
        }
    }

    function displayUserNotes(notes) {
        const container = document.getElementById('userNotesContainer');
        
        if (!container) return;
        
        if (notes.length === 0) {
            container.innerHTML = '<p>No notes uploaded yet</p>';
            return;
        }
        
        container.innerHTML = notes.map(note => `
            <div class="note-card">
                <h3>${note.title}</h3>
                <p>${note.description}</p>
                <div class="note-meta">
                    <span>${Utils.formatPrice(note.price)}</span>
                    <span>⭐ ${note.rating}</span>
                </div>
                <a href="note-detail.html?id=${note.id}" class="btn">View</a>
            </div>
        `).join('');
    }
});
