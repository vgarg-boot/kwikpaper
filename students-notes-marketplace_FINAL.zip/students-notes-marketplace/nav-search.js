// Global navigation functionality

document.addEventListener('DOMContentLoaded', function() {
    const isPhpPage = window.location.pathname.includes('.php');
    const currentUser = localStorage.getItem('currentUser');
    
    // Only control dashboard link visibility for HTML pages
    // PHP pages handle this server-side via session
    if (!isPhpPage) {
        const dashboardLinks = document.querySelectorAll('a[href="dashboard.html"]');
        
        dashboardLinks.forEach(link => {
            if (!currentUser) {
                // Hide dashboard link if user is not logged in
                link.style.display = 'none';
            } else {
                // Show dashboard link if user is logged in
                link.style.display = '';
            }
        });
    }

    // Handle aux nav (nav-right) for HTML pages only
    const navRight = document.querySelector('.nav-right');
    if (navRight && !isPhpPage) {
        if (currentUser) {
            // User is logged in - show username, dashboard, and logout
            const userData = JSON.parse(currentUser);
            navRight.innerHTML = `
                <span class="user-welcome">👋 ${userData.username}</span>
                <a href="dashboard.html" class="btn-dashboard">Dashboard</a>
                <a href="#" class="btn-logout" id="logoutBtn">Logout</a>
            `;
            
            // Add logout functionality
            document.getElementById('logoutBtn').addEventListener('click', function(e) {
                e.preventDefault();
                if (confirm('Are you sure you want to logout?')) {
                    localStorage.removeItem('currentUser');
                    alert('✅ Logged out successfully!');
                    window.location.href = 'index.html';
                }
            });
        } else {
            // User is not logged in - show login and register
            navRight.innerHTML = `
                <a href="login.html" class="btn-login">Login</a>
                <a href="register.html" class="btn-register">Register</a>
            `;
        }
    }

    // Search functionality
    const navSearch = document.getElementById('navSearch');
    
    if (!navSearch) return;

    // Handle Enter key press
    navSearch.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const searchTerm = navSearch.value.trim();
            
            if (searchTerm) {
                // Check if we're on a PHP page or HTML page
                const isPhpPage = window.location.pathname.includes('.php');
                const browseUrl = isPhpPage ? 'browse.php' : 'browse.html';
                
                // If on browse page, trigger the existing search
                if (window.location.pathname.includes('browse')) {
                    const browseSearchInput = document.getElementById('searchInput');
                    if (browseSearchInput) {
                        browseSearchInput.value = searchTerm;
                        browseSearchInput.dispatchEvent(new Event('input'));
                    }
                } else {
                    // Redirect to browse page with search query
                    window.location.href = `${browseUrl}?search=${encodeURIComponent(searchTerm)}`;
                }
            }
        }
    });

    // On browse page, check for search query parameter
    if (window.location.pathname.includes('browse')) {
        const urlParams = new URLSearchParams(window.location.search);
        const searchQuery = urlParams.get('search');
        
        if (searchQuery) {
            // Populate both search inputs
            navSearch.value = searchQuery;
            const browseSearchInput = document.getElementById('searchInput');
            if (browseSearchInput) {
                browseSearchInput.value = searchQuery;
                browseSearchInput.dispatchEvent(new Event('input'));
            }
        }
    }
});
