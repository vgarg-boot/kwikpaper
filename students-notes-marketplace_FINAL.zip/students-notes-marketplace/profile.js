// Profile data for different users
const profileData = {
    1: {
        name: "Sarah Williams",
        subject: "Biology & Chemistry Specialist",
        avatar: "👩‍🎓",
        notesCount: 47,
        rating: "4.9 ⭐",
        sales: 1247,
        earnings: "$1,247",
        bio: "Passionate Biology and Chemistry student dedicated to creating comprehensive, easy-to-understand study materials. All my notes are carefully organized with diagrams, examples, and key concepts highlighted for better retention. I believe in helping fellow students succeed!",
        memberSince: "January 2025",
        university: "Stanford University",
        year: "Senior",
        response: "Usually within 2 hours"
    },
    2: {
        name: "Alex Johnson",
        subject: "Computer Science Specialist",
        avatar: "👨‍🎓",
        notesCount: 38,
        rating: "4.8 ⭐",
        sales: 1089,
        earnings: "$1,089",
        bio: "Computer Science major with a passion for algorithms, data structures, and software development. My notes focus on breaking down complex concepts into digestible pieces with plenty of code examples and practical applications.",
        memberSince: "February 2025",
        university: "MIT",
        year: "Junior",
        response: "Usually within 4 hours"
    },
    3: {
        name: "Emma Rodriguez",
        subject: "Mathematics & Physics Specialist",
        avatar: "👩‍🎓",
        notesCount: 52,
        rating: "4.9 ⭐",
        sales: 986,
        earnings: "$986",
        bio: "Mathematics and Physics enthusiast who loves making complex formulas and theories accessible to everyone. My notes include step-by-step problem solving, visual aids, and real-world applications.",
        memberSince: "December 2024",
        university: "Caltech",
        year: "Senior",
        response: "Usually within 3 hours"
    },
    4: {
        name: "Ryan Lee",
        subject: "Business & Economics Specialist",
        avatar: "👨‍🎓",
        notesCount: 34,
        rating: "4.7 ⭐",
        sales: 842,
        earnings: "$842",
        bio: "Business and Economics major focused on finance, marketing, and management. My notes combine theoretical frameworks with real-world case studies to help you understand and apply business concepts effectively.",
        memberSince: "March 2025",
        university: "Harvard Business School",
        year: "Graduate",
        response: "Usually within 6 hours"
    },
    5: {
        name: "Olivia Brown",
        subject: "Psychology & Sociology Specialist",
        avatar: "👩‍🎓",
        notesCount: 29,
        rating: "4.8 ⭐",
        sales: 765,
        earnings: "$765",
        bio: "Psychology and Sociology student passionate about understanding human behavior and society. My notes are comprehensive, well-researched, and include relevant studies and theories explained in simple terms.",
        memberSince: "April 2025",
        university: "Yale University",
        year: "Junior",
        response: "Usually within 5 hours"
    },
    6: {
        name: "Marcus Davis",
        subject: "Engineering Specialist",
        avatar: "👨‍🎓",
        notesCount: 26,
        rating: "4.7 ⭐",
        sales: 698,
        earnings: "$698",
        bio: "Mechanical Engineering student with expertise in thermodynamics, mechanics, and design. My notes are detailed with diagrams, equations, and practical examples to help you master engineering concepts.",
        memberSince: "May 2025",
        university: "Georgia Tech",
        year: "Senior",
        response: "Usually within 8 hours"
    },
    7: {
        name: "Sophia Kim",
        subject: "Literature & History Specialist",
        avatar: "👩‍🎓",
        notesCount: 31,
        rating: "4.6 ⭐",
        sales: 623,
        earnings: "$623",
        bio: "Literature and History major who loves analyzing texts and historical events. My notes include summaries, analysis, timelines, and critical perspectives to help you excel in humanities courses.",
        memberSince: "June 2025",
        university: "Columbia University",
        year: "Junior",
        response: "Usually within 12 hours"
    },
    8: {
        name: "James Wilson",
        subject: "Chemistry Specialist",
        avatar: "👨‍🎓",
        notesCount: 24,
        rating: "4.8 ⭐",
        sales: 587,
        earnings: "$587",
        bio: "Chemistry major specializing in organic and inorganic chemistry. My notes feature detailed reaction mechanisms, molecular structures, and laboratory techniques explained clearly.",
        memberSince: "July 2025",
        university: "UC Berkeley",
        year: "Senior",
        response: "Usually within 4 hours"
    },
    9: {
        name: "Ava Martinez",
        subject: "Art & Design Specialist",
        avatar: "👩‍🎓",
        notesCount: 22,
        rating: "4.9 ⭐",
        sales: 542,
        earnings: "$542",
        bio: "Art and Design student passionate about visual communication, color theory, and digital design. My notes combine theory with practical tips and visual examples to inspire your creativity.",
        memberSince: "August 2025",
        university: "Rhode Island School of Design",
        year: "Sophomore",
        response: "Usually within 6 hours"
    }
};

// Get user ID from URL parameters
function getUserIdFromURL() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('id') || '1'; // Default to user 1 if no ID provided
}

// Load profile data
function loadProfileData() {
    const userId = getUserIdFromURL();
    const profile = profileData[userId];

    if (profile) {
        // Update profile header
        document.getElementById('profile-name').textContent = profile.name;
        document.getElementById('profile-subject').textContent = profile.subject;
        document.querySelector('.profile-avatar-large').textContent = profile.avatar;
        document.getElementById('profile-notes-count').textContent = profile.notesCount;
        document.getElementById('profile-rating').textContent = profile.rating;
        document.getElementById('profile-sales').textContent = profile.sales;
        document.getElementById('profile-earnings').textContent = profile.earnings;

        // Update about section
        document.getElementById('profile-bio').textContent = profile.bio;
        document.getElementById('profile-member-since').textContent = profile.memberSince;
        document.getElementById('profile-university').textContent = profile.university;
        document.getElementById('profile-year').textContent = profile.year;
        document.getElementById('profile-response').textContent = profile.response;

        // Update page title
        document.title = `${profile.name} - Profile | KwikPaper`;
    }
}

// Load data when page loads
document.addEventListener('DOMContentLoaded', loadProfileData);
