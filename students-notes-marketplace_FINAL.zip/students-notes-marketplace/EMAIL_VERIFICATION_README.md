# Email Verification Setup Guide

This guide explains how to set up and use the email verification feature for user registration.

## Features Added

1. **Email Verification on Registration**: Users must verify their email address after registering
2. **Verification Emails**: Automated emails sent with verification links
3. **Token-Based Verification**: Secure, time-limited verification tokens (24 hours expiry)
4. **Resend Verification**: Users can request a new verification email if needed
5. **Login Protection**: Prevents unverified users from logging in (configurable)

## Database Setup

### Run the Migration Script

You have two options for running the migration:

**Option 1: Using the Safe Version (Recommended)**
This checks if columns exist before adding them, safe to run multiple times:

```bash
mysql -u your_username -p notes_marketplace < api/config/add_email_verification_safe.sql
```

**Option 2: Using the Simple Version**
Simpler but will give errors if columns already exist (errors can be ignored):

```bash
mysql -u your_username -p notes_marketplace < api/config/add_email_verification.sql
```

**Option 3: Using the Web Interface**
Open `setup-email-verification.html` in your browser and click "Run Database Migration".

### Columns Added to `users` table:
- `email_verified` (TINYINT) - 0 for unverified, 1 for verified
- `verification_token` (VARCHAR) - Unique token for verification
- `verification_token_expires` (TIMESTAMP) - Token expiry date/time
- `verification_sent_at` (TIMESTAMP) - Track when last email was sent

## Email Configuration

### 1. Update Email Settings

Edit `api/config/email.php` to configure your email settings:

```php
// From email address
public static $from_email = 'noreply@kwikpaper.com'; // Change this
public static $from_name = 'KwikPaper';

// Base URL of your application
public static $base_url = 'http://localhost/students-notes-marketplace'; // Update for production

// Email verification settings
public static $verification_token_expiry = 24; // hours
public static $require_verification = true; // Set to false to allow login without verification
```

### 2. Configure Email Sending Method

#### Option A: PHP mail() Function (Default)
- Uses the built-in PHP `mail()` function
- Requires your server to have mail configured
- Works out of the box on most hosting providers

```php
public static $method = 'mail';
```

#### Option B: SMTP (Recommended for Production)
- More reliable email delivery
- Requires PHPMailer library (install via Composer)
- Configure SMTP settings in `api/config/email.php`

```php
public static $method = 'smtp';
public static $smtp_host = 'smtp.gmail.com';
public static $smtp_port = 587;
public static $smtp_username = 'your-email@gmail.com';
public static $smtp_password = 'your-app-password'; // Use App Password for Gmail
public static $smtp_secure = 'tls';
```

**For Gmail:**
1. Enable 2-Factor Authentication
2. Generate an App Password: https://myaccount.google.com/apppasswords
3. Use the App Password (not your regular Gmail password)

## Testing Email Verification

### Local Development Testing

For local development, you have several options:

#### 1. Use MailHog (Recommended)
- Catches all outgoing emails for testing
- No actual emails sent
- View emails in web interface: http://localhost:8025

```bash
# Install and run MailHog
# Windows: Download from https://github.com/mailhog/MailHog/releases
# macOS: brew install mailhog && mailhog
# Linux: sudo apt-get install golang-go; go get github.com/mailhog/MailHog
```

Configure PHP to use MailHog:
```ini
; In php.ini
smtp_port = 1025
```

#### 2. Check Email Logs
- Check your PHP error logs for email sending attempts
- Verification links will be logged

#### 3. Manual Verification (Development Only)
To bypass email verification during development:

```php
// In api/config/email.php
public static $require_verification = false;
```

Or manually verify a user in the database:
```sql
UPDATE users SET email_verified = 1 WHERE email = 'test@example.com';
```

## User Flow

### Registration Flow

1. User submits registration form
2. Account is created in the database with `email_verified = 0`
3. Verification token is generated (64-character hex string)
4. Verification email is sent with a link like:
   ```
   http://yourdomain.com/api/auth/verify-email.php?token=abc123...
   ```
5. User receives success message: "Registration successful! Please check your email to verify your account."

### Email Verification Flow

1. User clicks verification link in email
2. System validates the token and checks expiry
3. If valid:
   - `email_verified` is set to 1
   - Token is cleared
   - Welcome email is sent (optional)
   - User redirected to login with success message
4. If invalid/expired:
   - User redirected to login with error message
   - Option to resend verification email

### Login Flow

1. User enters email and password
2. Credentials are validated
3. If `require_verification = true` and email not verified:
   - Login is blocked (403 Forbidden)
   - Message shown: "Please verify your email address before logging in"
   - Option to resend verification email
4. If verified, login proceeds normally

## API Endpoints

### POST `/api/auth/register.php`
Register new user and send verification email

**Request:**
```json
{
  "username": "johndoe",
  "email": "john@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Registration successful! Please check your email to verify your account.",
  "user": {
    "id": 1,
    "username": "johndoe",
    "email": "john@example.com"
  },
  "verification_required": true
}
```

### GET `/api/auth/verify-email.php?token=xxx`
Verify email address with token

**Success:** Redirects to `login.php?verification=success`
**Failure:** Redirects to `login.php?verification=expired` or `login.php?verification=invalid`

### POST `/api/auth/resend-verification.php`
Resend verification email

**Request:**
```json
{
  "email": "john@example.com"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Verification email has been sent. Please check your inbox."
}
```

**Rate Limiting:** Can only resend once every 5 minutes

### POST `/api/auth/login.php`
Login with email verification check

**Response (Unverified):**
```json
{
  "success": false,
  "message": "Please verify your email address before logging in",
  "email_verified": false,
  "email": "john@example.com"
}
```

## Email Templates

Email templates are defined in `api/config/email-helper.php`:

1. **Verification Email**: Sent upon registration with verification link
2. **Welcome Email**: Sent after successful email verification (optional)

### Customizing Email Templates

Edit the methods in `api/config/email-helper.php`:
- `getVerificationEmailTemplate()` - Verification email design
- `getWelcomeEmailTemplate()` - Welcome email design

Templates are HTML-based with inline CSS for better email client compatibility.

## Security Considerations

1. **Token Security**
   - Tokens are 64-character random hex strings
   - Tokens expire after 24 hours
   - Tokens are cleared after successful verification

2. **Rate Limiting**
   - Resend verification limited to once per 5 minutes per user
   - Prevents spam and abuse

3. **Email Validation**
   - Email format validated before registration
   - Duplicate emails prevented

4. **HTTPS Required**
   - Use HTTPS in production to protect verification links
   - Update `base_url` in `email.php` to use `https://`

## Optional: Disable Email Verification

To allow users to login without email verification:

```php
// In api/config/email.php
public static $require_verification = false;
```

Users will still receive verification emails, but can login immediately.

## Troubleshooting

### Emails Not Sending

1. **Check PHP mail() configuration**
   ```bash
   php -i | grep sendmail_path
   ```

2. **Check error logs**
   - PHP error log
   - Web server error log

3. **Test with SMTP instead**
   - More reliable than `mail()`
   - Use services like SendGrid, Mailgun, or Gmail

### Verification Links Not Working

1. **Check base_url in email.php**
   - Must match your actual domain
   - Include protocol (http:// or https://)
   - No trailing slash

2. **Check token expiry**
   - Default is 24 hours
   - Adjust in `email.php` if needed

3. **Check database columns**
   - Ensure migration was run successfully
   - Verify columns exist in `users` table

### Users Can't Login After Verification

1. **Check EmailConfig::$require_verification**
2. **Verify database `email_verified` column is set to 1**
3. **Check browser console for JavaScript errors**

## Production Checklist

- [ ] Update `base_url` in `api/config/email.php` to production domain
- [ ] Use HTTPS for production
- [ ] Configure SMTP for reliable email delivery
- [ ] Test email sending on production server
- [ ] Set appropriate `from_email` and `from_name`
- [ ] Configure SPF/DKIM records for your domain
- [ ] Test full registration and verification flow
- [ ] Monitor email logs for delivery issues

## Support

For issues or questions, check:
- PHP error logs
- Browser console for JavaScript errors
- Database for verification token data
- Email delivery logs

---

**Last Updated:** February 17, 2026
