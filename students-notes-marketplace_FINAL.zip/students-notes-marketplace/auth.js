// Authentication and navigation for PHP pages with API integration

document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    
    // Check session and update navigation for all pages
    checkSessionAndUpdateNav();

    // Login functionality
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value.trim();
            const password = document.getElementById('loginPassword').value;
            
            try {
                const response = await fetch('api/auth/login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email, password })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    alert('Login successful! Welcome back, ' + data.user.username + '! 🎉');
                    
                    // Redirect based on role
                    if (data.user.role === 'admin') {
                        window.location.href = 'admin.php';
                    } else {
                        window.location.href = 'dashboard.php';
                    }
                } else {
                    // Check if email verification is required
                    if (data.email_verified === false) {
                        const resend = confirm(data.message + '\n\nWould you like us to resend the verification email?');
                        if (resend) {
                            // Resend verification email
                            try {
                                const resendResponse = await fetch('api/auth/resend-verification.php', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ email: email })
                                });
                                const resendData = await resendResponse.json();
                                alert(resendData.message);
                            } catch (error) {
                                alert('❌ Failed to resend verification email.');
                            }
                        }
                    } else {
                        alert('❌ ' + data.message);
                    }
                }
            } catch (error) {
                console.error('Login error:', error);
                alert('❌ Login failed. Please try again.');
            }
        });
    }

    // Register functionality
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const username = document.getElementById('registerUsername').value.trim();
            const email = document.getElementById('registerEmail').value.trim();
            const password = document.getElementById('registerPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            
            // Validation
            if (password !== confirmPassword) {
                alert('❌ Passwords do not match!');
                return;
            }
            
            if (password.length < 6) {
                alert('❌ Password must be at least 6 characters long!');
                return;
            }
            
            try {
                const response = await fetch('api/auth/register.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ username, email, password })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    if (data.verification_required) {
                        alert('✅ Registration successful! Please check your email to verify your account before logging in.');
                    } else {
                        alert('✅ Registration successful! Please login with your credentials.');
                    }
                    window.location.href = 'login.php';
                } else {
                    alert('❌ ' + data.message);
                }
            } catch (error) {
                console.error('Registration error:', error);
                alert('❌ Registration failed. Please try again.');
            }
        });
    }
});

// Check session and update navigation
async function checkSessionAndUpdateNav() {
    try {
        const response = await fetch('api/auth/session.php');
        const data = await response.json();
        
        if (data.logged_in && data.user) {
            updateNavigation(data.user);
        }
    } catch (error) {
        console.error('Session check error:', error);
    }
}

// Update navigation based on user
function updateNavigation(user) {
    const navRight = document.getElementById('navRight');
    if (!navRight) return;
    
    let navHTML = '<a href="index.php">Home</a>';
    navHTML += '<a href="browse.php">Browse</a>';
    
    // Add admin link if user is admin
    if (user.role === 'admin') {
        navHTML += '<a href="admin.php">Admin</a>';
    }
    
    navHTML += `
        <div class="user-menu">
            <span style="font-size: 24px;">${user.avatar}</span>
            <span>${user.username}</span>
            <div class="dropdown-menu">
                <a href="profile.php">Profile</a>
                <a href="dashboard.php">Dashboard</a>
                <a href="my-notes.php">My Notes</a>
                <a href="upload.php">Upload Notes</a>
                ${user.role === 'admin' ? '<a href="admin.php">Admin Panel</a>' : ''}
                <a href="#" onclick="logout()">Logout</a>
            </div>
        </div>
    `;
    
    navRight.innerHTML = navHTML;
}

// Logout function
async function logout() {
    try {
        const response = await fetch('api/auth/logout.php');
        const data = await response.json();
        
        if (data.success) {
            alert('✅ Logged out successfully!');
            window.location.href = 'index.php';
        }
    } catch (error) {
        console.error('Logout error:', error);
        alert('✅ Logged out successfully!');
        window.location.href = 'index.php';
    }
}

