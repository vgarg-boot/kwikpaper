# Seller Payouts Feature

## Overview
This feature allows administrators to view, track, and manage seller earnings and payouts in the Notes Marketplace platform.

## Files Added/Modified

### New Files Created:
1. **api/admin/seller-earnings.php** - API endpoint for seller earnings management
2. **api/config/add_payout_columns.sql** - Database migration to add payout tracking columns

### Modified Files:
1. **admin.php** - Added "Seller Payouts" tab to admin dashboard
2. **admin.js** - Added JavaScript functions for payouts management
3. **api/admin/transactions.php** - Added seller_id filter support

## Database Setup

Before using this feature, you need to run the database migration:

```sql
-- Run this SQL script in your database
source api/config/add_payout_columns.sql;
```

This will add the following columns to the `transactions` table:
- `payout_status` - ENUM('unpaid', 'paid') - Tracks if seller has been paid
- `payout_date` - TIMESTAMP - Date when payout was made
- `payout_method` - VARCHAR(50) - Payment method used (PayPal, Bank Transfer, etc.)
- `payout_reference` - VARCHAR(255) - Transaction reference or ID
- `payout_notes` - TEXT - Additional notes about the payout

## Features

### 1. Seller Earnings Dashboard
- View all sellers with their earnings statistics
- See total sales, notes sold, and earnings breakdown
- Track unpaid vs paid earnings
- View first and last sale dates

### 2. Summary Statistics
The Payouts tab displays:
- Total number of active sellers
- Total earnings (all time)
- Total unpaid earnings (awaiting payout)
- Total paid earnings (already processed)

### 3. Seller Filtering
- Search by seller name or email
- Filter by payout status (Unpaid, Paid, All)
- Real-time search with debouncing

### 4. Mark as Paid
Admins can mark seller earnings as paid with:
- Payout method (PayPal, Bank Transfer, Check, etc.)
- Payout reference/transaction ID
- Additional notes
- Automatic timestamp recording

### 5. Seller Transaction Details
View detailed transaction history for each seller:
- All transactions for a specific seller
- Transaction amounts and earnings breakdown
- Platform fees
- Payout status for each transaction

### 6. Export to CSV
Export seller earnings data to CSV format including:
- Seller information
- Sales statistics
- Earnings breakdown
- Date ranges

## API Endpoints

### GET /api/admin/seller-earnings.php
Retrieve seller earnings data.

**Query Parameters:**
- `search` - Search by seller name or email
- `status` - Filter by payout status (unpaid, paid, all)
- `date_from` - Filter by start date
- `date_to` - Filter by end date
- `limit` - Number of results per page (default: 50)
- `offset` - Pagination offset

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "seller_id": 1,
      "seller_name": "John Doe",
      "seller_email": "john@example.com",
      "total_sales": 25,
      "notes_sold": 5,
      "total_earnings": 250.00,
      "unpaid_earnings": 50.00,
      "paid_earnings": 200.00,
      "first_sale_date": "2024-01-15",
      "last_sale_date": "2024-02-15"
    }
  ],
  "total": 10,
  "page": 1,
  "limit": 50,
  "summary": {
    "total_sellers": 10,
    "total_earnings": 5000.00,
    "total_unpaid": 1200.00,
    "total_paid": 3800.00
  }
}
```

### PUT /api/admin/seller-earnings.php
Mark seller earnings as paid.

**Request Body:**
```json
{
  "seller_id": 1,
  "payout_method": "PayPal",
  "payout_reference": "PAYPAL-12345",
  "notes": "Paid via PayPal on Feb 17, 2026"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Payout marked as paid successfully",
  "transactions_updated": 5,
  "total_paid": 250.00
}
```

## Usage Instructions

### Accessing the Payouts Tab
1. Log in as an admin user
2. Navigate to Admin Dashboard
3. Click on "Seller Payouts" tab

### Viewing Seller Earnings
- The tab displays all sellers with completed transactions
- Use the search box to find specific sellers
- Use the status filter to show unpaid, paid, or all earnings

### Processing a Payout
1. Find the seller in the list
2. Click "Mark as Paid" button (only shown if unpaid earnings > 0)
3. Enter the payout method (e.g., "PayPal", "Bank Transfer")
4. Optionally enter a reference number
5. Optionally add notes
6. Confirm the payment

### Viewing Seller Details
1. Click "View Details" button for any seller
2. A modal will show all transactions for that seller
3. See transaction-level details including payout status

### Exporting Data
1. Apply any desired filters
2. Click "Export CSV" button
3. CSV file will download with current filtered data

## Security Features

- Admin authentication required for all endpoints
- SQL injection prevention with prepared statements
- Activity logging for all payout actions
- Database transactions for data integrity

## Activity Logging

All payout actions are logged in the `activity_logs` table with:
- Admin user ID
- Action type: 'mark_payout'
- Entity type: 'seller'
- Entity ID: seller_id
- Details: JSON with transaction count and amount

## Notes

- Only completed transactions are included in earnings calculations
- Seller earnings are calculated as: `amount - platform_fee`
- Payout status defaults to 'unpaid' for new transactions
- When marking as paid, ALL unpaid completed transactions for that seller are updated
- Refunded transactions do not count towards earnings

## Future Enhancements

Potential improvements for this feature:
- Automatic PayPal integration for payouts
- Scheduled payout processing
- Email notifications to sellers
- Minimum payout threshold settings
- Payout history tracking
- Seller payout dashboard (for sellers to view their own earnings)
