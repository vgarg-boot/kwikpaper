﻿<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        .page-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 4rem 0;
            color: white;
            text-align: center;
        }
        
        .page-header h1 {
            font-size: 3rem;
            margin: 0 0 1rem 0;
            font-weight: 700;
        }
        
        .page-header p {
            font-size: 1.3rem;
            opacity: 0.95;
            margin: 0;
        }
        
        .content-section {
            padding: 4rem 0;
        }

        .mission-section {
            max-width: 900px;
            margin: 0 auto;
            text-align: center;
        }

        .mission-section h2 {
            font-size: 2.5rem;
            color: #2c3e50;
            margin-bottom: 2rem;
        }

        .mission-section p {
            font-size: 1.15rem;
            line-height: 1.8;
            color: #555;
        }

        .about-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }

        .about-card {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            transition: all 0.3s;
            text-align: center;
        }

        .about-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }

        .about-card .icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: #667eea;
        }

        .about-card .icon i {
            display: inline-block;
        }

        .about-card h3 {
            font-size: 1.5rem;
            color: #2c3e50;
            margin: 1rem 0;
        }

        .about-card p {
            color: #666;
            line-height: 1.6;
            margin: 0;
        }

        .stats-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 3rem;
            text-align: center;
            margin-top: 2rem;
        }

        .stat-item {
            padding: 2rem;
        }

        .stat-number {
            display: block;
            font-size: 3.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            font-size: 1.1rem;
            color: #666;
            font-weight: 500;
        }

        .cta-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 4rem 0;
            text-align: center;
        }

        .cta-section h2 {
            font-size: 2.5rem;
            margin: 0 0 1rem 0;
            color: white;
        }

        .cta-section p {
            font-size: 1.2rem;
            opacity: 0.95;
            margin-bottom: 2rem;
        }

        .cta-section .btn-primary {
            background: white;
            color: #667eea;
            padding: 1rem 2.5rem;
            font-size: 1.1rem;
            text-decoration: none;
            border-radius: 10px;
            display: inline-block;
            font-weight: 600;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .cta-section .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body>
    <nav>
        <div class="container nav-container">
            <div class="logo">
                <a href="index.php">KwikPaper</a>
            </div>
            <div class="nav-links">
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="upload.php">Upload</a>
                    <a href="my-notes.php">My Notes</a>
                    <a href="profile.php">Profile</a>
                    <a href="api/auth/logout.php" class="btn-primary">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                    <a href="register.php" class="btn-primary">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="page-header">
        <div class="container">
            <h1>About KwikPaper</h1>
            <p>Empowering students through shared knowledge</p>
        </div>
    </div>

    <section class="content-section">
        <div class="container mission-section">
            <h2>Our Mission</h2>
            <p>
                KwikPaper is a student-driven marketplace designed to make quality study materials accessible to everyone. 
                We believe that education shouldn't be limited by the availability of good notes. Our platform connects 
                students who create exceptional study materials with those who need them, fostering a collaborative 
                learning environment where knowledge flows freely.
            </p>
            <p style="margin-top: 1.5rem;">
                Whether you're looking to earn from your hard work or searching for the perfect study companion, 
                KwikPaper is your trusted partner in academic success. We're building a community where students 
                help students, one note at a time.
            </p>
        </div>
    </section>

    <section class="content-section" style="background: #f8f9fa;">
        <div class="container">
            <h2 style="text-align: center; margin-bottom: 3rem; color: #333;">What Makes Us Different</h2>
            <div class="about-grid">
                <div class="about-card">
                    <div class="icon"><i class="fas fa-book"></i></div>
                    <h3>Quality First</h3>
                    <p>Every note on our platform is created by students who've excelled in their courses. We prioritize quality to ensure you get the best study materials.</p>
                </div>
                <div class="about-card">
                    <div class="icon"><i class="fas fa-dollar-sign"></i></div>
                    <h3>Fair Pricing</h3>
                    <p>Sellers set their own prices, and buyers get value for money. Plus, we offer plenty of free notes to support students on any budget.</p>
                </div>
                <div class="about-card">
                    <div class="icon"><i class="fas fa-shield-alt"></i></div>
                    <h3>Secure & Safe</h3>
                    <p>Your data and transactions are protected. We maintain a secure platform where you can buy and sell with confidence.</p>
                </div>
                <div class="about-card">
                    <div class="icon"><i class="fas fa-users"></i></div>
                    <h3>Community Driven</h3>
                    <p>Built by students, for students. Our community reviews help you find the best notes and sellers can improve based on feedback.</p>
                </div>
                <div class="about-card">
                    <div class="icon"><i class="fas fa-bolt"></i></div>
                    <h3>Instant Access</h3>
                    <p>Download your notes immediately after purchase. No waiting, no hassleâ€”just instant access to the materials you need.</p>
                </div>
                <div class="about-card">
                    <div class="icon"><i class="fas fa-check-circle"></i></div>
                    <h3>Easy to Use</h3>
                    <p>Our intuitive platform makes it simple to upload, browse, and purchase notes. Get started in minutes, not hours.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="content-section">
        <div class="container">
            <h2 style="text-align: center; margin-bottom: 2rem; color: #333;">KwikPaper by the Numbers</h2>
            <div class="stats-section">
                <div class="stat-item">
                    <span class="stat-number">10,000+</span>
                    <div class="stat-label">Quality Notes</div>
                </div>
                <div class="stat-item">
                    <span class="stat-number">5,000+</span>
                    <div class="stat-label">Active Students</div>
                </div>
                <div class="stat-item">
                    <span class="stat-number">50+</span>
                    <div class="stat-label">Universities</div>
                </div>
                <div class="stat-item">
                    <span class="stat-number">98%</span>
                    <div class="stat-label">Satisfaction Rate</div>
                </div>
            </div>
        </div>
    </section>

    <section class="cta-section">
        <div class="container">
            <h2>Join Our Community Today</h2>
            <p>Whether you're here to share your knowledge or find the perfect study materials, KwikPaper has something for everyone.</p>
            <?php if (!isset($_SESSION['user_id'])): ?>
                <a href="register.php" class="btn-primary">Get Started Free</a>
            <?php else: ?>
                <a href="browse.php" class="btn-primary">Browse Notes</a>
            <?php endif; ?>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="how-it-works.php">How It Works</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="browse.php">Help Center</a></li>
                        <li><a href="index.php" onclick="alert('Contact form coming soon! For now, please reach out via social media.'); return false;">Contact Us</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a></li>
                        <li><a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a></li>
                        <li><a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
</body>
</html>