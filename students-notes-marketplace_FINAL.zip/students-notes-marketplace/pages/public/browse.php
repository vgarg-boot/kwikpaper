﻿<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Notes - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        .browse-section {
            background: #f8f9fa;
            padding: 2rem 0 4rem;
            min-height: calc(100vh - 300px);
        }
        
        .browse-header {
            background: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .browse-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .browse-title h2 {
            font-size: 2rem;
            color: #2c3e50;
            margin: 0;
        }
        
        .results-info {
            color: #6c757d;
            font-size: 0.95rem;
        }
        
        .search-bar-container {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .search-box {
            flex: 1;
            position: relative;
        }
        
        .search-box input {
            width: 100%;
            padding: 1rem 1rem 1rem 3rem;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            font-size: 1rem;
            transition: all 0.3s;
            background: #f8f9fa;
        }
        
        .search-box input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .search-box::before {
            content: "🔍";
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.2rem;
        }
        
        .view-toggle {
            display: flex;
            gap: 0.5rem;
            background: #e9ecef;
            padding: 0.3rem;
            border-radius: 10px;
        }
        
        .view-btn {
            padding: 0.6rem 1rem;
            border: none;
            background: transparent;
            cursor: pointer;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 1.2rem;
        }
        
        .view-btn.active {
            background: white;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .browse-content {
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 2rem;
        }
        
        .filters-sidebar {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
            height: fit-content;
            position: sticky;
            top: 100px;
        }
        
        .filter-section {
            margin-bottom: 2rem;
            padding-bottom: 1.5rem;
            border-bottom: 1px solid #e9ecef;
        }
        
        .filter-section:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }
        
        .filter-section h3 {
            font-size: 1rem;
            color: #2c3e50;
            margin: 0 0 1rem 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .filter-option {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.6rem;
            margin-bottom: 0.5rem;
            cursor: pointer;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .filter-option:hover {
            background: #f8f9fa;
        }
        
        .filter-option input[type="checkbox"],
        .filter-option input[type="radio"] {
            cursor: pointer;
        }
        
        .filter-option label {
            cursor: pointer;
            flex: 1;
            font-size: 0.9rem;
            color: #2c3e50;
        }
        
        .filter-count {
            color: #6c757d;
            font-size: 0.85rem;
        }
        
        .price-range {
            display: flex;
            gap: 0.5rem;
            align-items: center;
        }
        
        .price-range input {
            width: 100%;
            padding: 0.5rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.9rem;
        }
        
        .clear-filters {
            width: 100%;
            padding: 0.7rem;
            background: transparent;
            color: #667eea;
            border: 2px solid #667eea;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .clear-filters:hover {
            background: #667eea;
            color: white;
        }
        
        .browse-main {
            flex: 1;
        }
        
        .filter-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }
        
        .filter-tag {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            background: white;
            border: 2px solid #667eea;
            color: #667eea;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .filter-tag button {
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1.1rem;
            color: #667eea;
            padding: 0;
            line-height: 1;
        }
        
        .sort-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        
        .sort-select {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .sort-select select {
            padding: 0.6rem 1rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 0.9rem;
            cursor: pointer;
            background: white;
        }
        
        .notes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .notes-grid.list-view {
            grid-template-columns: 1fr;
        }
        
        .note-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
            display: flex;
            flex-direction: column;
        }
        
        .note-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
        }
        
        .note-card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1rem;
            color: white;
            min-height: 80px;
            display: flex;
            align-items: center;
        }
        
        .note-card-body {
            padding: 1.5rem;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        
        .note-card h3 {
            margin: 0 0 1rem 0;
            color: #2c3e50;
            font-size: 1.1rem;
            line-height: 1.4;
        }
        
        .note-card p {
            color: #6c757d;
            font-size: 0.9rem;
            margin: 0 0 1rem 0;
            line-height: 1.6;
            flex: 1;
        }
        
        .note-badges {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }
        
        .note-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.3rem;
            padding: 0.3rem 0.7rem;
            background: #f8f9fa;
            border-radius: 15px;
            font-size: 0.8rem;
            color: #6c757d;
        }
        
        .note-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 1rem;
            border-top: 1px solid #e9ecef;
            margin-bottom: 1rem;
        }
        
        .note-meta .author {
            font-size: 0.85rem;
            color: #6c757d;
        }
        
        .note-meta .rating {
            font-size: 0.9rem;
            color: #ffa500;
        }
        
        .note-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .note-footer .price {
            font-size: 1.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .note-footer a {
            padding: 0.6rem 1.2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s;
        }
        
        .note-footer a:hover {
            transform: translateX(3px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        
        .notes-grid.list-view .note-card {
            flex-direction: row;
        }
        
        .notes-grid.list-view .note-card-header {
            min-width: 200px;
            max-width: 200px;
        }
        
        .notes-grid.list-view .note-card-body {
            flex-direction: row;
            align-items: center;
        }
        
        .notes-grid.list-view .note-card h3 {
            margin-bottom: 0.5rem;
        }
        
        .loading-container {
            text-align: center;
            padding: 4rem 0;
        }
        
        .loading-spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
        }
        
        .empty-state-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
        }
        
        .empty-state h3 {
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .empty-state p {
            color: #6c757d;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin-top: 2rem;
        }
        
        .pagination button {
            padding: 0.7rem 1.2rem;
            border: 2px solid #e9ecef;
            background: white;
            color: #2c3e50;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .pagination button:hover {
            border-color: #667eea;
            color: #667eea;
        }
        
        .pagination button.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
        }
        
        @media (max-width: 968px) {
            .browse-content {
                grid-template-columns: 1fr;
            }
            
            .filters-sidebar {
                position: static;
            }
            
            .notes-grid {
                grid-template-columns: 1fr;
            }
            
            .search-bar-container {
                flex-direction: column;
            }
            
            .view-toggle {
                align-self: flex-start;
            }
            
            .notes-grid.list-view .note-card {
                flex-direction: column;
            }
            
            .notes-grid.list-view .note-card-header {
                min-width: 100%;
                max-width: 100%;
            }
            
            .notes-grid.list-view .note-card-body {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>KwikPaper</h1>
            </div>
            <nav>
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <a href="upload.php">Upload</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="dashboard.php">Dashboard</a>
                <?php endif; ?>
            </nav>
            <div class="nav-search">
                <input type="text" placeholder="Search notes..." id="navSearch">
            </div>
            <nav class="nav-right">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <span class="admin-badge">ADMIN</span>
                    <?php endif; ?>
                    <span class="user-welcome">👋 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <a href="admin.php" class="btn-admin" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0.6rem 1.2rem; border-radius: 8px; text-decoration: none; font-weight: 600;">Admin</a>
                    <?php endif; ?>
                    <a href="dashboard.php" class="btn-dashboard">Dashboard</a>
                    <a href="api/auth/logout.php" class="btn-logout">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="btn-login">Login</a>
                    <a href="register.php" class="btn-register">Register</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <section class="browse-section">
        <div class="browse-header">
            <div class="container">
                <div class="browse-title">
                    <h2>📚 Browse All Notes</h2>
                    <span class="results-info" id="resultsInfo">Loading...</span>
                </div>
                <div class="search-bar-container">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Search by title, category, or university...">
                    </div>
                    <div class="view-toggle">
                        <button class="view-btn active" id="gridViewBtn" title="Grid View">📱</button>
                        <button class="view-btn" id="listViewBtn" title="List View">📋</button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="container">
            <div class="browse-content">
                <!-- Filters Sidebar -->
                <aside class="filters-sidebar">
                    <div class="filter-section">
                        <h3>📂 Categories</h3>
                        <div class="filter-option">
                            <input type="radio" name="category" value="all" id="cat-all" checked>
                            <label for="cat-all">All Categories</label>
                        </div>
                        <div class="filter-option">
                            <input type="radio" name="category" value="science" id="cat-science">
                            <label for="cat-science">🔬 Science</label>
                        </div>
                        <div class="filter-option">
                            <input type="radio" name="category" value="math" id="cat-math">
                            <label for="cat-math">➗ Mathematics</label>
                        </div>
                        <div class="filter-option">
                            <input type="radio" name="category" value="history" id="cat-history">
                            <label for="cat-history">📜 History</label>
                        </div>
                        <div class="filter-option">
                            <input type="radio" name="category" value="language" id="cat-language">
                            <label for="cat-language">🗣️ Language</label>
                        </div>
                        <div class="filter-option">
                            <input type="radio" name="category" value="cs" id="cat-cs">
                            <label for="cat-cs">💻 Computer Science</label>
                        </div>
                        <div class="filter-option">
                            <input type="radio" name="category" value="engineering" id="cat-engineering">
                            <label for="cat-engineering">⚙️ Engineering</label>
                        </div>
                        <div class="filter-option">
                            <input type="radio" name="category" value="business" id="cat-business">
                            <label for="cat-business">💼 Business</label>
                        </div>
                    </div>
                    
                    <div class="filter-section">
                        <h3>💰 Price Range</h3>
                        <div class="price-range">
                            <input type="number" id="minPrice" placeholder="Min" min="0" step="0.01">
                            <span>-</span>
                            <input type="number" id="maxPrice" placeholder="Max" min="0" step="0.01">
                        </div>
                    </div>
                    
                    <div class="filter-section">
                        <h3>⭐ Rating</h3>
                        <div class="filter-option">
                            <input type="radio" name="rating" value="all" id="rating-all" checked>
                            <label for="rating-all">All Ratings</label>
                        </div>
                        <div class="filter-option">
                            <input type="radio" name="rating" value="4" id="rating-4">
                            <label for="rating-4">⭐⭐⭐⭐ & up</label>
                        </div>
                        <div class="filter-option">
                            <input type="radio" name="rating" value="3" id="rating-3">
                            <label for="rating-3">⭐⭐⭐ & up</label>
                        </div>
                    </div>
                    
                    <button class="clear-filters" id="clearFilters">
                        🔄 Clear All Filters
                    </button>
                </aside>
                
                <!-- Main Content -->
                <div class="browse-main">
                    <!-- Active Filter Tags -->
                    <div id="activeFilterTags" class="filter-tags"></div>
                    
                    <!-- Sort Bar -->
                    <div class="sort-bar">
                        <div class="sort-select">
                            <label for="sortBy">Sort by:</label>
                            <select id="sortBy">
                                <option value="newest">Newest First</option>
                                <option value="popular">Most Popular</option>
                                <option value="price-low">Price: Low to High</option>
                                <option value="price-high">Price: High to Low</option>
                                <option value="rating">Highest Rated</option>
                            </select>
                        </div>
                    </div>
                    
                    <!-- Notes Grid -->
                    <div class="notes-grid" id="notesGrid">
                        <div class="loading-container">
                            <div class="loading-spinner"></div>
                            <p>Loading notes...</p>
                        </div>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="pagination" id="pagination"></div>
                </div>
            </div>
        </div>
    </section>
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="how-it-works.php">How It Works</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="browse.php">Help Center</a></li>
                        <li><a href="index.php" onclick="alert('Contact form coming soon! For now, please reach out via social media.'); return false;">Contact Us</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a></li>
                        <li><a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a></li>
                        <li><a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>
    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
    <script>
        let currentPage = 1;
        let viewMode = 'grid'; // 'grid' or 'list'
        let filters = {
            category: 'all',
            minPrice: null,
            maxPrice: null,
            rating: 'all',
            search: '',
            sortBy: 'newest'
        };
        
        // View Toggle
        document.getElementById('gridViewBtn').addEventListener('click', function() {
            viewMode = 'grid';
            document.getElementById('notesGrid').classList.remove('list-view');
            this.classList.add('active');
            document.getElementById('listViewBtn').classList.remove('active');
        });
        
        document.getElementById('listViewBtn').addEventListener('click', function() {
            viewMode = 'list';
            document.getElementById('notesGrid').classList.add('list-view');
            this.classList.add('active');
            document.getElementById('gridViewBtn').classList.remove('active');
        });
        
        // Filter Handlers
        document.querySelectorAll('input[name="category"]').forEach(input => {
            input.addEventListener('change', function() {
                filters.category = this.value;
                currentPage = 1;
                updateFilterTags();
                loadNotes();
            });
        });
        
        document.querySelectorAll('input[name="rating"]').forEach(input => {
            input.addEventListener('change', function() {
                filters.rating = this.value;
                currentPage = 1;
                updateFilterTags();
                loadNotes();
            });
        });
        
        document.getElementById('minPrice').addEventListener('change', function() {
            filters.minPrice = this.value ? parseFloat(this.value) : null;
            currentPage = 1;
            updateFilterTags();
            loadNotes();
        });
        
        document.getElementById('maxPrice').addEventListener('change', function() {
            filters.maxPrice = this.value ? parseFloat(this.value) : null;
            currentPage = 1;
            updateFilterTags();
            loadNotes();
        });
        
        document.getElementById('searchInput').addEventListener('input', function() {
            console.log('Search input changed:', this.value);
            filters.search = this.value;
            currentPage = 1;
            updateFilterTags();
            loadNotes();
        });
        
        document.getElementById('sortBy').addEventListener('change', function() {
            filters.sortBy = this.value;
            loadNotes();
        });
        
        document.getElementById('clearFilters').addEventListener('click', function() {
            // Reset all filters
            filters = {
                category: 'all',
                minPrice: null,
                maxPrice: null,
                rating: 'all',
                search: '',
                sortBy: 'newest'
            };
            
            // Reset UI
            document.getElementById('cat-all').checked = true;
            document.getElementById('rating-all').checked = true;
            document.getElementById('minPrice').value = '';
            document.getElementById('maxPrice').value = '';
            document.getElementById('searchInput').value = '';
            document.getElementById('sortBy').value = 'newest';
            
            currentPage = 1;
            updateFilterTags();
            loadNotes();
        });
        
        function updateFilterTags() {
            const tagsContainer = document.getElementById('activeFilterTags');
            let tags = [];
            
            if (filters.category !== 'all') {
                tags.push({ label: filters.category, type: 'category' });
            }
            
            if (filters.rating !== 'all') {
                tags.push({ label: `${filters.rating}+ stars`, type: 'rating' });
            }
            
            if (filters.minPrice !== null || filters.maxPrice !== null) {
                const priceLabel = `$${filters.minPrice || 0} - $${filters.maxPrice || '∞'}`;
                tags.push({ label: priceLabel, type: 'price' });
            }
            
            if (filters.search) {
                tags.push({ label: `"${filters.search}"`, type: 'search' });
            }
            
            if (tags.length === 0) {
                tagsContainer.innerHTML = '';
                return;
            }
            
            tagsContainer.innerHTML = tags.map(tag => `
                <div class="filter-tag">
                    <span>${tag.label}</span>
                    <button onclick="removeFilter('${tag.type}')">×</button>
                </div>
            `).join('');
        }
        
        function removeFilter(type) {
            switch(type) {
                case 'category':
                    filters.category = 'all';
                    document.getElementById('cat-all').checked = true;
                    break;
                case 'rating':
                    filters.rating = 'all';
                    document.getElementById('rating-all').checked = true;
                    break;
                case 'price':
                    filters.minPrice = null;
                    filters.maxPrice = null;
                    document.getElementById('minPrice').value = '';
                    document.getElementById('maxPrice').value = '';
                    break;
                case 'search':
                    filters.search = '';
                    document.getElementById('searchInput').value = '';
                    break;
            }
            currentPage = 1;
            updateFilterTags();
            loadNotes();
        }
        
        async function loadNotes() {
            const container = document.getElementById('notesGrid');
            const pagination = document.getElementById('pagination');
            const resultsInfo = document.getElementById('resultsInfo');
            
            // Show loading state
            container.innerHTML = `
                <div class="loading-container">
                    <div class="loading-spinner"></div>
                    <p>Loading notes...</p>
                </div>
            `;
            
            try {
                console.log('Loading notes with filters:', filters);
                console.log('Current page:', currentPage);
                console.log('Search term:', filters.search);
                
                const result = await NotesAPI.list(
                    currentPage, 
                    12, 
                    filters.category, 
                    filters.search
                );
                
                console.log('API Result:', result);
                console.log('API URL:', `api/notes/list.php?page=${currentPage}&limit=12&category=${filters.category}&search=${encodeURIComponent(filters.search)}`);
                
                if (result.success && result.data && result.data.length > 0) {
                    let notes = result.data;
                    
                    // Apply client-side filtering
                    notes = filterNotes(notes);
                    
                    // Apply sorting
                    notes = sortNotes(notes);
                    
                    console.log('Filtered & sorted notes:', notes);
                    
                    // Update results info
                    const total = notes.length;
                    resultsInfo.textContent = `${total} note${total !== 1 ? 's' : ''} found`;
                    
                    // Render notes
                    if (notes.length > 0) {
                        container.innerHTML = notes.map(note => createNoteCard(note)).join('');
                    } else {
                        container.innerHTML = `
                            <div class="empty-state">
                                <div class="empty-state-icon">📚</div>
                                <h3>No Notes Match Your Filters</h3>
                                <p>Try adjusting your filters or search terms</p>
                            </div>
                        `;
                    }
                    
                    // Pagination
                    if (result.pagination && result.pagination.total_pages > 1) {
                        renderPagination(result.pagination);
                    } else {
                        pagination.innerHTML = '';
                    }
                } else {
                    console.log('No notes found or error:', result);
                    resultsInfo.textContent = '0 notes found';
                    container.innerHTML = `
                        <div class="empty-state">
                            <div class="empty-state-icon">📚</div>
                            <h3>No Notes Found</h3>
                            <p>${result.message || 'Try adjusting your filters or search terms'}</p>
                        </div>
                    `;
                    pagination.innerHTML = '';
                }
            } catch (error) {
                console.error('Error loading notes:', error);
                resultsInfo.textContent = 'Error loading notes';
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">❌</div>
                        <h3>Error Loading Notes</h3>
                        <p>Please check if the database is running and try again.</p>
                    </div>
                `;
                pagination.innerHTML = '';
            }
        }
        
        function filterNotes(notes) {
            return notes.filter(note => {
                // Price filter
                if (filters.minPrice !== null && note.price < filters.minPrice) return false;
                if (filters.maxPrice !== null && note.price > filters.maxPrice) return false;
                
                // Rating filter
                if (filters.rating !== 'all') {
                    const minRating = parseInt(filters.rating);
                    const noteRating = parseFloat(note.rating) || 0;
                    if (noteRating < minRating) return false;
                }
                
                return true;
            });
        }
        
        function sortNotes(notes) {
            const sorted = [...notes];
            
            switch(filters.sortBy) {
                case 'popular':
                    sorted.sort((a, b) => (b.purchased_count || 0) - (a.purchased_count || 0));
                    break;
                case 'price-low':
                    sorted.sort((a, b) => a.price - b.price);
                    break;
                case 'price-high':
                    sorted.sort((a, b) => b.price - a.price);
                    break;
                case 'rating':
                    sorted.sort((a, b) => (parseFloat(b.rating) || 0) - (parseFloat(a.rating) || 0));
                    break;
                case 'newest':
                default:
                    // Already sorted by newest from API
                    break;
            }
            
            return sorted;
        }
        
        function createNoteCard(note) {
            const categoryIcons = {
                'science': '🔬',
                'math': '➗',
                'history': '📜',
                'language': '🗣️',
                'cs': '💻',
                'engineering': '⚙️',
                'business': '💼',
                'arts': '🎨'
            };
            
            const icon = categoryIcons[note.category] || '📚';
            const title = Utils.escapeHtml(note.title || 'Untitled');
            const description = note.description ? Utils.escapeHtml(note.description.substring(0, 120)) + '...' : 'No description available';
            const category = note.category ? note.category.charAt(0).toUpperCase() + note.category.slice(1) : 'General';
            const username = Utils.escapeHtml(note.username || 'Anonymous');
            const rating = note.rating && !isNaN(note.rating) ? parseFloat(note.rating).toFixed(1) : '5.0';
            
            return `
                <div class="note-card" data-category="${note.category || 'general'}">
                    <div class="note-card-header">
                        <h3 style="color: white; margin: 0; font-size: 1.1rem;">${icon} ${category}</h3>
                    </div>
                    <div class="note-card-body">
                        <div style="flex: 1;">
                            <h3>${title}</h3>
                            <p>${description}</p>
                            
                            <div class="note-badges">
                                ${note.pages ? `<span class="note-badge">📄 ${note.pages} pages</span>` : ''}
                                ${note.university ? `<span class="note-badge">🎓 ${Utils.escapeHtml(note.university)}</span>` : ''}
                                <span class="note-badge">🛒 ${note.purchased_count || 0} purchased</span>
                            </div>
                            
                            <div class="note-meta">
                                <span class="author">By ${username}</span>
                                <span class="rating">⭐ ${rating}</span>
                            </div>
                            
                            <div class="note-footer">
                                <span class="price" style="${(note.is_free || !note.price || parseFloat(note.price) === 0) ? 'background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%); color: #065c3b; padding: 0.5rem 1rem; border-radius: 20px; font-weight: 700;' : ''}">${(note.is_free || !note.price || parseFloat(note.price) === 0) ? '🎁 FREE' : Utils.formatPrice(note.price)}</span>
                                <a href="note-detail.php?id=${note.id}">View Details →</a>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }
        
        function renderPagination(paginationData) {
            const pagination = document.getElementById('pagination');
            const totalPages = paginationData.total_pages;
            
            let html = '';
            
            // Previous button
            if (currentPage > 1) {
                html += `<button onclick="changePage(${currentPage - 1})">← Previous</button>`;
            }
            
            // Page numbers
            for (let i = 1; i <= totalPages; i++) {
                if (
                    i === 1 || 
                    i === totalPages || 
                    (i >= currentPage - 1 && i <= currentPage + 1)
                ) {
                    html += `<button onclick="changePage(${i})" class="${i === currentPage ? 'active' : ''}">${i}</button>`;
                } else if (i === currentPage - 2 || i === currentPage + 2) {
                    html += `<button disabled>...</button>`;
                }
            }
            
            // Next button
            if (currentPage < totalPages) {
                html += `<button onclick="changePage(${currentPage + 1})">Next →</button>`;
            }
            
            pagination.innerHTML = html;
        }
        
        function changePage(page) {
            currentPage = page;
            loadNotes();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
        
        // Initial load
        loadNotes();
    </script>
</body>
</html>
