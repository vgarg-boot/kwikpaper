﻿<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms of Service - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        .page-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 4rem 0;
            color: white;
            text-align: center;
        }
        
        .page-header h1 {
            font-size: 3rem;
            margin: 0 0 0.5rem 0;
            font-weight: 700;
        }
        
        .page-header p {
            font-size: 1.1rem;
            opacity: 0.95;
            margin: 0;
        }

        .content-section {
            padding: 4rem 0;
            background: #f8f9fa;
        }

        .terms-container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            padding: 3rem;
            border-radius: 15px;
            box-shadow: 0 5px 30px rgba(0,0,0,0.08);
        }

        .terms-update {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 3rem;
            border-left: 4px solid #667eea;
            line-height: 1.7;
        }

        .terms-update strong {
            color: #667eea;
            display: block;
            margin-bottom: 0.5rem;
            font-size: 1.1rem;
        }

        .toc {
            background: #f8f9fa;
            padding: 2rem;
            border-radius: 12px;
            margin-bottom: 3rem;
            border: 2px solid #e9ecef;
        }

        .toc h3 {
            color: #2c3e50;
            font-size: 1.5rem;
            margin: 0 0 1.5rem 0;
            padding-bottom: 1rem;
            border-bottom: 2px solid #667eea;
        }

        .toc ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 0.8rem;
        }

        .toc ul li {
            margin: 0;
        }

        .toc a {
            color: #555;
            text-decoration: none;
            transition: all 0.3s;
            display: block;
            padding: 0.5rem;
            border-radius: 6px;
            font-weight: 500;
        }

        .toc a:hover {
            color: #667eea;
            background: white;
            padding-left: 1rem;
        }

        .terms-section {
            margin-bottom: 3rem;
            padding-bottom: 2rem;
            border-bottom: 1px solid #e9ecef;
        }

        .terms-section:last-of-type {
            border-bottom: none;
        }

        .terms-section h2 {
            color: #2c3e50;
            font-size: 2rem;
            margin: 0 0 1.5rem 0;
            padding-top: 1rem;
        }

        .terms-section h3 {
            color: #667eea;
            font-size: 1.4rem;
            margin: 2rem 0 1rem 0;
        }

        .terms-section p {
            color: #555;
            line-height: 1.8;
            margin-bottom: 1rem;
        }

        .terms-section ul {
            margin: 1rem 0 1.5rem 2rem;
            line-height: 1.8;
        }

        .terms-section ul li {
            color: #555;
            margin-bottom: 0.8rem;
            position: relative;
            padding-left: 0.5rem;
        }

        .terms-section ul li::marker {
            color: #667eea;
        }

        .highlight-box {
            background: linear-gradient(135deg, #fff9e6 0%, #fff3d6 100%);
            padding: 1.5rem;
            border-radius: 12px;
            border-left: 4px solid #ffc107;
            margin: 2rem 0;
        }

        .highlight-box strong {
            color: #d68910;
            display: block;
            margin-bottom: 0.5rem;
            font-size: 1.05rem;
        }

        .terms-section a {
            color: #667eea;
            text-decoration: none;
            transition: color 0.3s;
        }

        .terms-section a:hover {
            color: #764ba2;
            text-decoration: underline;
        }

        /* Smooth scroll behavior */
        html {
            scroll-behavior: smooth;
            scroll-padding-top: 100px;
        }

        /* Target section highlight */
        .terms-section:target {
            animation: highlight 2s ease-in-out;
        }

        @keyframes highlight {
            0%, 100% { background: transparent; }
            50% { background: #667eea15; }
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .terms-container {
                padding: 2rem 1.5rem;
            }

            .page-header h1 {
                font-size: 2rem;
            }

            .toc ul {
                grid-template-columns: 1fr;
            }

            .terms-section h2 {
                font-size: 1.6rem;
            }
        }

        /* Scroll to top button */
        .scroll-to-top {
            position: fixed;
            bottom: 2rem;
            right: 2rem;
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s;
            z-index: 1000;
        }

        .scroll-to-top.visible {
            opacity: 1;
            visibility: visible;
        }

        .scroll-to-top:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 25px rgba(102, 126, 234, 0.5);
        }
    </style>

</head>
<body>
    <nav>
        <div class="container nav-container">
            <div class="logo">
                <a href="index.php">KwikPaper</a>
            </div>
            <div class="nav-links">
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="upload.php">Upload</a>
                    <a href="my-notes.php">My Notes</a>
                    <a href="profile.php">Profile</a>
                    <a href="api/auth/logout.php" class="btn-primary">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                    <a href="register.php" class="btn-primary">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="page-header">
        <div class="container">
            <h1>Terms of Service</h1>
            <p>Last updated: February 14, 2026</p>
        </div>
    </div>

    <section class="content-section">
        <div class="container">
            <div class="terms-container">
                <div class="terms-update">
                    <strong>Please read these Terms of Service carefully.</strong> By accessing or using KwikPaper, you agree to be bound by these terms. If you do not agree to these terms, please do not use our platform.
                </div>

                <div class="toc">
                    <h3>Table of Contents</h3>
                    <ul>
                        <li><a href="#acceptance">1. Acceptance of Terms</a></li>
                        <li><a href="#eligibility">2. Eligibility</a></li>
                        <li><a href="#accounts">3. User Accounts</a></li>
                        <li><a href="#content">4. User Content and Intellectual Property</a></li>
                        <li><a href="#prohibited">5. Prohibited Activities</a></li>
                        <li><a href="#buying">6. Buying Notes</a></li>
                        <li><a href="#selling">7. Selling Notes</a></li>
                        <li><a href="#payment">8. Payment and Fees</a></li>
                        <li><a href="#termination">9. Termination</a></li>
                        <li><a href="#disclaimer">10. Disclaimer of Warranties</a></li>
                        <li><a href="#limitation">11. Limitation of Liability</a></li>
                        <li><a href="#privacy">12. Privacy</a></li>
                        <li><a href="#changes">13. Changes to Terms</a></li>
                        <li><a href="#contact">14. Contact Information</a></li>
                    </ul>
                </div>

                <div class="terms-section" id="acceptance">
                    <h2>1. Acceptance of Terms</h2>
                    <p>
                        By creating an account, accessing, or using KwikPaper ("the Platform", "we", "us", or "our"), you agree to comply with and be bound by these Terms of Service. These terms constitute a legally binding agreement between you and KwikPaper.
                    </p>
                    <p>
                        If you are using the Platform on behalf of an organization, you represent and warrant that you have the authority to bind that organization to these terms.
                    </p>
                </div>

                <div class="terms-section" id="eligibility">
                    <h2>2. Eligibility</h2>
                    <p>To use KwikPaper, you must:</p>
                    <ul>
                        <li>Be at least 13 years of age (or the age of majority in your jurisdiction)</li>
                        <li>Have the legal capacity to enter into a binding agreement</li>
                        <li>Not be prohibited from using the Platform under applicable laws</li>
                        <li>Provide accurate and complete information during registration</li>
                    </ul>
                    <p>
                        If you are under 18, you represent that you have permission from a parent or guardian to use the Platform.
                    </p>
                </div>

                <div class="terms-section" id="accounts">
                    <h2>3. User Accounts</h2>
                    
                    <h3>3.1 Account Creation</h3>
                    <p>
                        You must create an account to access certain features of the Platform. You agree to provide accurate, current, and complete information and to update such information to keep it accurate, current, and complete.
                    </p>
                    
                    <h3>3.2 Account Security</h3>
                    <p>
                        You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You agree to:
                    </p>
                    <ul>
                        <li>Use a strong, unique password</li>
                        <li>Not share your account credentials with others</li>
                        <li>Notify us immediately of any unauthorized access or security breach</li>
                        <li>Log out of your account at the end of each session</li>
                    </ul>
                    
                    <h3>3.3 Account Information</h3>
                    <p>
                        You may not create an account using a false identity, impersonate another person, or use a username that is offensive, vulgar, or violates anyone's rights.
                    </p>
                </div>

                <div class="terms-section" id="content">
                    <h2>4. User Content and Intellectual Property</h2>
                    
                    <h3>4.1 Ownership of Content</h3>
                    <p>
                        You retain ownership of any content you upload to the Platform, including study notes, descriptions, and profile information ("User Content"). By uploading User Content, you grant KwikPaper a worldwide, non-exclusive, royalty-free license to host, store, display, and distribute your content as necessary to operate the Platform.
                    </p>
                    
                    <h3>4.2 Content Requirements</h3>
                    <p>You represent and warrant that your User Content:</p>
                    <ul>
                        <li>Is your original work or you have the legal right to share it</li>
                        <li>Does not infringe on any third-party intellectual property rights</li>
                        <li>Does not contain copyrighted material unless you own the copyright or have permission</li>
                        <li>Does not violate any laws or regulations</li>
                        <li>Does not contain malicious code, viruses, or harmful components</li>
                    </ul>
                    
                    <div class="highlight-box">
                        <strong>Important:</strong> You may only upload notes that you personally created. Do not upload copyrighted textbooks, published materials, unauthorized lecture recordings, exam questions, or any content you do not have the right to distribute.
                    </div>
                    
                    <h3>4.3 Platform's Intellectual Property</h3>
                    <p>
                        The Platform itself, including its design, features, text, graphics, logos, and software, is owned by KwikPaper and protected by copyright and other intellectual property laws. You may not copy, modify, distribute, or create derivative works based on the Platform without our express written permission.
                    </p>
                </div>

                <div class="terms-section" id="prohibited">
                    <h2>5. Prohibited Activities</h2>
                    <p>You agree not to engage in any of the following prohibited activities:</p>
                    <ul>
                        <li>Uploading content that infringes on intellectual property rights</li>
                        <li>Sharing copyrighted materials without proper authorization</li>
                        <li>Uploading exam questions, answers, or test materials</li>
                        <li>Impersonating another person or entity</li>
                        <li>Harassing, threatening, or abusing other users</li>
                        <li>Attempting to gain unauthorized access to the Platform or other users' accounts</li>
                        <li>Using automated systems (bots, scrapers) without permission</li>
                        <li>Interfering with the proper functioning of the Platform</li>
                        <li>Posting spam, advertising, or promotional content</li>
                        <li>Manipulating reviews, ratings, or search rankings</li>
                        <li>Creating multiple accounts to circumvent restrictions</li>
                        <li>Selling or transferring your account to another party</li>
                    </ul>
                </div>

                <div class="terms-section" id="buying">
                    <h2>6. Buying Notes</h2>
                    
                    <h3>6.1 Purchases</h3>
                    <p>
                        When you purchase notes on the Platform, you receive a non-exclusive, non-transferable license to access and download the notes for your personal educational use only. You do not acquire ownership of the notes.
                    </p>
                    
                    <h3>6.2 Use of Purchased Notes</h3>
                    <p>Purchased notes may only be used for personal study purposes. You may not:</p>
                    <ul>
                        <li>Resell, redistribute, or share purchased notes with others</li>
                        <li>Post notes publicly on other websites or platforms</li>
                        <li>Use notes for commercial purposes</li>
                        <li>Claim the notes as your own work</li>
                    </ul>
                    
                    <h3>6.3 No Guarantees</h3>
                    <p>
                        KwikPaper does not guarantee the accuracy, completeness, or quality of user-uploaded notes. We encourage you to preview notes and read reviews before purchasing. Notes are provided "as is" by sellers.
                    </p>
                </div>

                <div class="terms-section" id="selling">
                    <h2>7. Selling Notes</h2>
                    
                    <h3>7.1 Seller Responsibilities</h3>
                    <p>As a seller, you agree to:</p>
                    <ul>
                        <li>Only upload original content you personally created</li>
                        <li>Ensure your notes are accurate and of reasonable quality</li>
                        <li>Provide honest and accurate descriptions</li>
                        <li>Not misrepresent the content or quality of your notes</li>
                        <li>Comply with all applicable laws and your institution's policies</li>
                    </ul>
                    
                    <h3>7.2 Pricing</h3>
                    <p>
                        Sellers set their own prices for notes. KwikPaper may establish minimum or maximum price limits. By listing notes for sale, you authorize KwikPaper to collect payment on your behalf and distribute your content to buyers.
                    </p>
                    
                    <h3>7.3 Content Removal</h3>
                    <p>
                        KwikPaper reserves the right to remove any notes that violate these terms, infringe on intellectual property rights, or are determined to be of unacceptable quality.
                    </p>
                </div>

                <div class="terms-section" id="payment">
                    <h2>8. Payment and Fees</h2>
                    
                    <h3>8.1 Payment Processing</h3>
                    <p>
                        All payments are processed through secure third-party payment processors. By making a purchase, you agree to the payment processor's terms and conditions. KwikPaper does not store your credit card information.
                    </p>
                    
                    <h3>8.2 Pricing and Fees</h3>
                    <p>
                        Prices for notes are set by sellers and displayed in your local currency. All prices are final at the time of purchase. KwikPaper may charge service fees or commissions on transactions, which will be clearly disclosed.
                    </p>
                    
                    <h3>8.3 Refund Policy</h3>
                    <p>
                        Due to the digital nature of our products, refunds are generally not available once notes have been downloaded. Exceptions may be made in cases of:
                    </p>
                    <ul>
                        <li>Technical issues preventing access to purchased notes</li>
                        <li>Notes significantly misrepresented in their description</li>
                        <li>Duplicate charges or billing errors</li>
                    </ul>
                    <p>
                        Refund requests must be submitted within 7 days of purchase and will be reviewed on a case-by-case basis.
                    </p>
                </div>

                <div class="terms-section" id="termination">
                    <h2>9. Termination</h2>
                    
                    <h3>9.1 Termination by You</h3>
                    <p>
                        You may terminate your account at any time by contacting us. Upon termination, you will lose access to your account and any purchased notes.
                    </p>
                    
                    <h3>9.2 Termination by Us</h3>
                    <p>
                        We reserve the right to suspend or terminate your account at any time, with or without notice, for violations of these terms, fraudulent activity, or any other reason we deem appropriate. We are not liable for any losses resulting from account termination.
                    </p>
                    
                    <h3>9.3 Effect of Termination</h3>
                    <p>
                        Upon termination, all licenses granted to you under these terms will immediately cease. Sections of these terms that by their nature should survive termination will remain in effect.
                    </p>
                </div>

                <div class="terms-section" id="disclaimer">
                    <h2>10. Disclaimer of Warranties</h2>
                    <p>
                        THE PLATFORM AND ALL CONTENT ARE PROVIDED "AS IS" AND "AS AVAILABLE" WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
                    </p>
                    <p>
                        We do not warrant that:
                    </p>
                    <ul>
                        <li>The Platform will be uninterrupted, secure, or error-free</li>
                        <li>The notes available on the Platform are accurate or complete</li>
                        <li>Any defects will be corrected</li>
                        <li>The Platform is free from viruses or harmful components</li>
                        <li>Results obtained from using the Platform will be reliable</li>
                    </ul>
                </div>

                <div class="terms-section" id="limitation">
                    <h2>11. Limitation of Liability</h2>
                    <p>
                        TO THE MAXIMUM EXTENT PERMITTED BY LAW, KWIKPAPER SHALL NOT BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF PROFITS OR REVENUES, WHETHER INCURRED DIRECTLY OR INDIRECTLY, OR ANY LOSS OF DATA, USE, GOODWILL, OR OTHER INTANGIBLE LOSSES.
                    </p>
                    <p>
                        Our total liability for any claims arising from your use of the Platform shall not exceed the amount you paid to us in the 12 months preceding the claim.
                    </p>
                </div>

                <div class="terms-section" id="privacy">
                    <h2>12. Privacy</h2>
                    <p>
                        Your use of the Platform is also governed by our Privacy Policy. By using KwikPaper, you consent to the collection and use of your information as described in our Privacy Policy.
                    </p>
                </div>

                <div class="terms-section" id="changes">
                    <h2>13. Changes to Terms</h2>
                    <p>
                        We reserve the right to modify these Terms of Service at any time. When we make changes, we will update the "Last updated" date at the top of this page. Significant changes will be communicated through email or a prominent notice on the Platform.
                    </p>
                    <p>
                        Your continued use of the Platform after changes are posted constitutes your acceptance of the revised terms. If you do not agree to the new terms, you must stop using the Platform.
                    </p>
                </div>

                <div class="terms-section" id="contact">
                    <h2>14. Contact Information</h2>
                    <p>
                        If you have questions about these Terms of Service, please contact us through:
                    </p>
                    <ul>
                        <li>Facebook: <a href="https://facebook.com" target="_blank">facebook.com/kwikpaper</a></li>
                        <li>Twitter: <a href="https://twitter.com" target="_blank">twitter.com/kwikpaper</a></li>
                        <li>Instagram: <a href="https://instagram.com" target="_blank">instagram.com/kwikpaper</a></li>
                    </ul>
                </div>

                <div class="highlight-box" style="margin-top: 3rem;">
                    <strong>By using KwikPaper, you acknowledge that you have read, understood, and agree to be bound by these Terms of Service.</strong>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="how-it-works.php">How It Works</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="browse.php">Help Center</a></li>
                        <li><a href="index.php" onclick="alert('Contact form coming soon! For now, please reach out via social media.'); return false;">Contact Us</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a></li>
                        <li><a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a></li>
                        <li><a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <button class="scroll-to-top" id="scrollToTop" onclick="scrollToTop()">↑</button>

    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
    <script>
        // Smooth scroll to section when clicking TOC links
        document.querySelectorAll('.toc a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    const offset = 100;
                    const elementPosition = targetElement.getBoundingClientRect().top;
                    const offsetPosition = elementPosition + window.pageYOffset - offset;
                    
                    window.scrollTo({
                        top: offsetPosition,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Scroll to top button visibility
        const scrollToTopBtn = document.getElementById('scrollToTop');
        
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                scrollToTopBtn.classList.add('visible');
            } else {
                scrollToTopBtn.classList.remove('visible');
            }
        });

        function scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }

        // Add reading progress indicator
        window.addEventListener('scroll', function() {
            const winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            const height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            const scrolled = (winScroll / height) * 100;
            
            // Optional: Add progress bar if element exists
            const progressBar = document.getElementById('progressBar');
            if (progressBar) {
                progressBar.style.width = scrolled + '%';
            }
        });
    </script>
</body>
</html>
