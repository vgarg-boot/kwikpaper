﻿<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        .page-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 4rem 0;
            color: white;
            text-align: center;
        }
        
        .page-header h1 {
            font-size: 3rem;
            margin: 0 0 1rem 0;
            font-weight: 700;
        }
        
        .page-header p {
            font-size: 1.3rem;
            opacity: 0.95;
            margin: 0;
        }

        .faq-section {
            padding: 4rem 0;
            background: #f8f9fa;
        }

        .faq-categories {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-bottom: 3rem;
            flex-wrap: wrap;
        }

        .category-btn {
            padding: 1rem 2rem;
            background: white;
            border: 2px solid #667eea;
            color: #667eea;
            font-size: 1rem;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .category-btn:hover {
            background: #667eea15;
        }

        .category-btn.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }

        .faq-container {
            max-width: 900px;
            margin: 0 auto;
        }

        .faq-category {
            display: none;
        }

        .faq-category.active {
            display: block;
        }

        .faq-item {
            background: white;
            margin-bottom: 1rem;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s;
        }

        .faq-item:hover {
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .faq-question {
            padding: 1.5rem;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 600;
            font-size: 1.1rem;
            color: #2c3e50;
            transition: all 0.3s;
        }

        .faq-question:hover {
            color: #667eea;
        }

        .faq-icon {
            transition: transform 0.3s;
            color: #667eea;
            font-size: 0.9rem;
        }

        .faq-item.active .faq-icon {
            transform: rotate(180deg);
        }

        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease;
        }

        .faq-item.active .faq-answer {
            max-height: 1000px;
        }

        .faq-answer-content {
            padding: 0 1.5rem 1.5rem 1.5rem;
            color: #666;
            line-height: 1.7;
        }

        .faq-answer-content ul {
            margin-top: 1rem;
            padding-left: 1.5rem;
        }

        .faq-answer-content li {
            margin-bottom: 0.5rem;
            color: #555;
        }

        .cta-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 4rem 0;
            text-align: center;
        }

        .cta-section h2 {
            font-size: 2.5rem;
            margin: 0 0 1rem 0;
            color: white;
        }

        .cta-section p {
            font-size: 1.2rem;
            opacity: 0.95;
            margin-bottom: 2rem;
        }

        .cta-section .btn-primary {
            background: white;
            color: #667eea;
            padding: 1rem 2rem;
            font-size: 1rem;
            text-decoration: none;
            border-radius: 10px;
            display: inline-block;
            font-weight: 600;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            margin: 0 0.5rem;
        }

        .cta-section .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0,0,0,0.3);
        }
    </style>

</head>
<body>
    <nav>
        <div class="container nav-container">
            <div class="logo">
                <a href="index.php">KwikPaper</a>
            </div>
            <div class="nav-links">
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="upload.php">Upload</a>
                    <a href="my-notes.php">My Notes</a>
                    <a href="profile.php">Profile</a>
                    <a href="api/auth/logout.php" class="btn-primary">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                    <a href="register.php" class="btn-primary">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="page-header">
        <div class="container">
            <h1>Frequently Asked Questions</h1>
            <p>Find answers to common questions about KwikPaper</p>
        </div>
    </div>

    <section class="faq-section">
        <div class="container">
            <div class="faq-categories">
                <button class="category-btn active" onclick="showCategory('general')">General</button>
                <button class="category-btn" onclick="showCategory('buying')">Buying Notes</button>
                <button class="category-btn" onclick="showCategory('selling')">Selling Notes</button>
                <button class="category-btn" onclick="showCategory('payment')">Payment & Security</button>
            </div>

            <div class="faq-container">
                <!-- General Questions -->
                <div id="general-category" class="faq-category active">
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>What is KwikPaper?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                KwikPaper is a student-driven marketplace where you can buy and sell study notes. We connect students who create quality study materials with those who need them, making learning resources more accessible for everyone.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Is KwikPaper free to use?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Yes! Creating an account and browsing notes is completely free. Many notes on the platform are also free to download. For paid notes, you only pay the price set by the sellerâ€”there are no hidden fees or subscription costs.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Who can use KwikPaper?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                KwikPaper is designed for students, by students. Whether you're in high school, college, or university, you can use our platform to find study materials or share your own notes with others.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>How do I create an account?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Click the "Sign Up" button in the top navigation, fill in your email, create a password, and you're ready to go! The whole process takes less than a minute.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Can I access notes from any device?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Absolutely! Once you purchase or add notes to your library, you can access them from any device by logging into your account. Download the PDFs to study offline whenever you need.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Buying Questions -->
                <div id="buying-category" class="faq-category">
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>How do I find notes for my course?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Use the search bar to enter your course name, code, or topic. You can also use filters to narrow down results by subject, university, price, and more. Our smart search makes it easy to find exactly what you need.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Can I preview notes before purchasing?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Yes! You can preview the first 3 pages of any note for free. This lets you check the quality, format, and content before making a purchase decision.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>What if I'm not satisfied with the notes I purchased?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                While we encourage previewing notes before purchase, we understand concerns about quality. Please contact our support team if you believe the notes don't match their description or have quality issues. We review each case individually.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Can I download notes multiple times?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Yes! Once you purchase or add notes to your library, you have unlimited downloads. Access them anytime from your "My Notes" section.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Are there free notes available?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Yes! Many sellers offer notes for free to build their reputation or simply to help fellow students. Use the price filter to find free notes, or sort by "Free" in the browse section.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>How do I know if notes are good quality?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Check the following indicators:
                                <ul>
                                    <li>Preview the first few pages</li>
                                    <li>Read reviews from other buyers</li>
                                    <li>Check the seller's rating and reputation</li>
                                    <li>Look at the number of purchases (popular notes are usually quality)</li>
                                    <li>Read the detailed description</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Selling Questions -->
                <div id="selling-category" class="faq-category">
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>How do I start selling notes?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Simply create an account (free), click "Upload" in the navigation, and fill in your note details. Upload your PDF, set a price (or offer it for free), and publish. Your notes will be live immediately!
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>What format should my notes be in?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Notes must be uploaded as PDF files. The maximum file size is 10MB. Make sure your notes are clear, well-organized, and easy to read.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>How much should I charge for my notes?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                You set your own price! Consider factors like:
                                <ul>
                                    <li>Quality and depth of content</li>
                                    <li>Number of pages</li>
                                    <li>Course difficulty and demand</li>
                                    <li>Prices of similar notes on the platform</li>
                                </ul>
                                Many sellers start with free notes to build reviews, then create paid premium versions.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>When do I get paid?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Earnings are tracked in your dashboard. You can view your total sales and earnings in the "My Notes" section. Payment processing details will be available in your account settings.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Can I edit or delete my notes after uploading?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Currently, uploaded notes cannot be directly edited through the platform. If you need to make changes, please contact support. You can manage your notes visibility from your dashboard.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Is it legal to sell my notes?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                You can sell notes that you've personally created. Do not upload copyrighted material, textbook solutions, or exam questions. Only share original content that you have the right to distribute. Check your university's policy on sharing course materials.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Payment & Security Questions -->
                <div id="payment-category" class="faq-category">
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>What payment methods do you accept?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                We accept major credit cards and debit cards. All payments are processed securely through industry-standard encryption.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Is my payment information secure?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Absolutely. We use industry-standard SSL encryption to protect your payment information. Your credit card details are never stored on our servers and are processed through secure payment gateways.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Are there any hidden fees?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                No hidden fees! The price you see is the price you pay. There are no subscription fees, monthly charges, or surprise costs. Sellers set their prices, and that's exactly what buyers pay.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>How is my personal data protected?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                We take privacy seriously. Your personal information is encrypted and stored securely. We never share your data with third parties without your consent. Read our Privacy Policy for complete details.
                            </div>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFaq(this)">
                            <span>Can I get a refund?</span>
                            <span class="faq-icon">â–¼</span>
                        </div>
                        <div class="faq-answer">
                            <div class="faq-answer-content">
                                Due to the digital nature of our products, refunds are handled on a case-by-case basis. If you believe the notes were misrepresented or have quality issues, contact our support team with details and we'll review your request.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="cta-section">
        <div class="container">
            <h2>Still Have Questions?</h2>
            <p>We're here to help! Reach out through our social media channels.</p>
            <div style="display: flex; justify-content: center; gap: 1rem;">
                <a href="https://facebook.com" target="_blank" class="btn-primary">Facebook</a>
                <a href="https://twitter.com" target="_blank" class="btn-primary">Twitter</a>
                <a href="https://instagram.com" target="_blank" class="btn-primary">Instagram</a>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="how-it-works.php">How It Works</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="browse.php">Help Center</a></li>
                        <li><a href="index.php" onclick="alert('Contact form coming soon! For now, please reach out via social media.'); return false;">Contact Us</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a></li>
                        <li><a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a></li>
                        <li><a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
    <script>
        function toggleFaq(element) {
            const faqItem = element.parentElement;
            const isActive = faqItem.classList.contains('active');
            
            // Close all FAQ items
            document.querySelectorAll('.faq-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Open clicked item if it wasn't already open
            if (!isActive) {
                faqItem.classList.add('active');
            }
        }

        function showCategory(category) {
            // Hide all categories
            document.querySelectorAll('.faq-category').forEach(cat => {
                cat.classList.remove('active');
            });
            
            // Remove active class from all buttons
            document.querySelectorAll('.category-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            
            // Show selected category
            document.getElementById(category + '-category').classList.add('active');
            
            // Add active class to clicked button
            event.target.classList.add('active');
            
            // Close all open FAQs when switching categories
            document.querySelectorAll('.faq-item').forEach(item => {
                item.classList.remove('active');
            });
        }
    </script>
</body>
</html>
