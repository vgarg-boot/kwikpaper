﻿<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How It Works - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        .page-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 4rem 0;
            color: white;
            text-align: center;
        }
        
        .page-header h1 {
            font-size: 3rem;
            margin: 0 0 1rem 0;
            font-weight: 700;
        }
        
        .page-header p {
            font-size: 1.3rem;
            opacity: 0.95;
            margin: 0;
        }
        
        .content-section {
            padding: 4rem 0;
        }

        .tabs {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-bottom: 3rem;
        }

        .tab-btn {
            padding: 1rem 2.5rem;
            background: white;
            border: 2px solid #667eea;
            color: #667eea;
            font-size: 1.1rem;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s;
        }

        .tab-btn:hover {
            background: #667eea15;
        }

        .tab-btn.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
        }

        .steps-container {
            max-width: 900px;
            margin: 0 auto;
        }

        .step {
            display: flex;
            gap: 2rem;
            margin-bottom: 3rem;
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            transition: all 0.3s;
        }

        .step:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0,0,0,0.15);
        }

        .step-number {
            flex-shrink: 0;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            font-weight: 700;
        }

        .step-content h3 {
            font-size: 1.8rem;
            color: #2c3e50;
            margin: 0 0 1rem 0;
        }

        .step-content p {
            color: #666;
            line-height: 1.7;
            margin-bottom: 1rem;
        }

        .step-content ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .step-content ul li {
            padding: 0.5rem 0;
            color: #555;
            position: relative;
            padding-left: 1.5rem;
        }

        .step-content ul li:before {
            content: "✓";
            position: absolute;
            left: 0;
            color: #667eea;
            font-weight: bold;
        }

        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 2rem;
            margin-top: 2rem;
        }

        .feature-box {
            background: white;
            padding: 2rem;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            text-align: center;
            transition: all 0.3s;
        }

        .feature-box:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.12);
        }

        .feature-box .icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            color: #667eea;
        }

        .feature-box .icon i {
            display: inline-block;
        }

        .feature-box h4 {
            font-size: 1.3rem;
            color: #2c3e50;
            margin: 1rem 0;
        }

        .feature-box p {
            color: #666;
            line-height: 1.6;
            margin: 0;
        }

        .cta-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 4rem 0;
            text-align: center;
        }

        .cta-section h2 {
            font-size: 2.5rem;
            margin: 0 0 1rem 0;
            color: white;
        }

        .cta-section p {
            font-size: 1.2rem;
            opacity: 0.95;
            margin-bottom: 2rem;
        }

        .cta-section .btn-primary {
            background: white;
            color: #667eea;
            padding: 1rem 2.5rem;
            font-size: 1.1rem;
            text-decoration: none;
            border-radius: 10px;
            display: inline-block;
            font-weight: 600;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            margin: 0 0.5rem;
        }

        .cta-section .btn-primary:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 25px rgba(0,0,0,0.3);
        }

        .cta-section .btn-secondary {
            background: transparent;
            color: white;
            border: 2px solid white;
            padding: 1rem 2.5rem;
            font-size: 1.1rem;
            text-decoration: none;
            border-radius: 10px;
            display: inline-block;
            font-weight: 600;
            transition: all 0.3s;
            margin: 0 0.5rem;
        }

        .cta-section .btn-secondary:hover {
            background: white;
            color: #667eea;
        }
    </style>
</head>
<body>
    <nav>
        <div class="container nav-container">
            <div class="logo">
                <a href="index.php">KwikPaper</a>
            </div>
            <div class="nav-links">
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="upload.php">Upload</a>
                    <a href="my-notes.php">My Notes</a>
                    <a href="profile.php">Profile</a>
                    <a href="api/auth/logout.php" class="btn-primary">Logout</a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                    <a href="register.php" class="btn-primary">Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="page-header">
        <div class="container">
            <h1>How KwikPaper Works</h1>
            <p>Simple, secure, and designed for students</p>
        </div>
    </div>

    <section class="content-section">
        <div class="container">
            <div class="tabs">
                <button class="tab-btn active" onclick="switchTab('buyers')">For Buyers</button>
                <button class="tab-btn" onclick="switchTab('sellers')">For Sellers</button>
            </div>

            <div id="buyers-tab" class="tab-content active">
                <div class="steps-container">
                    <div class="step">
                        <div class="step-number">1</div>
                        <div class="step-content">
                            <h3>Create Your Free Account</h3>
                            <p>Sign up in seconds with just your email address. No credit card required to browse and access free notes.</p>
                            <ul>
                                <li>Quick registration process</li>
                                <li>Secure account protection</li>
                                <li>Access to thousands of free notes immediately</li>
                            </ul>
                        </div>
                    </div>

                    <div class="step">
                        <div class="step-number">2</div>
                        <div class="step-content">
                            <h3>Browse & Search Notes</h3>
                            <p>Use our powerful search and filter tools to find exactly what you need. Filter by subject, course, university, price, and popularity.</p>
                            <ul>
                                <li>Search by keywords, course codes, or topics</li>
                                <li>Filter by price range (including free notes)</li>
                                <li>Sort by popularity, rating, or newest first</li>
                                <li>Preview notes before purchasing</li>
                            </ul>
                        </div>
                    </div>

                    <div class="step">
                        <div class="step-number">3</div>
                        <div class="step-content">
                            <h3>Preview & Review</h3>
                            <p>Check out the first few pages of any note to ensure it matches your needs. Read reviews from other students who've purchased the same notes.</p>
                            <ul>
                                <li>Preview the first 3 pages for free</li>
                                <li>Read detailed reviews and ratings</li>
                                <li>Check seller reputation</li>
                                <li>View note details and description</li>
                            </ul>
                        </div>
                    </div>

                    <div class="step">
                        <div class="step-number">4</div>
                        <div class="step-content">
                            <h3>Purchase or Add Free Notes</h3>
                            <p>For paid notes, complete a secure purchase. Free notes can be instantly added to your library with one click.</p>
                            <ul>
                                <li>Secure payment processing</li>
                                <li>Instant access after purchase</li>
                                <li>No hidden fees or subscriptions</li>
                                <li>Free notes require just a click</li>
                            </ul>
                        </div>
                    </div>

                    <div class="step">
                        <div class="step-number">5</div>
                        <div class="step-content">
                            <h3>Access & Download Anytime</h3>
                            <p>All your notes are saved in your personal library. Download them as many times as you need, whenever you need them.</p>
                            <ul>
                                <li>Unlimited downloads of purchased notes</li>
                                <li>Access from any device</li>
                                <li>Notes saved permanently in your account</li>
                                <li>View online or download PDF files</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div id="sellers-tab" class="tab-content">
                <div class="steps-container">
                    <div class="step">
                        <div class="step-number">1</div>
                        <div class="step-content">
                            <h3>Sign Up & Complete Your Profile</h3>
                            <p>Create your seller account and build trust by completing your profile with your university and areas of expertise.</p>
                            <ul>
                                <li>Free seller account creation</li>
                                <li>Showcase your academic credentials</li>
                                <li>Build your seller reputation</li>
                            </ul>
                        </div>
                    </div>

                    <div class="step">
                        <div class="step-number">2</div>
                        <div class="step-content">
                            <h3>Prepare Your Notes</h3>
                            <p>Organize your study materials into a clean, professional PDF format. Make sure they're clear, comprehensive, and valuable.</p>
                            <ul>
                                <li>Convert notes to PDF format</li>
                                <li>Ensure high-quality, readable content</li>
                                <li>Include examples and explanations</li>
                                <li>Organize topics logically</li>
                            </ul>
                        </div>
                    </div>

                    <div class="step">
                        <div class="step-number">3</div>
                        <div class="step-content">
                            <h3>Upload & Describe Your Notes</h3>
                            <p>Upload your PDF and provide detailed information to help buyers find and understand your notes.</p>
                            <ul>
                                <li>Add title, description, and course details</li>
                                <li>Tag with relevant subjects and topics</li>
                                <li>Upload PDF (max 10MB)</li>
                                <li>Choose between free or paid pricing</li>
                            </ul>
                        </div>
                    </div>

                    <div class="step">
                        <div class="step-number">4</div>
                        <div class="step-content">
                            <h3>Set Your Price</h3>
                            <p>You're in control! Set your own price or offer notes for free to build your reputation. Consider the quality, depth, and demand when pricing.</p>
                            <ul>
                                <li>Set any price you think is fair</li>
                                <li>Offer free notes to gain reviews</li>
                                <li>Premium notes can command higher prices</li>
                                <li>Research similar notes for pricing guidance</li>
                            </ul>
                        </div>
                    </div>

                    <div class="step">
                        <div class="step-number">5</div>
                        <div class="step-content">
                            <h3>Earn & Track Performance</h3>
                            <p>Watch your notes get discovered and make earnings every time someone purchases. Track your sales and reviews in your dashboard.</p>
                            <ul>
                                <li>Real-time sales tracking</li>
                                <li>Monitor views and purchases</li>
                                <li>Receive buyer reviews and ratings</li>
                                <li>Track your total earnings</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="content-section" style="background: #f8f9fa;">
        <div class="container">
            <h2 style="text-align: center; color: #333; margin-bottom: 1rem;">Key Features</h2>
            <p style="text-align: center; color: #666; max-width: 600px; margin: 0 auto 3rem;">Everything you need for a seamless experience</p>
            
            <div class="features-grid">
                <div class="feature-box">
                    <div class="icon"><i class="fas fa-bolt"></i></div>
                    <h4>Instant Access</h4>
                    <p>Download notes immediately after purchase or adding to library</p>
                </div>
                <div class="feature-box">
                    <div class="icon"><i class="fas fa-search"></i></div>
                    <h4>Smart Search</h4>
                    <p>Find exactly what you need with advanced filters and search</p>
                </div>
                <div class="feature-box">
                    <div class="icon"><i class="fas fa-star"></i></div>
                    <h4>Reviews & Ratings</h4>
                    <p>Community-driven quality assurance through honest reviews</p>
                </div>
                <div class="feature-box">
                    <div class="icon"><i class="fas fa-lock"></i></div>
                    <h4>Secure Platform</h4>
                    <p>Your data and payments are protected with industry-standard security</p>
                </div>
            </div>
        </div>
    </section>

    <div class="cta-section">
        <div class="container">
            <h2>Ready to Get Started?</h2>
            <p>Join thousands of students already using KwikPaper</p>
            <?php if (!isset($_SESSION['user_id'])): ?>
                <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                    <a href="register.php" class="btn-primary">Sign Up Free</a>
                    <a href="browse.php" class="btn-secondary">Browse Notes</a>
                </div>
            <?php else: ?>
                <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                    <a href="upload.php" class="btn-primary">Upload Notes</a>
                    <a href="browse.php" class="btn-secondary">Browse Notes</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="how-it-works.php">How It Works</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="browse.php">Help Center</a></li>
                        <li><a href="index.php" onclick="alert('Contact form coming soon! For now, please reach out via social media.'); return false;">Contact Us</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a></li>
                        <li><a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a></li>
                        <li><a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
    <script>
        function switchTab(tab) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            
            // Show selected tab
            document.getElementById(tab + '-tab').classList.add('active');
            event.target.classList.add('active');
        }
    </script>
</body>
</html>