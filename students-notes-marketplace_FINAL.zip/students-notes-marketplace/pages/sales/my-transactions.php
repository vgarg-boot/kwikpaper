<?php
session_start();

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Transactions - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        .transactions-section {
            padding: 2rem 0;
            min-height: 80vh;
        }
        
        .section-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
            border: 2px solid rgba(102, 126, 234, 0.2);
        }
        
        .stat-card .icon {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }
        
        .stat-card .label {
            color: #6c757d;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .stat-card .value {
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .filter-bar {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .filter-bar label {
            font-weight: 600;
            color: #2c3e50;
        }
        
        .filter-bar select {
            padding: 0.7rem 1rem;
            border: 2px solid rgba(102, 126, 234, 0.3);
            border-radius: 10px;
            font-weight: 600;
            color: #2c3e50;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .filter-bar select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .transactions-list {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.06);
        }
        
        .transaction-item {
            display: grid;
            grid-template-columns: 60px 1fr auto;
            gap: 1.5rem;
            align-items: center;
            padding: 1.5rem;
            border: 2px solid rgba(102, 126, 234, 0.1);
            border-radius: 12px;
            margin-bottom: 1rem;
            transition: all 0.3s;
        }
        
        .transaction-item:hover {
            border-color: rgba(102, 126, 234, 0.3);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
            transform: translateX(5px);
        }
        
        .transaction-icon {
            font-size: 2.5rem;
            text-align: center;
        }
        
        .transaction-details {
            flex: 1;
        }
        
        .transaction-details h3 {
            margin: 0 0 0.5rem 0;
            color: #2c3e50;
            font-size: 1.1rem;
        }
        
        .transaction-meta {
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .transaction-meta span {
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }
        
        .transaction-amount {
            text-align: right;
        }
        
        .transaction-amount .amount {
            font-size: 1.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .status-badge {
            display: inline-block;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-top: 0.5rem;
        }
        
        .status-completed {
            background: #d4edda;
            color: #155724;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-failed {
            background: #f8d7da;
            color: #721c24;
        }
        
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
        }
        
        .empty-state .icon {
            font-size: 5rem;
            margin-bottom: 1rem;
        }
        
        .empty-state h3 {
            color: #2c3e50;
            margin-bottom: 1rem;
        }
        
        .empty-state p {
            color: #6c757d;
            margin-bottom: 2rem;
        }
        
        .loading-spinner {
            text-align: center;
            padding: 4rem 2rem;
        }
        
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .btn-view {
            padding: 0.7rem 1.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-view:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>KwikPaper</h1>
            </div>
            <nav>
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <a href="upload.php">Upload</a>
                <a href="dashboard.php">Dashboard</a>
            </nav>
            <div class="nav-search">
                <input type="text" placeholder="Search notes..." id="navSearch">
            </div>
            <nav class="nav-right">
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <span class="admin-badge">ADMIN</span>
                <?php endif; ?>
                <span class="user-welcome">👋 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <a href="admin.php" class="btn-admin" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0.6rem 1.2rem; border-radius: 8px; text-decoration: none; font-weight: 600;">Admin</a>
                <?php endif; ?>
                <a href="dashboard.php" class="btn-dashboard">Dashboard</a>
                <a href="api/auth/logout.php" class="btn-logout">Logout</a>
            </nav>
        </div>
    </header>

    <section class="transactions-section">
        <div class="container">
            <h1 class="section-header">💳 My Transaction History</h1>
            
            <div id="statsContainer" class="stats-grid">
                <div class="stat-card">
                    <div class="icon">💰</div>
                    <div class="label">Total Spent</div>
                    <div class="value" id="totalSpent">$0.00</div>
                </div>
                <div class="stat-card">
                    <div class="icon">✅</div>
                    <div class="label">Completed Purchases</div>
                    <div class="value" id="completedCount">0</div>
                </div>
                <div class="stat-card">
                    <div class="icon">📊</div>
                    <div class="label">Total Transactions</div>
                    <div class="value" id="totalCount">0</div>
                </div>
            </div>
            
            <div class="filter-bar">
                <label for="statusFilter">Filter by Status:</label>
                <select id="statusFilter" onchange="loadTransactions()">
                    <option value="all">All Transactions</option>
                    <option value="completed">Completed</option>
                    <option value="pending">Pending</option>
                    <option value="failed">Failed</option>
                </select>
            </div>
            
            <div class="transactions-list">
                <div id="transactionsList" class="loading-spinner">
                    <div class="spinner"></div>
                    <p>Loading transactions...</p>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="how-it-works.php">How It Works</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="browse.php">Help Center</a></li>
                        <li><a href="index.php">Contact Us</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="https://facebook.com" target="_blank">Facebook</a></li>
                        <li><a href="https://twitter.com" target="_blank">Twitter</a></li>
                        <li><a href="https://instagram.com" target="_blank">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="nav-search.js"></script>
    <script>
        async function loadTransactions() {
            const container = document.getElementById('transactionsList');
            const status = document.getElementById('statusFilter').value;
            
            try {
                const response = await fetch(`api/payments/my-transactions.php?status=${status}`);
                const result = await response.json();
                
                if (result.success) {
                    // Update stats
                    document.getElementById('totalSpent').textContent = '$' + result.total_spent;
                    document.getElementById('completedCount').textContent = result.completed_count;
                    document.getElementById('totalCount').textContent = result.count;
                    
                    // Display transactions
                    if (result.data.length === 0) {
                        container.innerHTML = `
                            <div class="empty-state">
                                <div class="icon">📭</div>
                                <h3>No Transactions Found</h3>
                                <p>You haven't made any purchases yet.</p>
                                <a href="browse.php" class="btn-view">Browse Notes</a>
                            </div>
                        `;
                    } else {
                        container.innerHTML = result.data.map(transaction => `
                            <div class="transaction-item">
                                <div class="transaction-icon">📄</div>
                                <div class="transaction-details">
                                    <h3>${transaction.note_title}</h3>
                                    <div class="transaction-meta">
                                        <span>🆔 ${transaction.transaction_id}</span>
                                        <span>📅 ${new Date(transaction.transaction_date).toLocaleDateString()}</span>
                                        <span>👤 ${transaction.seller_name}</span>
                                        <span>💳 ${transaction.payment_method.toUpperCase()}</span>
                                    </div>
                                    <span class="status-badge status-${transaction.status}">
                                        ${transaction.status === 'completed' ? '✅ Completed' : 
                                          transaction.status === 'pending' ? '⏳ Pending' : 
                                          '❌ Failed'}
                                    </span>
                                </div>
                                <div class="transaction-amount">
                                    <div class="amount">$${parseFloat(transaction.amount).toFixed(2)}</div>
                                    ${transaction.status === 'completed' ? 
                                        `<a href="view-note.php?id=${transaction.note_id}" class="btn-view">View Note</a>` : 
                                        ''}
                                </div>
                            </div>
                        `).join('');
                    }
                } else {
                    container.innerHTML = `
                        <div class="empty-state">
                            <div class="icon">⚠️</div>
                            <h3>Error Loading Transactions</h3>
                            <p>${result.message}</p>
                        </div>
                    `;
                }
            } catch (error) {
                console.error('Error:', error);
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="icon">⚠️</div>
                        <h3>Error Loading Transactions</h3>
                        <p>Unable to load transaction history. Please try again later.</p>
                    </div>
                `;
            }
        }
        
        // Load transactions on page load
        loadTransactions();
    </script>
</body>
</html>
