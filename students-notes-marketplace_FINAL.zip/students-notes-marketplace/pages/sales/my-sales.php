<?php
session_start();

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Sales - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        .sales-section {
            padding: 2rem 0;
            min-height: 80vh;
        }
        
        .section-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: 2rem;
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
            border: 2px solid rgba(102, 126, 234, 0.2);
        }
        
        .stat-card .icon {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }
        
        .stat-card .label {
            color: #6c757d;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        
        .stat-card .value {
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .stat-card .subtext {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 0.5rem;
        }
        
        .earnings-highlight {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .filter-bar {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .filter-bar label {
            font-weight: 600;
            color: #2c3e50;
        }
        
        .filter-bar select {
            padding: 0.7rem 1rem;
            border: 2px solid rgba(102, 126, 234, 0.3);
            border-radius: 10px;
            font-weight: 600;
            color: #2c3e50;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .filter-bar select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .sales-list {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.06);
        }
        
        .sale-item {
            display: grid;
            grid-template-columns: 60px 1fr auto auto;
            gap: 1.5rem;
            align-items: center;
            padding: 1.5rem;
            border: 2px solid rgba(102, 126, 234, 0.1);
            border-radius: 12px;
            margin-bottom: 1rem;
            transition: all 0.3s;
        }
        
        .sale-item:hover {
            border-color: rgba(102, 126, 234, 0.3);
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
            transform: translateX(5px);
        }
        
        .sale-icon {
            font-size: 2.5rem;
            text-align: center;
        }
        
        .sale-details {
            flex: 1;
        }
        
        .sale-details h3 {
            margin: 0 0 0.5rem 0;
            color: #2c3e50;
            font-size: 1.1rem;
        }
        
        .sale-meta {
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
            font-size: 0.9rem;
            color: #6c757d;
        }
        
        .sale-meta span {
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }
        
        .sale-amounts {
            text-align: right;
        }
        
        .sale-revenue {
            font-size: 1.3rem;
            font-weight: 700;
            color: #6c757d;
            text-decoration: line-through;
        }
        
        .sale-earnings {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .sale-fee {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 0.3rem;
        }
        
        .status-badge {
            display: inline-block;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .status-completed {
            background: #d4edda;
            color: #155724;
        }
        
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        
        .status-failed {
            background: #f8d7da;
            color: #721c24;
        }
        
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
        }
        
        .empty-state .icon {
            font-size: 5rem;
            margin-bottom: 1rem;
        }
        
        .empty-state h3 {
            color: #2c3e50;
            margin-bottom: 1rem;
        }
        
        .empty-state p {
            color: #6c757d;
            margin-bottom: 2rem;
        }
        
        .loading-spinner {
            text-align: center;
            padding: 4rem 2rem;
        }
        
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #667eea;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .info-box {
            background: linear-gradient(135deg, #e7f3ff 0%, #ffffff 100%);
            border: 2px solid rgba(13, 110, 253, 0.2);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .info-box h3 {
            color: #0d6efd;
            margin: 0 0 0.5rem 0;
            font-size: 1.1rem;
        }
        
        .info-box p {
            color: #084298;
            margin: 0;
            font-size: 0.95rem;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>KwikPaper</h1>
            </div>
            <nav>
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <a href="upload.php">Upload</a>
                <a href="dashboard.php">Dashboard</a>
            </nav>
            <div class="nav-search">
                <input type="text" placeholder="Search notes..." id="navSearch">
            </div>
            <nav class="nav-right">
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <span class="admin-badge">ADMIN</span>
                <?php endif; ?>
                <span class="user-welcome">👋 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <a href="admin.php" class="btn-admin" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0.6rem 1.2rem; border-radius: 8px; text-decoration: none; font-weight: 600;">Admin</a>
                <?php endif; ?>
                <a href="dashboard.php" class="btn-dashboard">Dashboard</a>
                <a href="api/auth/logout.php" class="btn-logout">Logout</a>
            </nav>
        </div>
    </header>

    <section class="sales-section">
        <div class="container">
            <h1 class="section-header">💰 My Sales & Earnings</h1>
            
            <div class="info-box">
                <h3>💡 About Platform Fees</h3>
                <p>KwikPaper charges a 10% platform fee on each sale to maintain and improve the marketplace. Your earnings reflect the amount after this fee is deducted.</p>
            </div>
            
            <div id="statsContainer" class="stats-grid">
                <div class="stat-card">
                    <div class="icon">💵</div>
                    <div class="label">Total Revenue</div>
                    <div class="value" id="totalRevenue">$0.00</div>
                    <div class="subtext">Before platform fees</div>
                </div>
                <div class="stat-card">
                    <div class="icon">💚</div>
                    <div class="label">Your Earnings</div>
                    <div class="value earnings-highlight" id="totalEarnings">$0.00</div>
                    <div class="subtext">After 10% platform fee</div>
                </div>
                <div class="stat-card">
                    <div class="icon">📊</div>
                    <div class="label">Platform Fees</div>
                    <div class="value" id="totalFees">$0.00</div>
                    <div class="subtext">10% of total revenue</div>
                </div>
                <div class="stat-card">
                    <div class="icon">✅</div>
                    <div class="label">Completed Sales</div>
                    <div class="value" id="completedCount">0</div>
                    <div class="subtext" id="totalCount">of 0 total</div>
                </div>
            </div>
            
            <div class="filter-bar">
                <label for="statusFilter">Filter by Status:</label>
                <select id="statusFilter" onchange="loadSales()">
                    <option value="all">All Transactions</option>
                    <option value="completed">Completed</option>
                    <option value="pending">Pending</option>
                    <option value="failed">Failed</option>
                </select>
            </div>
            
            <div class="sales-list">
                <div id="salesList" class="loading-spinner">
                    <div class="spinner"></div>
                    <p>Loading sales data...</p>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="how-it-works.php">How It Works</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="browse.php">Help Center</a></li>
                        <li><a href="index.php">Contact Us</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="https://facebook.com" target="_blank">Facebook</a></li>
                        <li><a href="https://twitter.com" target="_blank">Twitter</a></li>
                        <li><a href="https://instagram.com" target="_blank">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="nav-search.js"></script>
    <script>
        async function loadSales() {
            const container = document.getElementById('salesList');
            const status = document.getElementById('statusFilter').value;
            
            try {
                const response = await fetch(`api/payments/my-sales.php?status=${status}`);
                const result = await response.json();
                
                if (result.success) {
                    // Update stats
                    document.getElementById('totalRevenue').textContent = '$' + result.total_revenue;
                    document.getElementById('totalEarnings').textContent = '$' + result.total_earnings;
                    document.getElementById('totalFees').textContent = '$' + result.total_platform_fees;
                    document.getElementById('completedCount').textContent = result.completed_count;
                    document.getElementById('totalCount').textContent = 'of ' + result.count + ' total';
                    
                    // Display sales
                    if (result.data.length === 0) {
                        container.innerHTML = `
                            <div class="empty-state">
                                <div class="icon">📊</div>
                                <h3>No Sales Yet</h3>
                                <p>You haven't made any sales yet. Upload quality notes to start earning!</p>
                                <a href="upload.php" class="btn-view">Upload Notes</a>
                            </div>
                        `;
                    } else {
                        container.innerHTML = result.data.map(sale => `
                            <div class="sale-item">
                                <div class="sale-icon">💸</div>
                                <div class="sale-details">
                                    <h3>${sale.note_title}</h3>
                                    <div class="sale-meta">
                                        <span>🆔 ${sale.transaction_id}</span>
                                        <span>📅 ${new Date(sale.transaction_date).toLocaleDateString()}</span>
                                        <span>👤 ${sale.buyer_name}</span>
                                        <span>💳 ${sale.payment_method.toUpperCase()}</span>
                                    </div>
                                    <span class="status-badge status-${sale.status}">
                                        ${sale.status === 'completed' ? '✅ Completed' : 
                                          sale.status === 'pending' ? '⏳ Pending' : 
                                          '❌ Failed'}
                                    </span>
                                </div>
                                <div class="sale-amounts">
                                    <div class="sale-revenue">$${parseFloat(sale.amount).toFixed(2)}</div>
                                    ${sale.status === 'completed' ? `
                                        <div class="sale-earnings">$${parseFloat(sale.seller_earnings).toFixed(2)}</div>
                                        <div class="sale-fee">-$${parseFloat(sale.platform_fee).toFixed(2)} fee (10%)</div>
                                    ` : '<div class="sale-earnings">--</div>'}
                                </div>
                            </div>
                        `).join('');
                    }
                } else {
                    container.innerHTML = `
                        <div class="empty-state">
                            <div class="icon">⚠️</div>
                            <h3>Error Loading Sales</h3>
                            <p>${result.message}</p>
                        </div>
                    `;
                }
            } catch (error) {
                console.error('Error:', error);
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="icon">⚠️</div>
                        <h3>Error Loading Sales</h3>
                        <p>Unable to load sales data. Please try again later.</p>
                    </div>
                `;
            }
        }
        
        // Load sales on page load
        loadSales();
    </script>
</body>
</html>
