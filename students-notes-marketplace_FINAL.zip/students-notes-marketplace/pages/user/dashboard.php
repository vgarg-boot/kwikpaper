<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        .dashboard-section {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            padding: 2rem 0 4rem;
            min-height: calc(100vh - 300px);
        }
        
        .dashboard-header {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .welcome-section h2 {
            font-size: 2rem;
            color: #2c3e50;
            margin: 0 0 0.5rem 0;
        }
        
        .welcome-section p {
            color: #6c757d;
            margin: 0;
            font-size: 1rem;
        }
        
        .profile-quick {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .profile-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .profile-info h4 {
            margin: 0 0 0.3rem 0;
            color: #2c3e50;
            font-size: 1.1rem;
        }
        
        .profile-info p {
            margin: 0;
            color: #6c757d;
            font-size: 0.85rem;
        }
        
        .dashboard-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
            display: flex;
            align-items: center;
            gap: 1.5rem;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 4px;
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .stat-icon {
            width: 70px;
            height: 70px;
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            flex-shrink: 0;
        }
        
        .stat-card:nth-child(1) .stat-icon {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
        }
        
        .stat-card:nth-child(2) .stat-icon {
            background: linear-gradient(135deg, #f093fb15 0%, #f5576c15 100%);
        }
        
        .stat-card:nth-child(3) .stat-icon {
            background: linear-gradient(135deg, #4facfe15 0%, #00f2fe15 100%);
        }
        
        .stat-card:nth-child(4) .stat-icon {
            background: linear-gradient(135deg, #43e97b15 0%, #38f9d715 100%);
        }
        
        .stat-info {
            flex: 1;
        }
        
        .stat-info h3 {
            font-size: 2rem;
            margin: 0 0 0.3rem 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .stat-info p {
            margin: 0;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .stat-trend {
            display: flex;
            align-items: center;
            gap: 0.3rem;
            margin-top: 0.5rem;
            font-size: 0.85rem;
            color: #28a745;
        }
        
        .stat-trend.down {
            color: #dc3545;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e9ecef;
        }
        
        .card-header h3 {
            margin: 0;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .card-header a {
            color: #667eea;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .card-header a:hover {
            color: #5568d3;
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
        }
        
        .action-btn {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.2);
        }
        
        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3);
        }
        
        .action-btn:nth-child(2) {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            box-shadow: 0 4px 15px rgba(240, 147, 251, 0.2);
        }
        
        .action-btn:nth-child(2):hover {
            box-shadow: 0 6px 20px rgba(240, 147, 251, 0.3);
        }
        
        .action-btn:nth-child(3) {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            box-shadow: 0 4px 15px rgba(79, 172, 254, 0.2);
        }
        
        .action-btn:nth-child(3):hover {
            box-shadow: 0 6px 20px rgba(79, 172, 254, 0.3);
        }
        
        .action-btn:nth-child(4) {
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            box-shadow: 0 4px 15px rgba(250, 112, 154, 0.2);
        }
        
        .action-btn:nth-child(4):hover {
            box-shadow: 0 6px 20px rgba(250, 112, 154, 0.3);
        }
        
        .action-btn:nth-child(5) {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            box-shadow: 0 4px 15px rgba(67, 233, 123, 0.2);
        }
        
        .action-btn:nth-child(5):hover {
            box-shadow: 0 6px 20px rgba(67, 233, 123, 0.3);
        }
        
        .action-btn:nth-child(6) {
            background: linear-gradient(135deg, #fa8bff 0%, #2bd2ff 100%);
            box-shadow: 0 4px 15px rgba(250, 139, 255, 0.2);
        }
        
        .action-btn:nth-child(6):hover {
            box-shadow: 0 6px 20px rgba(250, 139, 255, 0.3);
        }
        
        .action-icon {
            font-size: 2rem;
        }
        
        .action-text h4 {
            margin: 0 0 0.2rem 0;
            font-size: 1rem;
        }
        
        .action-text p {
            margin: 0;
            font-size: 0.85rem;
            opacity: 0.9;
        }
        
        .activity-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .activity-item {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 0.75rem;
            background: #f8f9fa;
            transition: all 0.3s;
        }
        
        .activity-item:hover {
            background: #e9ecef;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            flex-shrink: 0;
        }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-content p {
            margin: 0 0 0.3rem 0;
            color: #2c3e50;
            font-size: 0.9rem;
        }
        
        .activity-time {
            color: #6c757d;
            font-size: 0.8rem;
        }
        
        .recent-notes {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        
        .note-item {
            display: flex;
            gap: 1rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 10px;
            transition: all 0.3s;
            cursor: pointer;
        }
        
        .note-item:hover {
            background: #e9ecef;
            transform: translateX(5px);
        }
        
        .note-thumb {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            flex-shrink: 0;
        }
        
        .note-details {
            flex: 1;
        }
        
        .note-details h5 {
            margin: 0 0 0.3rem 0;
            color: #2c3e50;
            font-size: 0.95rem;
        }
        
        .note-details p {
            margin: 0;
            color: #6c757d;
            font-size: 0.8rem;
        }
        
        .note-price {
            font-weight: 700;
            color: #667eea;
            font-size: 1.1rem;
            align-self: center;
        }
        
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #6c757d;
        }
        
        .empty-state-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .progress-section {
            margin-top: 1.5rem;
        }
        
        .progress-item {
            margin-bottom: 1rem;
        }
        
        .progress-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
        }
        
        .progress-bar-container {
            height: 8px;
            background: #e9ecef;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .progress-bar {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 10px;
            transition: width 0.3s;
        }
        
        @media (max-width: 968px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .dashboard-stats {
                grid-template-columns: 1fr;
            }
            
            .quick-actions {
                grid-template-columns: 1fr;
            }
            
            .dashboard-header {
                flex-direction: column;
                gap: 1.5rem;
                text-align: center;
            }
            
            .profile-quick {
                flex-direction: column;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>KwikPaper</h1>
            </div>
            <nav>
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <a href="upload.php">Upload</a>
                <a href="my-notes.php">My Notes</a>
            </nav>
            <div class="nav-search">
                <input type="text" placeholder="Search notes..." id="navSearch">
            </div>
            <nav class="nav-right">
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <span class="admin-badge">ADMIN</span>
                <?php endif; ?>
                <span class="user-welcome">👋 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <a href="admin.php" class="btn-admin" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0.6rem 1.2rem; border-radius: 8px; text-decoration: none; font-weight: 600;">Admin</a>
                <?php endif; ?>
                <a href="dashboard.php" class="btn-dashboard">Dashboard</a>
                <a href="api/auth/logout.php" class="btn-logout">Logout</a>
            </nav>
        </div>
    </header>
    
    <section class="dashboard-section">
        <div class="container">
            <!-- Welcome Header -->
            <div class="dashboard-header">
                <div class="welcome-section">
                    <h2>Welcome back, <span id="userName"><?php echo htmlspecialchars($_SESSION['username']); ?></span>! 👋</h2>
                    <p>Here's what's happening with your account today</p>
                </div>
                <div class="profile-quick">
                    <div class="profile-avatar" id="profileAvatar">👤</div>
                    <div class="profile-info">
                        <h4 id="profileName"><?php echo htmlspecialchars($_SESSION['username']); ?></h4>
                        <p>Member since 2026</p>
                    </div>
                </div>
            </div>
            
            <!-- Stats Cards -->
            <div class="dashboard-stats">
                <div class="stat-card">
                    <div class="stat-icon">📤</div>
                    <div class="stat-info">
                        <h3 id="notesUploaded">0</h3>
                        <p>Notes Uploaded</p>
                        <div class="stat-trend">
                            <span>↗</span>
                            <span>+2 this month</span>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">⬇️</div>
                    <div class="stat-info">
                        <h3 id="totalDownloads">0</h3>
                        <p>Total Downloads</p>
                        <div class="stat-trend">
                            <span>↗</span>
                            <span>+5 this week</span>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">💰</div>
                    <div class="stat-info">
                        <h3 id="totalEarnings">$0.00</h3>
                        <p>Total Earnings</p>
                        <div class="stat-trend">
                            <span>↗</span>
                            <span>+$15 this month</span>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">⭐</div>
                    <div class="stat-info">
                        <h3 id="avgRating">5.0</h3>
                        <p>Average Rating</p>
                        <div class="stat-trend">
                            <span>→</span>
                            <span>Excellent</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Grid -->
            <div class="dashboard-grid">
                <!-- Left Column -->
                <div>
                    <!-- Quick Actions -->
                    <div class="dashboard-card" style="margin-bottom: 2rem;">
                        <div class="card-header">
                            <h3>⚡ Quick Actions</h3>
                        </div>
                        <div class="quick-actions">
                            <a href="upload.php" class="action-btn">
                                <div class="action-icon">📤</div>
                                <div class="action-text">
                                    <h4>Upload Notes</h4>
                                    <p>Share your knowledge</p>
                                </div>
                            </a>
                            
                            <a href="my-notes.php" class="action-btn">
                                <div class="action-icon">📋</div>
                                <div class="action-text">
                                    <h4>My Notes</h4>
                                    <p>Manage uploads</p>
                                </div>
                            </a>
                            
                            <a href="browse.php" class="action-btn">
                                <div class="action-icon">🔍</div>
                                <div class="action-text">
                                    <h4>Browse Notes</h4>
                                    <p>Discover content</p>
                                </div>
                            </a>
                            
                            <a href="profile.php" class="action-btn">
                                <div class="action-icon">👤</div>
                                <div class="action-text">
                                    <h4>Edit Profile</h4>
                                    <p>Update info</p>
                                </div>
                            </a>
                            
                            <a href="my-transactions.php" class="action-btn">
                                <div class="action-icon">💳</div>
                                <div class="action-text">
                                    <h4>My Purchases</h4>
                                    <p>Transaction history</p>
                                </div>
                            </a>
                            
                            <a href="my-sales.php" class="action-btn">
                                <div class="action-icon">💰</div>
                                <div class="action-text">
                                    <h4>My Sales</h4>
                                    <p>Earnings & revenue</p>
                                </div>
                            </a>
                        </div>
                    </div>
                    
                    <!-- Recent Activity -->
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h3>📊 Recent Activity</h3>
                            <a href="#">View All</a>
                        </div>
                        <ul class="activity-list" id="activityList">
                            <li class="activity-item">
                                <div class="activity-icon">🎉</div>
                                <div class="activity-content">
                                    <p>Welcome to KwikPaper!</p>
                                    <span class="activity-time">Just now</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                
                <!-- Right Column -->
                <div>
                    <!-- Profile Progress -->
                    <div class="dashboard-card" style="margin-bottom: 2rem;">
                        <div class="card-header">
                            <h3>🎯 Profile Progress</h3>
                        </div>
                        <div class="progress-section">
                            <div class="progress-item">
                                <div class="progress-header">
                                    <span>Profile Completion</span>
                                    <span id="profileProgress">60%</span>
                                </div>
                                <div class="progress-bar-container">
                                    <div class="progress-bar" id="profileProgressBar" style="width: 60%"></div>
                                </div>
                            </div>
                            
                            <div class="progress-item">
                                <div class="progress-header">
                                    <span>Monthly Goal</span>
                                    <span id="goalProgress">30%</span>
                                </div>
                                <div class="progress-bar-container">
                                    <div class="progress-bar" id="goalProgressBar" style="width: 30%"></div>
                                </div>
                            </div>
                        </div>
                        
                        <div style="margin-top: 1.5rem; padding: 1rem; background: #f8f9fa; border-radius: 10px;">
                            <p style="margin: 0; font-size: 0.9rem; color: #6c757d;">
                                💡 <strong>Tip:</strong> Complete your profile to increase visibility and earn more!
                            </p>
                        </div>
                    </div>
                    
                    <!-- Recent Notes -->
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h3>📚 Recent Notes</h3>
                            <a href="my-notes.php">View All</a>
                        </div>
                        <div class="recent-notes" id="recentNotes">
                            <div class="empty-state">
                                <div class="empty-state-icon">📝</div>
                                <p>No notes uploaded yet</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Purchased/Downloaded Notes -->
                    <div class="dashboard-card">
                        <div class="card-header">
                            <h3>📥 Purchased & Downloaded Notes</h3>
                            <span id="purchasedCount" style="color: #667eea; font-weight: 600;">0 notes</span>
                        </div>
                        <div class="recent-notes" id="purchasedNotes">
                            <div class="empty-state">
                                <div class="empty-state-icon">🛒</div>
                                <p>No notes purchased or downloaded yet</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="how-it-works.php">How It Works</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="browse.php">Help Center</a></li>
                        <li><a href="index.php" onclick="alert('Contact form coming soon! For now, please reach out via social media.'); return false;">Contact Us</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a></li>
                        <li><a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a></li>
                        <li><a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
    <script>
        // Load user stats
        async function loadUserStats() {
            const result = await UserAPI.getStats();
            
            if (result.success && result.data) {
                // Update stats
                document.getElementById('notesUploaded').textContent = result.data.notes_uploaded || 0;
                document.getElementById('totalDownloads').textContent = result.data.total_downloads || 0;
                document.getElementById('totalEarnings').textContent = Utils.formatPrice(result.data.earnings || 0);
                document.getElementById('avgRating').textContent = result.data.average_rating || '5.0';
                
                // Update profile avatar (use first letter of username)
                const username = document.getElementById('userName').textContent;
                if (username) {
                    document.getElementById('profileAvatar').textContent = username.charAt(0).toUpperCase();
                }
            }
        }
        
        // Load recent notes
        async function loadRecentNotes() {
            const result = await NotesAPI.getUserNotes();
            const container = document.getElementById('recentNotes');
            
            if (result.success && result.data && result.data.length > 0) {
                const recentThree = result.data.slice(0, 3);
                
                container.innerHTML = recentThree.map(note => {
                    const categoryIcons = {
                        'science': '🔬',
                        'math': '➗',
                        'history': '📜',
                        'language': '🗣️',
                        'cs': '💻',
                        'engineering': '⚙️',
                        'business': '💼',
                        'arts': '🎨'
                    };
                    
                    const icon = categoryIcons[note.category] || '📚';
                    
                    return `
                        <div class="note-item" onclick="location.href='note-detail.php?id=${note.id}'">
                            <div class="note-thumb">${icon}</div>
                            <div class="note-details">
                                <h5>${note.title}</h5>
                                <p>${note.category} • ${note.downloads || 0} downloads</p>
                            </div>
                            <div class="note-price">${Utils.formatPrice(note.price)}</div>
                        </div>
                    `;
                }).join('');
            } else {
                container.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">📝</div>
                        <p>No notes uploaded yet</p>
                    </div>
                `;
            }
        }
        
        // Load purchased/downloaded notes
        async function loadPurchasedNotes() {
            try {
                const response = await fetch('api/notes/purchased.php');
                const result = await response.json();
                
                const container = document.getElementById('purchasedNotes');
                const countElement = document.getElementById('purchasedCount');
                
                if (result.success && result.data && result.data.length > 0) {
                    countElement.textContent = `${result.count} note${result.count !== 1 ? 's' : ''}`;
                    
                    const categoryIcons = {
                        'science': '🔬',
                        'math': '➗',
                        'history': '📜',
                        'language': '🗣️',
                        'cs': '💻',
                        'engineering': '⚙️',
                        'business': '💼',
                        'arts': '🎨'
                    };
                    
                    container.innerHTML = result.data.map(note => {
                        const icon = categoryIcons[note.category] || '📚';
                        const isFree = note.paid_amount == 0 || note.is_free == 1;
                        const priceLabel = isFree ? '🎁 FREE' : Utils.formatPrice(note.paid_amount);
                        
                        return `
                            <div class="note-item" onclick="location.href='note-detail.php?id=${note.id}'">
                                <div class="note-thumb">${icon}</div>
                                <div class="note-details">
                                    <h5>${note.title}</h5>
                                    <p>${note.category} • ${isFree ? 'Downloaded' : 'Purchased'} ${Utils.formatDate(note.purchase_date)}</p>
                                </div>
                                <div class="note-price">
                                    <button class="btn-download-small" onclick="event.stopPropagation(); downloadPurchasedNote(${note.id})" style="background: #43e97b; color: #065c3b; padding: 0.5rem 1rem; border: none; border-radius: 6px; cursor: pointer; font-size: 0.85rem; font-weight: 600;">
                                        📥 Download
                                    </button>
                                </div>
                            </div>
                        `;
                    }).join('');
                } else {
                    countElement.textContent = '0 notes';
                    container.innerHTML = `
                        <div class="empty-state">
                            <div class="empty-state-icon">🛒</div>
                            <p>No notes purchased or downloaded yet</p>
                        </div>
                    `;
                }
            } catch (error) {
                console.error('Error loading purchased notes:', error);
            }
        }
        
        // Load recent activity
        async function loadRecentActivity() {
            const activityList = document.getElementById('activityList');
            
            // Simulate activity (in real app, this would come from API)
            const activities = [
                { icon: '🎉', text: 'Welcome to KwikPaper!', time: 'Just now' },
                { icon: '📤', text: 'Upload your first note to get started', time: '1 hour ago' },
                { icon: '🔍', text: 'Browse available notes in your field', time: '2 hours ago' },
                { icon: '💡', text: 'Complete your profile for better visibility', time: '1 day ago' }
            ];
            
            activityList.innerHTML = activities.map(activity => `
                <li class="activity-item">
                    <div class="activity-icon">${activity.icon}</div>
                    <div class="activity-content">
                        <p>${activity.text}</p>
                        <span class="activity-time">${activity.time}</span>
                    </div>
                </li>
            `).join('');
        }
        
        // Update profile progress
        function updateProfileProgress() {
            // Calculate profile completion (simulate)
            const username = document.getElementById('userName').textContent;
            let progress = 40; // Base progress
            
            if (username) progress += 20;
            // Add more checks for profile fields
            progress = Math.min(100, progress);
            
            document.getElementById('profileProgress').textContent = progress + '%';
            document.getElementById('profileProgressBar').style.width = progress + '%';
            
            // Simulate monthly goal progress
            const goalProgress = 30; // This would come from actual data
            document.getElementById('goalProgress').textContent = goalProgress + '%';
            document.getElementById('goalProgressBar').style.width = goalProgress + '%';
        }
        
        // Download purchased note using iframe
        function downloadPurchasedNote(noteId) {
            const iframe = document.createElement('iframe');
            iframe.style.display = 'none';
            iframe.src = `api/notes/download.php?id=${noteId}`;
            document.body.appendChild(iframe);
            
            setTimeout(() => {
                alert('📥 Download started successfully!');
            }, 500);
        }
        
        // Load all dashboard data
        async function loadDashboard() {
            await Promise.all([
                loadUserStats(),
                loadRecentNotes(),
                loadPurchasedNotes(),
                loadRecentActivity()
            ]);
            updateProfileProgress();
        }
        
        // Initialize dashboard
        loadDashboard();
        
        // Refresh data every 30 seconds
        setInterval(() => {
            loadUserStats();
        }, 30000);
    </script>
</body>
</html>
