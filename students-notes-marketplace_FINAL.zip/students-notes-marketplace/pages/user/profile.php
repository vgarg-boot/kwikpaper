﻿<?php
session_start();

// Get user ID from URL, or use current user's ID if logged in and no ID provided
$profile_user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// If no ID provided but user is logged in, show their own profile
if ($profile_user_id === 0 && isset($_SESSION['user_id'])) {
    $profile_user_id = (int)$_SESSION['user_id'];
}

// If still no valid ID, redirect to browse
if ($profile_user_id === 0) {
    header('Location: browse.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        .edit-profile-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.8rem 1.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            text-decoration: none;
            margin-top: 1rem;
        }
        
        .edit-profile-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .profile-edit-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 9999;
            overflow-y: auto;
            padding: 2rem;
        }
        
        .profile-edit-modal.active {
            display: flex;
            align-items: flex-start;
            justify-content: center;
        }
        
        .modal-content {
            background: white;
            border-radius: 20px;
            padding: 2.5rem;
            max-width: 700px;
            width: 100%;
            box-shadow: 0 10px 50px rgba(0, 0, 0, 0.3);
            margin: 2rem auto;
            animation: slideDown 0.3s ease-out;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e9ecef;
        }
        
        .modal-header h2 {
            margin: 0;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .close-modal {
            background: none;
            border: none;
            font-size: 2rem;
            color: #6c757d;
            cursor: pointer;
            line-height: 1;
            transition: all 0.3s;
        }
        
        .close-modal:hover {
            color: #2c3e50;
            transform: rotate(90deg);
        }
        
        .avatar-upload-section {
            text-align: center;
            margin-bottom: 2rem;
            padding: 2rem;
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            border-radius: 15px;
        }
        
        .avatar-preview {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 4rem;
            color: white;
            margin: 0 auto 1rem;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .avatar-options {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            flex-wrap: wrap;
            margin-top: 1rem;
        }
        
        .avatar-option {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            cursor: pointer;
            border: 3px solid transparent;
            transition: all 0.3s;
        }
        
        .avatar-option:hover,
        .avatar-option.selected {
            border-color: #667eea;
            transform: scale(1.1);
            box-shadow: 0 2px 10px rgba(102, 126, 234, 0.3);
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
        }
        
        .form-group-full {
            grid-column: 1 / -1;
        }
        
        .form-group {
            margin-bottom: 0;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #2c3e50;
            font-weight: 600;
            font-size: 0.95rem;
        }
        
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 0.9rem 1rem;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            font-size: 1rem;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s;
            background: #f8f9fa;
        }
        
        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        .char-counter {
            text-align: right;
            font-size: 0.85rem;
            color: #6c757d;
            margin-top: 0.3rem;
        }
        
        .modal-actions {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .btn-save {
            flex: 1;
            padding: 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .btn-save:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-save:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }
        
        .btn-cancel {
            flex: 1;
            padding: 1rem;
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .btn-cancel:hover {
            background: #667eea;
            color: white;
        }
        
        .success-message,
        .error-message {
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: none;
        }
        
        .success-message {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        
        .success-message.show,
        .error-message.show {
            display: block;
        }
        
        .profile-tabs {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 2rem;
            border-bottom: 2px solid #e9ecef;
            background: white;
            padding: 0 1rem;
            border-radius: 15px 15px 0 0;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
        }
        
        .tab-btn {
            padding: 1rem 2rem;
            background: none;
            border: none;
            border-bottom: 3px solid transparent;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            color: #6c757d;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .tab-btn:hover {
            color: #667eea;
        }
        
        .tab-btn.active {
            color: #667eea;
            border-bottom-color: #667eea;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
            animation: fadeIn 0.3s ease-in;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .profile-notes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }
        
        .reviews-section {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
        }
        
        .reviews-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
            padding-bottom: 2rem;
            border-bottom: 2px solid #e9ecef;
        }
        
        .review-stat-card {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
        }
        
        .review-stat-card h3 {
            font-size: 2.5rem;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .review-stat-card p {
            margin: 0.5rem 0 0 0;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .review-list {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }
        
        .review-card {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 12px;
            border-left: 4px solid #667eea;
            transition: all 0.3s;
        }
        
        .review-card:hover {
            background: #e9ecef;
            transform: translateX(5px);
        }
        
        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }
        
        .review-author {
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }
        
        .reviewer-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.3rem;
            color: white;
        }
        
        .reviewer-info h4 {
            margin: 0;
            color: #2c3e50;
            font-size: 1rem;
        }
        
        .reviewer-info p {
            margin: 0.2rem 0 0 0;
            color: #6c757d;
            font-size: 0.85rem;
        }
        
        .review-rating {
            display: flex;
            align-items: center;
            gap: 0.3rem;
            font-size: 1.2rem;
        }
        
        .review-note-title {
            color: #667eea;
            font-size: 0.9rem;
            margin-bottom: 0.8rem;
            font-weight: 600;
        }
        
        .review-text {
            color: #2c3e50;
            line-height: 1.6;
            margin: 0;
        }
        
        .rating-bars {
            margin: 2rem 0;
        }
        
        .rating-bar-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 0.8rem;
        }
        
        .rating-label {
            min-width: 80px;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .rating-bar-bg {
            flex: 1;
            height: 8px;
            background: #e9ecef;
            border-radius: 10px;
            overflow: hidden;
        }
        
        .rating-bar-fill {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 10px;
            transition: width 0.3s;
        }
        
        .rating-count {
            min-width: 40px;
            text-align: right;
            color: #6c757d;
            font-size: 0.85rem;
        }
        
        .empty-reviews {
            text-align: center;
            padding: 3rem;
            color: #6c757d;
        }
        
        .empty-reviews-icon {
            font-size: 4rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .modal-content {
                padding: 1.5rem;
            }
            
            .profile-edit-modal {
                padding: 1rem;
            }
            
            .profile-tabs {
                flex-wrap: wrap;
                padding: 0.5rem;
            }
            
            .tab-btn {
                padding: 0.8rem 1.2rem;
                font-size: 0.9rem;
            }
            
            .profile-notes-grid {
                grid-template-columns: 1fr;
            }
            
            .reviews-stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>KwikPaper</h1>
            </div>
            <nav>
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <a href="upload.php">Upload</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="dashboard.php">Dashboard</a>
                <?php endif; ?>
            </nav>
            <div class="nav-search">
                <input type="text" placeholder="Search notes..." id="navSearch">
            </div>
            <nav class="nav-right">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <span class="admin-badge">ADMIN</span>
                    <?php endif; ?>
                    <span class="user-welcome">👋 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                    <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <a href="admin.php" class="btn-admin" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0.6rem 1.2rem; border-radius: 8px; text-decoration: none; font-weight: 600;">Admin</a>
                    <?php endif; ?>
                    <a href="dashboard.php" class="btn-dashboard">Dashboard</a>
                    <a href="api/auth/logout.php" class="btn-logout">Logout</a>
                <?php else: ?>
                    <a href="login.php" class="btn-login">Login</a>
                    <a href="register.php" class="btn-register">Register</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>

    <section class="profile-header">
        <div class="container">
            <div class="profile-header-content" id="profileHeader">
                <p>Loading profile...</p>
            </div>
        </div>
    </section>

    <!-- Profile Edit Modal -->
    <div class="profile-edit-modal" id="editProfileModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>✏️ Edit Profile</h2>
                <button class="close-modal" onclick="closeEditModal()">×</button>
            </div>
            
            <div class="success-message" id="successMessage">
                ✅ Profile updated successfully!
            </div>
            <div class="error-message" id="errorMessage">
                ❌ <span id="errorText"></span>
            </div>
            
            <form id="editProfileForm">
                <!-- Avatar Selection -->
                <div class="avatar-upload-section">
                    <div class="avatar-preview" id="avatarPreview">👤</div>
                    <p style="margin: 0 0 0.5rem 0; color: #6c757d; font-size: 0.9rem;">Choose your avatar</p>
                    <div class="avatar-options">
                        <div class="avatar-option" data-avatar="👤" onclick="selectAvatar('👤')">👤</div>
                        <div class="avatar-option" data-avatar="👨‍🎓" onclick="selectAvatar('👨‍🎓')">👨‍🎓</div>
                        <div class="avatar-option" data-avatar="👩‍🎓" onclick="selectAvatar('👩‍🎓')">👩‍🎓</div>
                        <div class="avatar-option" data-avatar="🧑‍💻" onclick="selectAvatar('🧑‍💻')">🧑‍💻</div>
                        <div class="avatar-option" data-avatar="👨‍🏫" onclick="selectAvatar('👨‍🏫')">👨‍🏫</div>
                        <div class="avatar-option" data-avatar="👩‍🏫" onclick="selectAvatar('👩‍🏫')">👩‍🏫</div>
                        <div class="avatar-option" data-avatar="🧑‍🔬" onclick="selectAvatar('🧑‍🔬')">🧑‍🔬</div>
                        <div class="avatar-option" data-avatar="👨‍⚕️" onclick="selectAvatar('👨‍⚕️')">👨‍⚕️</div>
                    </div>
                    <input type="hidden" id="avatarInput" name="avatar" value="👤">
                </div>
                
                <!-- Form Fields -->
                <div class="form-grid">
                    <div class="form-group">
                        <label for="editUsername">Username</label>
                        <input type="text" id="editUsername" name="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="editEmail">Email</label>
                        <input type="email" id="editEmail" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="editUniversity">University/College</label>
                        <input type="text" id="editUniversity" name="university" placeholder="e.g., Harvard University">
                    </div>
                    
                    <div class="form-group">
                        <label for="editYear">Academic Year</label>
                        <select id="editYear" name="year">
                            <option value="">Select Year</option>
                            <option value="Freshman">Freshman</option>
                            <option value="Sophomore">Sophomore</option>
                            <option value="Junior">Junior</option>
                            <option value="Senior">Senior</option>
                            <option value="Graduate">Graduate</option>
                            <option value="PhD">PhD</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="editSubject">Major/Subject</label>
                        <input type="text" id="editSubject" name="subject" placeholder="e.g., Computer Science">
                    </div>
                    
                    <div class="form-group">
                        <label for="editPhone">Phone Number</label>
                        <input type="tel" id="editPhone" name="phone" placeholder="(123) 456-7890">
                    </div>
                    
                    <div class="form-group form-group-full">
                        <label for="editBio">Bio</label>
                        <textarea id="editBio" name="bio" maxlength="500" placeholder="Tell us about yourself..."></textarea>
                        <div class="char-counter">
                            <span id="bioCounter">0</span>/500 characters
                        </div>
                    </div>
                </div>
                
                <!-- Password Change Section (Optional) -->
                <div style="margin-top: 2rem; padding-top: 2rem; border-top: 2px solid #e9ecef;">
                    <h3 style="color: #2c3e50; margin-bottom: 1rem;">🔒 Change Password (Optional)</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="currentPassword">Current Password</label>
                            <input type="password" id="currentPassword" name="current_password" placeholder="Enter current password">
                        </div>
                        
                        <div class="form-group">
                            <label for="newPassword">New Password</label>
                            <input type="password" id="newPassword" name="new_password" placeholder="Enter new password">
                        </div>
                    </div>
                </div>
                
                <!-- Modal Actions -->
                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn-save" id="saveBtn">💾 Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <section class="profile-main">
        <div class="container">
            <!-- Profile Tabs -->
            <div class="profile-tabs">
                <button class="tab-btn active" onclick="switchTab('about')">
                    📋 About
                </button>
                <button class="tab-btn" onclick="switchTab('notes')">
                    📚 Notes (<span id="notesCount">0</span>)
                </button>
                <button class="tab-btn" onclick="switchTab('reviews')">
                    ⭐ Reviews (<span id="reviewsCount">0</span>)
                </button>
            </div>
            
            <div class="profile-grid">
                <div class="profile-main-content">
                    <!-- About Tab -->
                    <div class="tab-content active" id="aboutTab">
                        <div class="profile-section">
                            <div class="profile-about" id="profileAbout">
                                <p>Loading...</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Notes Tab -->
                    <div class="tab-content" id="notesTab">
                        <div class="profile-section">
                            <div class="profile-notes-grid" id="userNotes">
                                <p>Loading notes...</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Reviews Tab -->
                    <div class="tab-content" id="reviewsTab">
                        <div class="reviews-section">
                            <div class="reviews-stats" id="reviewsStats">
                                <div class="review-stat-card">
                                    <h3 id="avgRating">5.0</h3>
                                    <p>Average Rating</p>
                                </div>
                                <div class="review-stat-card">
                                    <h3 id="totalReviews">0</h3>
                                    <p>Total Reviews</p>
                                </div>
                                <div class="review-stat-card">
                                    <h3 id="recommendPercent">100%</h3>
                                    <p>Recommend</p>
                                </div>
                            </div>
                            
                            <!-- Rating Distribution -->
                            <div class="rating-bars" id="ratingBars" style="display: none;">
                                <h3 style="color: #2c3e50; margin-bottom: 1rem;">Rating Distribution</h3>
                                <div class="rating-bar-item">
                                    <span class="rating-label">⭐⭐⭐⭐⭐</span>
                                    <div class="rating-bar-bg">
                                        <div class="rating-bar-fill" id="bar5" style="width: 0%"></div>
                                    </div>
                                    <span class="rating-count" id="count5">0</span>
                                </div>
                                <div class="rating-bar-item">
                                    <span class="rating-label">⭐⭐⭐⭐</span>
                                    <div class="rating-bar-bg">
                                        <div class="rating-bar-fill" id="bar4" style="width: 0%"></div>
                                    </div>
                                    <span class="rating-count" id="count4">0</span>
                                </div>
                                <div class="rating-bar-item">
                                    <span class="rating-label">⭐⭐⭐</span>
                                    <div class="rating-bar-bg">
                                        <div class="rating-bar-fill" id="bar3" style="width: 0%"></div>
                                    </div>
                                    <span class="rating-count" id="count3">0</span>
                                </div>
                                <div class="rating-bar-item">
                                    <span class="rating-label">⭐⭐</span>
                                    <div class="rating-bar-bg">
                                        <div class="rating-bar-fill" id="bar2" style="width: 0%"></div>
                                    </div>
                                    <span class="rating-count" id="count2">0</span>
                                </div>
                                <div class="rating-bar-item">
                                    <span class="rating-label">⭐</span>
                                    <div class="rating-bar-bg">
                                        <div class="rating-bar-fill" id="bar1" style="width: 0%"></div>
                                    </div>
                                    <span class="rating-count" id="count1">0</span>
                                </div>
                            </div>
                            
                            <!-- Reviews List -->
                            <div class="review-list" id="reviewsList">
                                <div class="empty-reviews">
                                    <div class="empty-reviews-icon">⭐</div>
                                    <h3>No Reviews Yet</h3>
                                    <p>This user hasn't received any reviews yet.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="how-it-works.php">How It Works</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="browse.php">Help Center</a></li>
                        <li><a href="index.php" onclick="alert('Contact form coming soon! For now, please reach out via social media.'); return false;">Contact Us</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a></li>
                        <li><a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a></li>
                        <li><a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
    <script>
        const profileUserId = <?php echo $profile_user_id; ?>;
        const currentUserId = <?php echo isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0; ?>;
        const isOwnProfile = profileUserId === currentUserId && currentUserId !== 0;
        let currentProfile = null;
        
        // Tab switching function
        function switchTab(tabName) {
            // Remove active class from all tabs and content
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            event.target.classList.add('active');
            document.getElementById(tabName + 'Tab').classList.add('active');
            
            // Load data if not already loaded
            if (tabName === 'reviews' && !document.getElementById('reviewsList').dataset.loaded) {
                loadReviews();
            }
        }
        
        async function loadProfile() {
            const result = await UserAPI.getProfile(profileUserId);
            
            if (result.success && result.data) {
                const profile = result.data;
                currentProfile = profile;
                document.title = profile.username + ' - KwikPaper';
                
                // Update profile header
                document.getElementById('profileHeader').innerHTML = `
                    <div class="profile-avatar-large">${profile.avatar || '👤'}</div>
                    <div class="profile-info">
                        <h1>${profile.username}</h1>
                        <p class="profile-specialization">${profile.subject || 'Student'}</p>
                        <div class="profile-stats-row">
                            <div class="profile-stat">
                                <h3>${profile.notes_uploaded || 0}</h3>
                                <p>Notes Uploaded</p>
                            </div>
                            <div class="profile-stat">
                                <h3>${profile.total_reviews || 0}</h3>
                                <p>Reviews</p>
                            </div>
                            <div class="profile-stat">
                                <h3>${profile.average_rating ? parseFloat(profile.average_rating).toFixed(1) : '5.0'} ⭐</h3>
                                <p>Rating</p>
                            </div>
                        </div>
                        ${isOwnProfile ? '<button class="edit-profile-btn" onclick="openEditModal()">✏️ Edit Profile</button>' : ''}
                    </div>
                `;
                
                // Update about section
                document.getElementById('profileAbout').innerHTML = `
                    <p>${profile.bio || 'No bio available'}</p>
                    <div class="profile-details">
                        <p><strong>Member Since:</strong> ${Utils.formatDate(profile.join_date)}</p>
                        ${profile.university ? `<p><strong>University:</strong> ${profile.university}</p>` : ''}
                        ${profile.year ? `<p><strong>Year:</strong> ${profile.year}</p>` : ''}
                        ${profile.email && isOwnProfile ? `<p><strong>Email:</strong> ${profile.email}</p>` : ''}
                        ${profile.phone && isOwnProfile ? `<p><strong>Phone:</strong> ${profile.phone}</p>` : ''}
                    </div>
                `;
                
                // Update review count in tab
                document.getElementById('reviewsCount').textContent = profile.total_reviews || 0;
                
                // Load user's notes
                loadUserNotes(profileUserId);
            } else {
                document.getElementById('profileHeader').innerHTML = `
                    <div style="text-align: center; padding: 40px;">
                        <h3>Profile not found</h3>
                        <button onclick="location.href='browse.php'">Browse Notes</button>
                    </div>
                `;
            }
        }
        
        async function loadUserNotes(userId) {
            const result = await NotesAPI.getUserNotes(userId);
            const container = document.getElementById('userNotes');
            const countSpan = document.getElementById('notesCount');
            
            if (result.success && result.data.length > 0) {
                countSpan.textContent = result.data.length;
                
                container.innerHTML = result.data.map(note => {
                    const categoryIcons = {
                        'science': '🔬',
                        'math': '➗',
                        'history': '📜',
                        'language': '🗣️',
                        'cs': '💻',
                        'engineering': '⚙️',
                        'business': '💼',
                        'arts': '🎨'
                    };
                    
                    const icon = categoryIcons[note.category] || '📚';
                    
                    return `
                        <div class="note-card" onclick="location.href='note-detail.php?id=${note.id}'" style="cursor: pointer;">
                            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1rem; border-radius: 10px 10px 0 0; color: white;">
                                <h3 style="margin: 0; font-size: 1rem;">${icon} ${note.category.charAt(0).toUpperCase() + note.category.slice(1)}</h3>
                            </div>
                            <div style="padding: 1.5rem;">
                                <h3>${note.title}</h3>
                                <p>${note.description ? note.description.substring(0, 100) + '...' : 'No description'}</p>
                                <div class="note-meta">
                                    <span class="rating">⭐ ${note.rating || '5.0'}</span>
                                    <span class="downloads">🛒 ${note.purchased_count || 0} purchased</span>
                                </div>
                                <div class="note-footer">
                                    <span class="price">${Utils.formatPrice(note.price)}</span>
                                    <a href="note-detail.php?id=${note.id}" onclick="event.stopPropagation()">View Details</a>
                                </div>
                            </div>
                        </div>
                    `;
                }).join('');
            } else {
                countSpan.textContent = '0';
                container.innerHTML = `
                    <div style="text-align: center; padding: 3rem; background: white; border-radius: 15px;">
                        <p style="font-size: 3rem; margin-bottom: 1rem;">📚</p>
                        <p style="color: #6c757d;">No notes uploaded yet</p>
                    </div>
                `;
            }
        }
        
        async function loadReviews() {
            const reviewsList = document.getElementById('reviewsList');
            reviewsList.dataset.loaded = 'true';
            
            // Simulate loading reviews (in real app, this would be an API call)
            // For now, show sample reviews or empty state
            const sampleReviews = [
                {
                    id: 1,
                    reviewer_name: 'John Doe',
                    reviewer_avatar: '👨‍🎓',
                    rating: 5,
                    note_title: 'Advanced Calculus Notes',
                    comment: 'Excellent notes! Very detailed and well-organized. Helped me ace my exam!',
                    date: '2026-02-10'
                },
                {
                    id: 2,
                    reviewer_name: 'Jane Smith',
                    reviewer_avatar: '👩‍🎓',
                    rating: 4,
                    note_title: 'Biology 101 Complete Guide',
                    comment: 'Great content, though some sections could use more diagrams.',
                    date: '2026-02-08'
                },
                {
                    id: 3,
                    reviewer_name: 'Mike Johnson',
                    reviewer_avatar: '🧑‍💻',
                    rating: 5,
                    note_title: 'Computer Science Fundamentals',
                    comment: 'Best notes I\'ve purchased! Clear explanations and lots of examples.',
                    date: '2026-02-05'
                }
            ];
            
            const hasReviews = sampleReviews.length > 0;
            
            if (hasReviews) {
                // Update stats
                const avgRating = sampleReviews.reduce((sum, r) => sum + r.rating, 0) / sampleReviews.length;
                document.getElementById('avgRating').textContent = avgRating.toFixed(1);
                document.getElementById('totalReviews').textContent = sampleReviews.length;
                document.getElementById('recommendPercent').textContent = Math.round((sampleReviews.filter(r => r.rating >= 4).length / sampleReviews.length) * 100) + '%';
                
                // Calculate rating distribution
                const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
                sampleReviews.forEach(r => distribution[r.rating]++);
                
                // Update rating bars
                document.getElementById('ratingBars').style.display = 'block';
                for (let i = 1; i <= 5; i++) {
                    const count = distribution[i];
                    const percentage = (count / sampleReviews.length) * 100;
                    document.getElementById('bar' + i).style.width = percentage + '%';
                    document.getElementById('count' + i).textContent = count;
                }
                
                // Display reviews
                reviewsList.innerHTML = sampleReviews.map(review => `
                    <div class="review-card">
                        <div class="review-header">
                            <div class="review-author">
                                <div class="reviewer-avatar">${review.reviewer_avatar}</div>
                                <div class="reviewer-info">
                                    <h4>${review.reviewer_name}</h4>
                                    <p>${Utils.formatDate(review.date)}</p>
                                </div>
                            </div>
                            <div class="review-rating">
                                ${'⭐'.repeat(review.rating)}
                            </div>
                        </div>
                        <div class="review-note-title">
                            📝 ${review.note_title}
                        </div>
                        <p class="review-text">${review.comment}</p>
                    </div>
                `).join('');
            }
        }
        
        // Modal Functions
        function openEditModal() {
            if (!currentProfile) return;
            
            // Populate form with current data
            document.getElementById('editUsername').value = currentProfile.username || '';
            document.getElementById('editEmail').value = currentProfile.email || '';
            document.getElementById('editUniversity').value = currentProfile.university || '';
            document.getElementById('editYear').value = currentProfile.year || '';
            document.getElementById('editSubject').value = currentProfile.subject || '';
            document.getElementById('editPhone').value = currentProfile.phone || '';
            document.getElementById('editBio').value = currentProfile.bio || '';
            document.getElementById('avatarInput').value = currentProfile.avatar || '👤';
            
            // Update avatar preview
            document.getElementById('avatarPreview').textContent = currentProfile.avatar || '👤';
            
            // Update selected avatar option
            document.querySelectorAll('.avatar-option').forEach(option => {
                option.classList.remove('selected');
                if (option.dataset.avatar === currentProfile.avatar) {
                    option.classList.add('selected');
                }
            });
            
            // Update bio counter
            updateBioCounter();
            
            // Show modal
            document.getElementById('editProfileModal').classList.add('active');
            document.body.style.overflow = 'hidden';
        }
        
        function closeEditModal() {
            document.getElementById('editProfileModal').classList.remove('active');
            document.body.style.overflow = 'auto';
            
            // Clear password fields
            document.getElementById('currentPassword').value = '';
            document.getElementById('newPassword').value = '';
            
            // Hide messages
            document.getElementById('successMessage').classList.remove('show');
            document.getElementById('errorMessage').classList.remove('show');
        }
        
        function selectAvatar(emoji) {
            document.getElementById('avatarInput').value = emoji;
            document.getElementById('avatarPreview').textContent = emoji;
            
            // Update selected state
            document.querySelectorAll('.avatar-option').forEach(option => {
                option.classList.remove('selected');
                if (option.dataset.avatar === emoji) {
                    option.classList.add('selected');
                }
            });
        }
        
        function updateBioCounter() {
            const bio = document.getElementById('editBio').value;
            document.getElementById('bioCounter').textContent = bio.length;
        }
        
        // Bio character counter
        document.getElementById('editBio').addEventListener('input', updateBioCounter);
        
        // Close modal on outside click
        document.getElementById('editProfileModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeEditModal();
            }
        });
        
        // Form submission
        document.getElementById('editProfileForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const saveBtn = document.getElementById('saveBtn');
            const originalText = saveBtn.textContent;
            saveBtn.disabled = true;
            saveBtn.textContent = '⏳ Saving...';
            
            // Hide previous messages
            document.getElementById('successMessage').classList.remove('show');
            document.getElementById('errorMessage').classList.remove('show');
            
            // Collect form data
            const formData = {
                username: document.getElementById('editUsername').value,
                email: document.getElementById('editEmail').value,
                university: document.getElementById('editUniversity').value,
                year: document.getElementById('editYear').value,
                subject: document.getElementById('editSubject').value,
                phone: document.getElementById('editPhone').value,
                bio: document.getElementById('editBio').value,
                avatar: document.getElementById('avatarInput').value
            };
            
            // Add password fields if filled
            const currentPassword = document.getElementById('currentPassword').value;
            const newPassword = document.getElementById('newPassword').value;
            if (currentPassword && newPassword) {
                formData.current_password = currentPassword;
                formData.new_password = newPassword;
            }
            
            try {
                const result = await UserAPI.updateProfile(formData);
                
                if (result.success) {
                    // Show success message
                    document.getElementById('successMessage').classList.add('show');
                    
                    // Reload profile after 1 second
                    setTimeout(() => {
                        closeEditModal();
                        loadProfile();
                    }, 1500);
                } else {
                    // Show error message
                    document.getElementById('errorText').textContent = result.message || 'Failed to update profile';
                    document.getElementById('errorMessage').classList.add('show');
                    saveBtn.disabled = false;
                    saveBtn.textContent = originalText;
                }
            } catch (error) {
                document.getElementById('errorText').textContent = 'An error occurred. Please try again.';
                document.getElementById('errorMessage').classList.add('show');
                saveBtn.disabled = false;
                saveBtn.textContent = originalText;
            }
        });
        
        loadProfile();
    </script>
</body>
</html>
