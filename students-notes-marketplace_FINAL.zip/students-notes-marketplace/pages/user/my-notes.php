﻿<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Notes - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        .my-notes-section {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            padding: 2rem 0 4rem;
            min-height: calc(100vh - 300px);
        }
        
        .page-header {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
        }
        
        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }
        
        .header-top h2 {
            font-size: 2rem;
            color: #2c3e50;
            margin: 0;
        }
        
        .header-actions {
            display: flex;
            gap: 1rem;
        }
        
        .btn-upload-new {
            padding: 0.8rem 1.5rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .btn-upload-new:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .stats-overview {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
        }
        
        .stat-box {
            background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            transition: all 0.3s;
        }
        
        .stat-box:hover {
            transform: translateY(-3px);
        }
        
        .stat-box h3 {
            font-size: 2rem;
            margin: 0 0 0.5rem 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .stat-box p {
            margin: 0;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .tabs-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            gap: 1rem;
            flex-wrap: wrap;
        }
        
        .tabs {
            display: flex;
            gap: 0.5rem;
            background: white;
            padding: 0.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
        }
        
        .tab {
            padding: 0.8rem 1.5rem;
            background: none;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 1rem;
            color: #6c757d;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        
        .tab:hover {
            color: #667eea;
            background: #f8f9fa;
        }
        
        .tab.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .tab-badge {
            background: rgba(255, 255, 255, 0.3);
            padding: 0.2rem 0.6rem;
            border-radius: 12px;
            font-size: 0.85rem;
        }
        
        .tab.active .tab-badge {
            background: rgba(255, 255, 255, 0.3);
        }
        
        .filters-row {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .filter-select {
            padding: 0.8rem 1rem;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            background: white;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .filter-select:focus {
            outline: none;
            border-color: #667eea;
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
            animation: fadeIn 0.3s ease-in;
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .notes-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 1.5rem;
        }
        
        .my-note-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
            display: flex;
            flex-direction: column;
        }
        
        .my-note-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
        }
        
        .note-card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 1.5rem;
            color: white;
        }
        
        .note-card-header h3 {
            margin: 0 0 0.5rem 0;
            font-size: 1.2rem;
            line-height: 1.3;
        }
        
        .note-category {
            display: inline-block;
            background: rgba(255, 255, 255, 0.3);
            padding: 0.3rem 0.8rem;
            border-radius: 15px;
            font-size: 0.85rem;
        }
        
        .note-card-body {
            padding: 1.5rem;
            flex: 1;
        }
        
        .note-description {
            color: #6c757d;
            font-size: 0.9rem;
            line-height: 1.6;
            margin-bottom: 1rem;
        }
        
        .note-stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1rem;
            margin-bottom: 1rem;
        }
        
        .note-stat-item {
            background: #f8f9fa;
            padding: 0.8rem;
            border-radius: 8px;
            text-align: center;
        }
        
        .note-stat-value {
            font-size: 1.3rem;
            font-weight: 700;
            color: #667eea;
            display: block;
        }
        
        .note-stat-label {
            font-size: 0.8rem;
            color: #6c757d;
            margin-top: 0.2rem;
        }
        
        .note-card-footer {
            padding: 1rem 1.5rem;
            background: #f8f9fa;
            display: flex;
            gap: 0.5rem;
            border-top: 1px solid #e9ecef;
        }
        
        .btn-action {
            flex: 1;
            padding: 0.7rem;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.3rem;
        }
        
        .btn-view {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
        }
        
        .btn-view:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        
        .btn-edit {
            background: #4facfe;
            color: white;
        }
        
        .btn-edit:hover {
            background: #3a9ce5;
            transform: translateY(-2px);
        }
        
        .btn-delete {
            background: #e74c3c;
            color: white;
        }
        
        .btn-delete:hover {
            background: #c0392b;
            transform: translateY(-2px);
        }
        
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border-radius: 15px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.06);
        }
        
        .empty-icon {
            font-size: 5rem;
            margin-bottom: 1rem;
            opacity: 0.5;
        }
        
        .empty-state h3 {
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .empty-state p {
            color: #6c757d;
            margin-bottom: 1.5rem;
        }
        
        .btn-empty-action {
            padding: 1rem 2rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-empty-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        @media (max-width: 768px) {
            .header-top {
                flex-direction: column;
                align-items: flex-start;
                gap: 1rem;
            }
            
            .tabs-container {
                flex-direction: column;
                align-items: stretch;
            }
            
            .tabs {
                width: 100%;
            }
            
            .tab {
                flex: 1;
                justify-content: center;
            }
            
            .filters-row {
                width: 100%;
                flex-direction: column;
            }
            
            .filter-select {
                width: 100%;
            }
            
            .notes-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-overview {
                grid-template-columns: 1fr;
            }
        }
        
        /* Rating Modal Styles */
        .modal {
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .modal-content {
            background-color: white;
            padding: 2rem;
            border-radius: 15px;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            position: relative;
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            line-height: 20px;
        }
        
        .close:hover,
        .close:focus {
            color: #000;
        }
        
        .rating-stars {
            display: flex;
            justify-content: center;
            gap: 0.5rem;
            margin: 2rem 0;
        }
        
        .star {
            font-size: 3rem;
            cursor: pointer;
            transition: all 0.2s;
            filter: grayscale(100%);
            opacity: 0.4;
        }
        
        .star:hover,
        .star.active {
            filter: grayscale(0%);
            opacity: 1;
            transform: scale(1.1);
        }
        
        .btn-rate {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
        }
        
        .btn-rate:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(245, 87, 108, 0.3);
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">
                <h1>KwikPaper</h1>
            </div>
            <nav>
                <a href="index.php">Home</a>
                <a href="browse.php">Browse Notes</a>
                <a href="upload.php">Upload</a>
                <a href="my-notes.php">My Notes</a>
            </nav>
            <div class="nav-search">
                <input type="text" placeholder="Search notes..." id="navSearch">
            </div>
            <nav class="nav-right">
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <span class="admin-badge">ADMIN</span>
                <?php endif; ?>
                <span class="user-welcome">👋 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                <?php if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                    <a href="admin.php" class="btn-admin" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 0.6rem 1.2rem; border-radius: 8px; text-decoration: none; font-weight: 600;">Admin</a>
                <?php endif; ?>
                <a href="dashboard.php" class="btn-dashboard">Dashboard</a>
                <a href="api/auth/logout.php" class="btn-logout">Logout</a>
            </nav>
        </div>
    </header>

    <section class="my-notes-section">
        <div class="container" style="max-width: 1400px; margin: 80px auto 0; padding: 0 2rem;">
            
            <!-- Page Header with Stats -->
            <div class="page-header">
                <div class="header-top">
                    <h2>📚 My Notes Dashboard</h2>
                    <div class="header-actions">
                        <a href="upload.html" class="btn-upload-new">
                            <span>➕</span> Upload New Note
                        </a>
                    </div>
                </div>
                
                <div class="stats-overview">
                    <div class="stat-box">
                        <h3 id="total-uploads">0</h3>
                        <p>Total Uploads</p>
                    </div>
                    <div class="stat-box">
                        <h3 id="total-downloads">0</h3>
                        <p>Total Purchased</p>
                    </div>
                    <div class="stat-box">
                        <h3 id="total-earnings">$0</h3>
                        <p>Total Earnings</p>
                    </div>
                    <div class="stat-box">
                        <h3 id="total-purchased">0</h3>
                        <p>Notes Purchased</p>
                    </div>
                </div>
            </div>

            <!-- Tabs and Filters -->
            <div class="tabs-container">
                <div class="tabs">
                    <button class="tab active" onclick="switchTab('uploaded', event)">
                        📤 Uploaded Notes
                        <span class="tab-badge" id="uploaded-count">0</span>
                    </button>
                    <button class="tab" onclick="switchTab('purchased', event)">
                        🛒 Purchased Notes
                        <span class="tab-badge" id="purchased-count">0</span>
                    </button>
                </div>
                
                <div class="filters-row">
                    <select class="filter-select" id="sort-select" onchange="applySorting()">
                        <option value="newest">Newest First</option>
                        <option value="oldest">Oldest First</option>
                        <option value="price-high">Price: High to Low</option>
                        <option value="price-low">Price: Low to High</option>
                        <option value="popular">Most Purchased</option>
                    </select>
                </div>
            </div>

            <!-- Uploaded Notes Tab -->
            <div id="uploaded-tab" class="tab-content active">
                <div class="notes-grid" id="uploaded-notes-grid"></div>
                
                <div id="uploaded-empty" class="empty-state" style="display: none;">
                    <div class="empty-icon">📝</div>
                    <h3>No Uploaded Notes Yet</h3>
                    <p>Start sharing your knowledge by uploading your first note!</p>
                    <a href="upload.html" class="btn-empty-action">Upload Your First Note</a>
                </div>
            </div>

            <!-- Purchased Notes Tab -->
            <div id="purchased-tab" class="tab-content">
                <div class="notes-grid" id="purchased-notes-grid"></div>
                
                <div id="purchased-empty" class="empty-state" style="display: none;">
                    <div class="empty-icon">🛍️</div>
                    <h3>No Purchased Notes Yet</h3>
                    <p>Explore the marketplace and find helpful notes for your studies!</p>
                    <a href="browse.html" class="btn-empty-action">Browse Notes</a>
                </div>
            </div>

        </div>
    </section>

    <!-- Rating Modal -->
    <div id="ratingModal" class="modal" style="display: none;">
        <div class="modal-content">
            <span class="close" onclick="closeRatingModal()">&times;</span>
            <h2>Rate This Note</h2>
            <p id="ratingNoteTitle" style="color: #6c757d; margin-bottom: 2rem;"></p>
            
            <div class="rating-stars" id="ratingStars">
                <span class="star" data-rating="1">⭐</span>
                <span class="star" data-rating="2">⭐</span>
                <span class="star" data-rating="3">⭐</span>
                <span class="star" data-rating="4">⭐</span>
                <span class="star" data-rating="5">⭐</span>
            </div>
            
            <p id="ratingText" style="text-align: center; margin: 1rem 0; font-weight: 600; color: #667eea;">Select a rating</p>
            
            <textarea id="reviewComment" placeholder="Write your review (optional)" 
                     style="width: 100%; min-height: 100px; padding: 0.8rem; border: 1px solid #ddd; border-radius: 8px; margin: 1rem 0; font-family: 'Poppins', sans-serif; resize: vertical;"></textarea>
            
            <div style="display: flex; gap: 1rem; justify-content: flex-end;">
                <button onclick="closeRatingModal()" class="btn-secondary" 
                       style="padding: 0.8rem 2rem; border: none; border-radius: 8px; cursor: pointer; background: #e9ecef; color: #495057;">
                    Cancel
                </button>
                <button onclick="submitRating()" class="btn-primary" 
                       style="padding: 0.8rem 2rem; border: none; border-radius: 8px; cursor: pointer; background: #667eea; color: white;">
                    Submit Rating
                </button>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-col">
                    <h4>About</h4>
                    <ul>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="how-it-works.php">How It Works</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Support</h4>
                    <ul>
                        <li><a href="browse.php">Help Center</a></li>
                        <li><a href="index.php" onclick="alert('Contact form coming soon! For now, please reach out via social media.'); return false;">Contact Us</a></li>
                        <li><a href="terms-of-service.php">Terms of Service</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Connect</h4>
                    <ul>
                        <li><a href="https://facebook.com" target="_blank" rel="noopener noreferrer">Facebook</a></li>
                        <li><a href="https://twitter.com" target="_blank" rel="noopener noreferrer">Twitter</a></li>
                        <li><a href="https://instagram.com" target="_blank" rel="noopener noreferrer">Instagram</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 KwikPaper. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="api-helper.js"></script>
    <script src="nav-search.js"></script>
    <script>
        let uploadedNotes = [];
        let purchasedNotes = [];
        
        // Category icons mapping
        const categoryIcons = {
            'Mathematics': '🔢',
            'Science': '🔬',
            'Engineering': '⚙️',
            'Business': '💼',
            'Arts': '🎨',
            'Literature': '📖',
            'History': '📜',
            'Computer Science': '💻',
            'default': '📚'
        };
        
        function getCategoryIcon(category) {
            return categoryIcons[category] || categoryIcons['default'];
        }
        
        function switchTab(tabName, event) {
            // Update tabs
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });
            
            // If event exists (clicked), use it to set active tab
            if (event && event.target) {
                event.target.closest('.tab').classList.add('active');
            } else {
                // Otherwise find the tab button by tabName
                document.querySelectorAll('.tab').forEach(tab => {
                    if (tab.onclick && tab.onclick.toString().includes(tabName)) {
                        tab.classList.add('active');
                    }
                });
            }
            
            // Update content
            document.querySelectorAll('.tab-content').forEach(content => {
                content.classList.remove('active');
            });
            document.getElementById(`${tabName}-tab`).classList.add('active');
        }
        
        function applySorting() {
            const sortValue = document.getElementById('sort-select').value;
            const activeTab = document.querySelector('.tab.active').textContent.includes('Uploaded') ? 'uploaded' : 'purchased';
            
            let notes = activeTab === 'uploaded' ? [...uploadedNotes] : [...purchasedNotes];
            
            switch(sortValue) {
                case 'newest':
                    notes.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                    break;
                case 'oldest':
                    notes.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
                    break;
                case 'price-high':
                    notes.sort((a, b) => b.price - a.price);
                    break;
                case 'price-low':
                    notes.sort((a, b) => a.price - b.price);
                    break;
                case 'popular':
                    notes.sort((a, b) => (b.purchased_count || 0) - (a.purchased_count || 0));
                    break;
            }
            
            if (activeTab === 'uploaded') {
                displayUploadedNotes(notes);
            } else {
                displayPurchasedNotes(notes);
            }
        }
        
        function displayUploadedNotes(notes) {
            const grid = document.getElementById('uploaded-notes-grid');
            const empty = document.getElementById('uploaded-empty');
            
            console.log('Displaying notes:', notes);
            
            if (!notes || notes.length === 0) {
                grid.innerHTML = '';
                empty.style.display = 'block';
                grid.style.display = 'none';
                return;
            }
            
            empty.style.display = 'none';
            grid.style.display = 'grid';
            grid.innerHTML = notes.map(note => {
                const earnings = (note.price * (note.purchased_count || 0)).toFixed(2);
                const icon = getCategoryIcon(note.category);
                
                return `
                    <div class="my-note-card">
                        <div class="note-card-header">
                            <h3>${Utils.escapeHtml(note.title)}</h3>
                            <span class="note-category">${icon} ${Utils.escapeHtml(note.category)}</span>
                        </div>
                        <div class="note-card-body">
                            <p class="note-description">${Utils.escapeHtml(note.description || 'No description available')}</p>
                            <div class="note-stats-grid">
                                <div class="note-stat-item">
                                    <span class="note-stat-value">${Utils.formatPrice(note.price)}</span>
                                    <span class="note-stat-label">Price</span>
                                </div>
                                <div class="note-stat-item">
                                    <span class="note-stat-value">${note.purchased_count || 0}</span>
                                    <span class="note-stat-label">Purchased</span>
                                </div>
                                <div class="note-stat-item">
                                    <span class="note-stat-value">$${earnings}</span>
                                    <span class="note-stat-label">Earnings</span>
                                </div>
                                <div class="note-stat-item">
                                    <span class="note-stat-value">${note.rating && !isNaN(note.rating) ? parseFloat(note.rating).toFixed(1) : 'N/A'}</span>
                                    <span class="note-stat-label">Rating</span>
                                </div>
                            </div>
                        </div>
                        <div class="note-card-footer">
                            <button class="btn-action btn-view" onclick="viewNote(${note.id})">
                                � View Full Note
                            </button>
                            <button class="btn-action btn-edit" onclick="viewNoteDetails(${note.id})">
                                🔍 Public Preview
                            </button>
                            <button class="btn-action btn-delete" onclick="deleteNote(${note.id})">
                                🗑️ Delete
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }
        
        function displayPurchasedNotes(notes) {
            const grid = document.getElementById('purchased-notes-grid');
            const empty = document.getElementById('purchased-empty');
            
            if (!notes || notes.length === 0) {
                grid.innerHTML = '';
                empty.style.display = 'block';
                grid.style.display = 'none';
                return;
            }
            
            empty.style.display = 'none';
            grid.style.display = 'grid';
            grid.innerHTML = notes.map(note => {
                const icon = getCategoryIcon(note.category);
                const isFree = note.paid_amount == 0 || note.is_free == 1;
                const priceLabel = isFree ? '🎁 FREE' : Utils.formatPrice(note.paid_amount);
                const downloadDateLabel = note.purchase_date ? new Date(note.purchase_date).toLocaleDateString() : 'N/A';
                
                return `
                    <div class="my-note-card">
                        <div class="note-card-header">
                            <h3>${Utils.escapeHtml(note.title)}</h3>
                            <span class="note-category">${icon} ${Utils.escapeHtml(note.category)}</span>
                        </div>
                        <div class="note-card-body">
                            <p class="note-description">${Utils.escapeHtml(note.description || 'No description available')}</p>
                            <div class="note-stats-grid">
                                <div class="note-stat-item">
                                    <span class="note-stat-value">${priceLabel}</span>
                                    <span class="note-stat-label">${isFree ? 'Downloaded' : 'Purchased'}</span>
                                </div>
                                <div class="note-stat-item">
                                    <span class="note-stat-value">${downloadDateLabel}</span>
                                    <span class="note-stat-label">Date</span>
                                </div>
                                <div class="note-stat-item">
                                    <span class="note-stat-value">${note.rating && !isNaN(note.rating) ? parseFloat(note.rating).toFixed(1) : 'N/A'}</span>
                                    <span class="note-stat-label">Rating</span>
                                </div>
                            </div>
                        </div>
                        <div class="note-card-footer">
                            <button class="btn-action btn-view" onclick="viewNote(${note.id})">
                                👁️ Read Note
                            </button>
                            <button class="btn-action btn-rate" onclick="openRatingModal(${note.id}, '${Utils.escapeHtml(note.title)}')">
                                ⭐ Rate
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }
        
        function updateStats() {
            const totalUploads = uploadedNotes.length;
            const totalDownloads = uploadedNotes.reduce((sum, note) => sum + (note.purchased_count || 0), 0);
            const totalEarnings = uploadedNotes.reduce((sum, note) => sum + (note.price * (note.purchased_count || 0)), 0);
            const totalPurchased = purchasedNotes.length;
            
            document.getElementById('total-uploads').textContent = totalUploads;
            document.getElementById('total-downloads').textContent = totalDownloads;
            document.getElementById('total-earnings').textContent = Utils.formatPrice(totalEarnings);
            document.getElementById('total-purchased').textContent = totalPurchased;
            
            document.getElementById('uploaded-count').textContent = totalUploads;
            document.getElementById('purchased-count').textContent = totalPurchased;
        }
        
        // Rating Modal Functions
        let currentRatingNoteId = null;
        let selectedRating = 0;
        
        function openRatingModal(noteId, noteTitle) {
            currentRatingNoteId = noteId;
            selectedRating = 0;
            
            document.getElementById('ratingNoteTitle').textContent = noteTitle;
            document.getElementById('reviewComment').value = '';
            document.getElementById('ratingText').textContent = 'Select a rating';
            
            // Reset stars
            document.querySelectorAll('.star').forEach(star => {
                star.classList.remove('active');
            });
            
            // Check if user has already rated this note
            fetch(`api/notes/get-review.php?note_id=${noteId}`)
                .then(response => response.json())
                .then(result => {
                    if (result.success && result.data) {
                        selectedRating = result.data.rating;
                        document.getElementById('reviewComment').value = result.data.comment || '';
                        updateStarDisplay(selectedRating);
                        updateRatingText(selectedRating);
                    }
                })
                .catch(error => console.error('Error loading existing review:', error));
            
            document.getElementById('ratingModal').style.display = 'flex';
        }
        
        function closeRatingModal() {
            document.getElementById('ratingModal').style.display = 'none';
            currentRatingNoteId = null;
            selectedRating = 0;
        }
        
        function updateStarDisplay(rating) {
            document.querySelectorAll('.star').forEach((star, index) => {
                if (index < rating) {
                    star.classList.add('active');
                } else {
                    star.classList.remove('active');
                }
            });
        }
        
        function updateRatingText(rating) {
            const ratingTexts = ['', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent'];
            document.getElementById('ratingText').textContent = ratingTexts[rating] || 'Select a rating';
        }
        
        async function submitRating() {
            if (selectedRating === 0) {
                alert('Please select a rating');
                return;
            }
            
            const comment = document.getElementById('reviewComment').value.trim();
            
            try {
                const response = await fetch('api/notes/submit-review.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        note_id: currentRatingNoteId,
                        rating: selectedRating,
                        comment: comment
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    alert('✅ ' + result.message);
                    closeRatingModal();
                    // Reload purchased notes to update ratings
                    await loadPurchasedNotes();
                } else {
                    alert('❌ ' + result.message);
                }
            } catch (error) {
                console.error('Error submitting review:', error);
                alert('Failed to submit review. Please try again.');
            }
        }
        
        // Star click handlers
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.star').forEach(star => {
                star.addEventListener('click', function() {
                    selectedRating = parseInt(this.getAttribute('data-rating'));
                    updateStarDisplay(selectedRating);
                    updateRatingText(selectedRating);
                });
                
                star.addEventListener('mouseenter', function() {
                    const hoverRating = parseInt(this.getAttribute('data-rating'));
                    updateStarDisplay(hoverRating);
                });
            });
            
            document.getElementById('ratingStars').addEventListener('mouseleave', function() {
                updateStarDisplay(selectedRating);
            });
        });
        
        async function loadUploadedNotes() {
            try {
                console.log('Loading uploaded notes...');
                const result = await NotesAPI.getUserNotes();
                console.log('API Result:', result);
                
                if (result.success) {
                    uploadedNotes = result.data || [];
                    console.log('Uploaded notes:', uploadedNotes);
                    displayUploadedNotes(uploadedNotes);
                    updateStats();
                } else {
                    console.error('Failed to load uploaded notes:', result.error || result.message);
                    document.getElementById('uploaded-empty').style.display = 'block';
                    document.getElementById('uploaded-notes-grid').innerHTML = '';
                }
            } catch (error) {
                console.error('Error loading uploaded notes:', error);
                document.getElementById('uploaded-empty').style.display = 'block';
                document.getElementById('uploaded-notes-grid').innerHTML = '';
            }
        }
        
        async function loadPurchasedNotes() {
            try {
                const response = await fetch('api/notes/purchased.php');
                const result = await response.json();
                
                console.log('Purchased notes response:', result);
                
                if (result.success && result.data) {
                    purchasedNotes = result.data;
                } else {
                    purchasedNotes = [];
                }
                
                displayPurchasedNotes(purchasedNotes);
                updateStats();
            } catch (error) {
                console.error('Error loading purchased notes:', error);
                purchasedNotes = [];
                displayPurchasedNotes(purchasedNotes);
                document.getElementById('purchased-empty').style.display = 'block';
            }
        }
        
        function viewNote(noteId) {
            window.location.href = `view-note.php?id=${noteId}`;
        }
        
        function viewNoteDetails(noteId) {
            window.location.href = `note-detail.php?id=${noteId}`;
        }
        
        async function deleteNote(noteId) {
            if (!confirm('Are you sure you want to delete this note? This action cannot be undone.')) {
                return;
            }
            
            try {
                const response = await fetch(`api/notes/delete.php?id=${noteId}`, {
                    method: 'DELETE',
                    credentials: 'include'
                });
                
                const result = await response.json();
                
                if (result.success) {
                    alert('Note deleted successfully!');
                    loadUploadedNotes();
                } else {
                    alert('Failed to delete note: ' + (result.error || 'Unknown error'));
                }
            } catch (error) {
                console.error('Error deleting note:', error);
                alert('Failed to delete note. Please try again.');
            }
        }
        
        // Load data on page load
        document.addEventListener('DOMContentLoaded', () => {
            loadUploadedNotes();
            loadPurchasedNotes();
            
            // Check for tab query parameter
            const urlParams = new URLSearchParams(window.location.search);
            const tab = urlParams.get('tab');
            if (tab === 'purchased') {
                switchTab('purchased');
            }
        });
    </script>
</body>
</html>
