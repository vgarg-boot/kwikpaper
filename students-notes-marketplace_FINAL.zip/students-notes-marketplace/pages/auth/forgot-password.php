<?php
session_start();
if(isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f8f9fa; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 1rem; }
        .card { background: white; width: 100%; max-width: 460px; padding: 2rem; border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
        h1 { font-size: 1.8rem; margin-bottom: 0.5rem; color: #2c3e50; }
        p { color: #6c757d; margin-bottom: 1.5rem; }
        .form-group { margin-bottom: 1rem; }
        label { display: block; margin-bottom: 0.45rem; font-weight: 500; color: #2c3e50; }
        input { width: 100%; padding: 0.85rem 0.95rem; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem; }
        input:focus { outline: none; border-color: #667eea; }
        .btn { width: 100%; padding: 0.95rem; border: none; border-radius: 10px; color: white; font-weight: 600; cursor: pointer; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .btn:disabled { opacity: 0.65; cursor: not-allowed; }
        .alert { display: none; padding: 0.9rem; border-radius: 10px; margin-bottom: 1rem; }
        .alert-success { display: block; background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { display: block; background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .links { margin-top: 1rem; display: flex; justify-content: space-between; gap: 1rem; }
        .links a { color: #667eea; text-decoration: none; font-size: 0.95rem; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Forgot Password</h1>
        <p>Enter your email and we’ll send you a reset link.</p>

        <div id="alertBox" class="alert"></div>

        <form id="forgotPasswordForm">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" required placeholder="you@example.com">
            </div>
            <button type="submit" class="btn" id="submitBtn">Send Reset Link</button>
        </form>

        <div class="links">
            <a href="login.php">← Back to Login</a>
            <a href="register.php">Create Account</a>
        </div>
    </div>

    <script src="api-helper.js"></script>
    <script>
        function showAlert(message, type) {
            const alertBox = document.getElementById('alertBox');
            alertBox.textContent = message;
            alertBox.className = 'alert ' + (type === 'success' ? 'alert-success' : 'alert-error');
        }

        document.getElementById('forgotPasswordForm').addEventListener('submit', async function(e) {
            e.preventDefault();

            const submitBtn = document.getElementById('submitBtn');
            const email = document.getElementById('email').value.trim();

            submitBtn.disabled = true;
            submitBtn.textContent = 'Sending...';

            try {
                const result = await AuthAPI.forgotPassword(email);
                if (result.success) {
                    showAlert(result.message, 'success');
                } else {
                    showAlert(result.message || 'Could not send reset email', 'error');
                }
            } catch (error) {
                showAlert('Something went wrong. Please try again.', 'error');
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Send Reset Link';
            }
        });
    </script>
</body>
</html>
