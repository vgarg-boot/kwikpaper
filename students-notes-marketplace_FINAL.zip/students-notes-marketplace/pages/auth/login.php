<?php
session_start();
// Redirect if already logged in
if(isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            height: 100vh;
            overflow: hidden;
        }
        
        .auth-wrapper {
            display: grid;
            grid-template-columns: 1fr 1fr;
            height: 100vh;
            width: 100%;
        }
        
        .auth-left {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 3rem;
            position: relative;
            overflow: hidden;
        }
        
        .auth-left::before {
            content: '';
            position: absolute;
            width: 500px;
            height: 500px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -200px;
            left: -200px;
        }
        
        .auth-left::after {
            content: '';
            position: absolute;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            bottom: -150px;
            right: -150px;
        }
        
        .brand-content {
            position: relative;
            z-index: 1;
            color: white;
            text-align: center;
        }
        
        .brand-logo {
            font-size: 5rem;
            margin-bottom: 1rem;
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
        }
        
        .brand-content h1 {
            font-size: 3rem;
            margin-bottom: 1rem;
            font-weight: 700;
        }
        
        .brand-content p {
            font-size: 1.2rem;
            opacity: 0.95;
            line-height: 1.6;
            max-width: 400px;
        }
        
        .features-list {
            margin-top: 2rem;
            text-align: left;
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1rem;
            background: rgba(255, 255, 255, 0.1);
            padding: 1rem;
            border-radius: 10px;
            backdrop-filter: blur(10px);
        }
        
        .feature-icon {
            font-size: 2rem;
        }
        
        .auth-right {
            background: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 3rem;
        }
        
        .auth-form-container {
            background: white;
            padding: 3rem;
            border-radius: 20px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 450px;
            animation: slideIn 0.5s ease-out;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .form-header {
            margin-bottom: 2rem;
        }
        
        .form-header h2 {
            font-size: 2rem;
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }
        
        .form-header p {
            color: #6c757d;
            font-size: 0.95rem;
        }
        
        .form-group {
            margin-bottom: 1.5rem;
        }
        
        .form-label {
            display: block;
            margin-bottom: 0.5rem;
            color: #2c3e50;
            font-weight: 500;
            font-size: 0.9rem;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .input-icon {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.2rem;
            color: #6c757d;
        }
        
        .form-input {
            width: 100%;
            padding: 1rem 1rem 1rem 3rem;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            font-size: 1rem;
            font-family: 'Poppins', sans-serif;
            transition: all 0.3s;
            background: #f8f9fa;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #667eea;
            background: white;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        .password-toggle {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            font-size: 1.2rem;
            color: #6c757d;
            transition: color 0.3s;
        }
        
        .password-toggle:hover {
            color: #667eea;
        }
        
        .form-checkbox {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1.5rem;
        }
        
        .form-checkbox input {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .form-checkbox label {
            color: #6c757d;
            font-size: 0.9rem;
            cursor: pointer;
        }
        
        .forgot-password {
            text-align: right;
            margin-top: -1rem;
            margin-bottom: 1.5rem;
        }
        
        .forgot-password a {
            color: #667eea;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s;
        }
        
        .forgot-password a:hover {
            color: #764ba2;
        }
        
        .btn-submit {
            width: 100%;
            padding: 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4);
        }
        
        .btn-submit:active {
            transform: translateY(0);
        }
        
        .btn-submit:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }
        
        .form-divider {
            text-align: center;
            margin: 2rem 0;
            position: relative;
        }
        
        .form-divider::before,
        .form-divider::after {
            content: '';
            position: absolute;
            top: 50%;
            width: 40%;
            height: 1px;
            background: #e9ecef;
        }
        
        .form-divider::before {
            left: 0;
        }
        
        .form-divider::after {
            right: 0;
        }
        
        .form-divider span {
            background: white;
            padding: 0 1rem;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .form-footer {
            text-align: center;
            margin-top: 2rem;
        }
        
        .form-footer p {
            color: #6c757d;
            font-size: 0.95rem;
        }
        
        .form-footer a {
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }
        
        .form-footer a:hover {
            color: #764ba2;
        }
        
        .back-home {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            margin-top: 1rem;
            color: #6c757d;
            text-decoration: none;
            font-size: 0.9rem;
            transition: color 0.3s;
        }
        
        .back-home:hover {
            color: #667eea;
        }
        
        .alert {
            padding: 1rem;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            display: none;
            animation: slideDown 0.3s ease-out;
        }
        
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @media (max-width: 968px) {
            .auth-wrapper {
                grid-template-columns: 1fr;
            }
            
            .auth-left {
                display: none;
            }
            
            .auth-right {
                padding: 2rem 1rem;
            }
            
            .auth-form-container {
                padding: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="auth-wrapper">
        <div class="auth-left">
            <div class="brand-content">
                <div class="brand-logo">KP</div>
                <h1>KwikPaper</h1>
                <p>Your ultimate platform for sharing and accessing quality study notes</p>
                
                <div class="features-list">
                    <div class="feature-item">
                        <span class="feature-icon">📝</span>
                        <div>
                            <strong>Upload & Share</strong>
                            <p style="font-size: 0.9rem; opacity: 0.9; margin-top: 0.2rem;">Share your knowledge and earn</p>
                        </div>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">🎓</span>
                        <div>
                            <strong>Access Quality Notes</strong>
                            <p style="font-size: 0.9rem; opacity: 0.9; margin-top: 0.2rem;">Find notes from top students</p>
                        </div>
                    </div>
                    <div class="feature-item">
                        <span class="feature-icon">💰</span>
                        <div>
                            <strong>Earn Money</strong>
                            <p style="font-size: 0.9rem; opacity: 0.9; margin-top: 0.2rem;">Monetize your study materials</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="auth-right">
            <div class="auth-form-container">
                <div class="form-header">
                    <h2>Welcome Back!</h2>
                    <p>Enter your credentials to access your account</p>
                </div>
                
                <div id="alertBox" class="alert"></div>
                
                <form id="loginForm">
                    <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <div class="input-wrapper">
                            <span class="input-icon">📧</span>
                            <input type="email" id="loginEmail" class="form-input" placeholder="Enter your email address" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Password</label>
                        <div class="input-wrapper">
                            <span class="input-icon">🔒</span>
                            <input type="password" id="loginPassword" class="form-input" placeholder="Enter your password" required>
                            <button type="button" class="password-toggle" onclick="togglePassword('loginPassword')">
                                👁️
                            </button>
                        </div>
                    </div>
                    
                    <div class="forgot-password">
                        <a href="forgot-password.php">Forgot Password?</a>
                    </div>
                    
                    <button type="submit" class="btn-submit" id="submitBtn">
                        Login
                    </button>
                </form>
                
                <div class="form-footer">
                    <p>Don't have an account? <a href="register.php">Create one now</a></p>
                    <a href="index.php" class="back-home">
                        ← Back to Home
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <script src="api-helper.js?v=2"></script>
    <script>
        // Check for verification status in URL
        const urlParams = new URLSearchParams(window.location.search);
        const verification = urlParams.get('verification');
        
        if (verification) {
            const alertBox = document.getElementById('alertBox');
            alertBox.style.display = 'block';
            
            switch(verification) {
                case 'success':
                    alertBox.className = 'alert alert-success';
                    alertBox.innerHTML = '✅ Email verified successfully! You can now login.';
                    break;
                case 'expired':
                    alertBox.className = 'alert alert-error';
                    alertBox.innerHTML = '❌ Verification link has expired. Please request a new one below.';
                    break;
                case 'invalid':
                    alertBox.className = 'alert alert-error';
                    alertBox.innerHTML = '❌ Invalid verification link. Please try again.';
                    break;
                case 'missing_token':
                    alertBox.className = 'alert alert-error';
                    alertBox.innerHTML = '❌ Verification token is missing.';
                    break;
            }
            
            // Clear URL parameter
            window.history.replaceState({}, document.title, window.location.pathname);
        }
        
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const button = event.target;
            
            if (input.type === 'password') {
                input.type = 'text';
                button.textContent = '🙈';
            } else {
                input.type = 'password';
                button.textContent = '👁️';
            }
        }
        
        function showAlert(message, type) {
            const alertBox = document.getElementById('alertBox');
            alertBox.textContent = message;
            alertBox.className = `alert alert-${type}`;
            alertBox.style.display = 'block';
            
            setTimeout(() => {
                alertBox.style.display = 'none';
            }, 5000);
        }
        
        document.getElementById('loginForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = document.getElementById('submitBtn');
            const email = document.getElementById('loginEmail').value.trim();
            const password = document.getElementById('loginPassword').value;
            
            console.log('Form submitted with email:', email);
            console.log('Password length:', password.length);
            
            // Disable button during submission
            submitBtn.disabled = true;
            submitBtn.textContent = 'Logging in...';
            
            try {
                const result = await AuthAPI.login(email, password);
                
                if (result.success) {
                    showAlert('Login successful! Redirecting...', 'success');
                    setTimeout(() => {
                        window.location.href = 'dashboard.php';
                    }, 1000);
                } else {
                    // Check if email verification is required
                    if (result.email_verified === false) {
                        showAlert(result.message, 'error');
                        
                        // Show resend verification option
                        const resendHTML = `
                            <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #f5c6cb;">
                                <p style="margin-bottom: 10px;">Didn't receive the email?</p>
                                <button type="button" id="resendVerificationBtn" class="btn-submit" 
                                        style="padding: 10px 20px; font-size: 0.9rem;">
                                    Resend Verification Email
                                </button>
                            </div>
                        `;
                        const alertBox = document.getElementById('alertBox');
                        alertBox.innerHTML += resendHTML;
                        
                        // Add event listener for resend button
                        document.getElementById('resendVerificationBtn').addEventListener('click', async function() {
                            this.disabled = true;
                            this.textContent = 'Sending...';
                            
                            try {
                                const response = await fetch('api/auth/resend-verification.php', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ email: email })
                                });
                                
                                const data = await response.json();
                                
                                if (data.success) {
                                    showAlert('✅ Verification email sent! Please check your inbox.', 'success');
                                } else {
                                    showAlert('❌ ' + data.message, 'error');
                                    this.disabled = false;
                                    this.textContent = 'Resend Verification Email';
                                }
                            } catch (error) {
                                showAlert('❌ Failed to resend email. Please try again.', 'error');
                                this.disabled = false;
                                this.textContent = 'Resend Verification Email';
                            }
                        });
                    } else {
                        showAlert(result.message || 'Login failed. Please try again.', 'error');
                    }
                    
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Login';
                }
            } catch (error) {
                showAlert('An error occurred. Please try again.', 'error');
                submitBtn.disabled = false;
                submitBtn.textContent = 'Login';
            }
        });
    </script>
</body>
</html>
