<?php
session_start();
$token = isset($_GET['token']) ? trim($_GET['token']) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f8f9fa; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 1rem; }
        .card { background: white; width: 100%; max-width: 460px; padding: 2rem; border-radius: 14px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
        h1 { font-size: 1.8rem; margin-bottom: 0.5rem; color: #2c3e50; }
        p { color: #6c757d; margin-bottom: 1.5rem; }
        .form-group { margin-bottom: 1rem; }
        label { display: block; margin-bottom: 0.45rem; font-weight: 500; color: #2c3e50; }
        input { width: 100%; padding: 0.85rem 0.95rem; border: 2px solid #e9ecef; border-radius: 10px; font-size: 1rem; }
        input:focus { outline: none; border-color: #667eea; }
        .btn { width: 100%; padding: 0.95rem; border: none; border-radius: 10px; color: white; font-weight: 600; cursor: pointer; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .btn:disabled { opacity: 0.65; cursor: not-allowed; }
        .alert { display: none; padding: 0.9rem; border-radius: 10px; margin-bottom: 1rem; }
        .alert-success { display: block; background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { display: block; background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .links { margin-top: 1rem; }
        .links a { color: #667eea; text-decoration: none; font-size: 0.95rem; }
    </style>
</head>
<body>
    <div class="card">
        <h1>Reset Password</h1>
        <p>Create a new password for your account.</p>

        <div id="alertBox" class="alert"></div>

        <form id="resetPasswordForm">
            <div class="form-group">
                <label for="password">New Password</label>
                <input type="password" id="password" required minlength="6" placeholder="At least 6 characters">
            </div>
            <div class="form-group">
                <label for="confirmPassword">Confirm New Password</label>
                <input type="password" id="confirmPassword" required minlength="6" placeholder="Re-enter password">
            </div>
            <button type="submit" class="btn" id="submitBtn">Reset Password</button>
        </form>

        <div class="links">
            <a href="login.php">← Back to Login</a>
        </div>
    </div>

    <script src="api-helper.js"></script>
    <script>
        const token = <?php echo json_encode($token); ?>;

        function showAlert(message, type) {
            const alertBox = document.getElementById('alertBox');
            alertBox.textContent = message;
            alertBox.className = 'alert ' + (type === 'success' ? 'alert-success' : 'alert-error');
        }

        if (!token) {
            showAlert('Reset token is missing. Please request a new reset link.', 'error');
            document.getElementById('submitBtn').disabled = true;
        }

        document.getElementById('resetPasswordForm').addEventListener('submit', async function(e) {
            e.preventDefault();

            const submitBtn = document.getElementById('submitBtn');
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            submitBtn.disabled = true;
            submitBtn.textContent = 'Resetting...';

            try {
                const result = await AuthAPI.resetPassword(token, password, confirmPassword);
                if (result.success) {
                    showAlert(result.message, 'success');
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 1500);
                } else {
                    showAlert(result.message || 'Could not reset password', 'error');
                }
            } catch (error) {
                showAlert('Something went wrong. Please try again.', 'error');
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Reset Password';
            }
        });
    </script>
</body>
</html>
