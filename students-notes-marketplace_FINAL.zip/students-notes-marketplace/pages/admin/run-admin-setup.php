<?php
/**
 * Run All Admin Setup SQL Scripts
 * This will set up the transactions table, admin role, and related tables
 */

include_once 'api/config/database.php';

$database = new Database();
$db = $database->getConnection();

echo "<h2>Running Admin Setup Scripts</h2>";

// 1. Run add_transactions_table.sql
echo "<h3>1. Setting up Transactions Table...</h3>";
try {
    $sql = file_get_contents('api/config/add_transactions_table.sql');
    
    // Remove comments and split by semicolon
    $statements = array_filter(
        array_map('trim',
            explode(';', preg_replace('/--.*$/m', '', $sql))
        )
    );
    
    foreach ($statements as $statement) {
        if (empty($statement)) continue;
        
        try {
            $db->exec($statement);
            echo "<p style='color: green;'>✓ Executed statement successfully</p>";
        } catch(PDOException $e) {
            // Ignore errors for ALTER TABLE if column already exists
            if (strpos($e->getMessage(), 'Duplicate') !== false || strpos($e->getMessage(), 'exists') !== false) {
                echo "<p style='color: orange;'>⚠ Column/index already exists (safe to ignore)</p>";
            } else {
                echo "<p style='color: red;'>✗ Error: " . $e->getMessage() . "</p>";
            }
        }
    }
    echo "<p style='color: green;'><strong>✓ Transactions table setup complete</strong></p>";
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Error setting up transactions table: " . $e->getMessage() . "</p>";
}

// 2. Run add_admin_role.sql
echo "<h3>2. Setting up Admin Role and Tables...</h3>";
try {
    $sql = file_get_contents('api/config/add_admin_role.sql');
    
    // Remove comments and split by semicolon
    $statements = array_filter(
        array_map('trim',
            explode(';', preg_replace('/--.*$/m', '', $sql))
        )
    );
    
    foreach ($statements as $statement) {
        if (empty($statement)) continue;
        
        try {
            $db->exec($statement);
            echo "<p style='color: green;'>✓ Executed statement successfully</p>";
        } catch(PDOException $e) {
            // Ignore errors for ALTER TABLE if column already exists
            if (strpos($e->getMessage(), 'Duplicate') !== false || strpos($e->getMessage(), 'exists') !== false) {
                echo "<p style='color: orange;'>⚠ Column/table/index already exists (safe to ignore)</p>";
            } else {
                echo "<p style='color: red;'>✗ Error: " . $e->getMessage() . "</p>";
            }
        }
    }
    echo "<p style='color: green;'><strong>✓ Admin role and tables setup complete</strong></p>";
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Error setting up admin role: " . $e->getMessage() . "</p>";
}

echo "<h3>Setup Complete!</h3>";
echo "<p>All necessary tables and columns have been created.</p>";
echo "<p><a href='check-db-tables.php'>Click here to verify the database structure</a></p>";
echo "<p><a href='admin.php'>Go to Admin Dashboard</a></p>";
?>
