<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Check if user has admin role
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Notes Marketplace</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .admin-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        .admin-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }

        .admin-tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            border-bottom: 2px solid #e0e0e0;
            flex-wrap: wrap;
        }

        .admin-tab {
            padding: 15px 25px;
            background: none;
            border: none;
            cursor: pointer;
            font-size: 16px;
            color: #666;
            border-bottom: 3px solid transparent;
            transition: all 0.3s;
        }

        .admin-tab:hover {
            color: #667eea;
            background: #f5f5f5;
        }

        .admin-tab.active {
            color: #667eea;
            border-bottom-color: #667eea;
            font-weight: bold;
        }

        .admin-content {
            display: none;
        }

        .admin-content.active {
            display: block;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }

        .stat-card h3 {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .stat-card .value {
            font-size: 36px;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }

        .stat-card .change {
            font-size: 14px;
            color: #28a745;
        }

        .data-table {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .table-header {
            padding: 20px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .table-header h2 {
            margin: 0;
        }

        .table-controls {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .search-box {
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 250px;
        }

        .filter-select {
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f8f9fa;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        th {
            font-weight: 600;
            color: #333;
        }

        tbody tr:hover {
            background: #f8f9fa;
        }

        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: bold;
            display: inline-block;
        }

        .status-active, .status-completed, .status-approved {
            background: #d4edda;
            color: #155724;
        }

        .status-inactive, .status-pending {
            background: #fff3cd;
            color: #856404;
        }

        .status-rejected, .status-failed, .status-refunded {
            background: #f8d7da;
            color: #721c24;
        }

        .action-btn {
            padding: 8px 15px;
            margin: 0 5px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #667eea;
            color: white;
        }

        .btn-primary:hover {
            background: #5568d3;
        }

        .btn-success {
            background: #28a745;
            color: white;
        }

        .btn-success:hover {
            background: #218838;
        }

        .btn-danger {
            background: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background: #c82333;
        }

        .btn-warning {
            background: #ffc107;
            color: #333;
        }

        .btn-warning:hover {
            background: #e0a800;
        }

        .pagination {
            padding: 20px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .page-btn {
            padding: 8px 15px;
            border: 1px solid #ddd;
            background: white;
            cursor: pointer;
            border-radius: 5px;
        }

        .page-btn:hover {
            background: #f8f9fa;
        }

        .page-btn.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: white;
            padding: 30px;
            border-radius: 10px;
            max-width: 700px;
            width: 90%;
            max-height: 80vh;
            overflow-y: auto;
        }

        .modal-header {
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e0e0e0;
        }

        .modal-header h2 {
            margin: 0;
            color: #333;
        }

        .note-preview {
            margin: 20px 0;
        }

        .note-preview .form-group {
            margin-bottom: 20px;
        }

        .note-preview label {
            display: block;
            font-weight: 600;
            color: #666;
            margin-bottom: 5px;
            font-size: 14px;
            text-transform: uppercase;
        }

        .note-preview p {
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        .loading {
            text-align: center;
            padding: 40px;
            color: #666;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .empty-state svg {
            width: 100px;
            height: 100px;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }

            .table-header {
                flex-direction: column;
                align-items: stretch;
            }

            .table-controls {
                flex-direction: column;
            }

            .search-box {
                width: 100%;
            }

            table {
                font-size: 14px;
            }

            th, td {
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="nav-container">
            <div class="nav-left">
                <a href="index.php" class="logo">📚 Notes Marketplace</a>
                <span class="admin-badge">ADMIN</span>
            </div>
            <div class="nav-right" id="navRight">
                <a href="index.php">Home</a>
                <a href="browse.php">Browse</a>
                <a href="admin.php" class="active">Admin</a>
                <div class="user-menu">
                    <span class="user-avatar" id="userAvatar" style="font-size: 24px;"></span>
                    <span id="userName"></span>
                    <div class="dropdown-menu">
                        <a href="profile.php">Profile</a>
                        <a href="dashboard.php">Dashboard</a>
                        <a href="#" onclick="logout()">Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="admin-container">
        <!-- Admin Header -->
        <div class="admin-header">
            <h1>🛡️ Admin Dashboard</h1>
            <p>Manage users, notes, transactions, and system settings</p>
        </div>

        <!-- Admin Tabs -->
        <div class="admin-tabs">
            <button class="admin-tab active" data-tab="overview">Overview</button>
            <button class="admin-tab" data-tab="users">Users</button>
            <button class="admin-tab" data-tab="notes">Notes</button>
            <button class="admin-tab" data-tab="transactions">Transactions</button>
            <button class="admin-tab" data-tab="payouts">Seller Payouts</button>
            <button class="admin-tab" data-tab="settings">Settings</button>
            <button class="admin-tab" data-tab="logs">Activity Logs</button>
        </div>

        <!-- Overview Tab -->
        <div class="admin-content active" id="overview">
            <div class="stats-grid" id="statsGrid"></div>
            <div class="data-table">
                <div class="table-header">
                    <h2>Recent Transactions</h2>
                </div>
                <div id="recentTransactions"></div>
            </div>
        </div>

        <!-- Users Tab -->
        <div class="admin-content" id="users">
            <div class="data-table">
                <div class="table-header">
                    <h2>User Management</h2>
                    <div class="table-controls">
                        <input type="text" class="search-box" id="userSearch" placeholder="Search users...">
                        <select class="filter-select" id="userRoleFilter">
                            <option value="all">All Roles</option>
                            <option value="user">Users</option>
                            <option value="admin">Admins</option>
                        </select>
                        <select class="filter-select" id="userStatusFilter">
                            <option value="all">All Status</option>
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                </div>
                <div id="usersTable"></div>
            </div>
        </div>

        <!-- Notes Tab -->
        <div class="admin-content" id="notes">
            <div class="data-table">
                <div class="table-header">
                    <h2>Notes Management</h2>
                    <div class="table-controls">
                        <input type="text" class="search-box" id="noteSearch" placeholder="Search notes...">
                        <select class="filter-select" id="noteCategoryFilter">
                            <option value="all">All Categories</option>
                            <option value="Computer Science">Computer Science</option>
                            <option value="Mathematics">Mathematics</option>
                            <option value="Physics">Physics</option>
                            <option value="Chemistry">Chemistry</option>
                            <option value="Biology">Biology</option>
                            <option value="Business">Business</option>
                            <option value="Engineering">Engineering</option>
                            <option value="Other">Other</option>
                        </select>
                        <select class="filter-select" id="noteStatusFilter">
                            <option value="all">All Status</option>
                            <option value="approved">Approved</option>
                            <option value="pending">Pending</option>
                            <option value="rejected">Rejected</option>
                        </select>
                    </div>
                </div>
                <div id="notesTable"></div>
            </div>
        </div>

        <!-- Transactions Tab -->
        <div class="admin-content" id="transactions">
            <div class="data-table">
                <div class="table-header">
                    <h2>Transaction Management</h2>
                    <div class="table-controls">
                        <input type="text" class="search-box" id="transactionSearch" placeholder="Search transactions...">
                        <select class="filter-select" id="transactionStatusFilter">
                            <option value="all">All Status</option>
                            <option value="completed">Completed</option>
                            <option value="pending">Pending</option>
                            <option value="failed">Failed</option>
                            <option value="refunded">Refunded</option>
                        </select>
                        <button class="action-btn btn-primary" onclick="exportTransactions()">Export CSV</button>
                    </div>
                </div>
                <div id="transactionsTable"></div>
            </div>
        </div>

        <!-- Seller Payouts Tab -->
        <div class="admin-content" id="payouts">
            <div class="stats-grid" id="payoutsStatsGrid"></div>
            <div class="data-table">
                <div class="table-header">
                    <h2>Seller Earnings & Payouts</h2>
                    <div class="table-controls">
                        <input type="text" class="search-box" id="payoutSearch" placeholder="Search sellers...">
                        <select class="filter-select" id="payoutStatusFilter">
                            <option value="unpaid">Unpaid</option>
                            <option value="paid">Paid</option>
                            <option value="all">All</option>
                        </select>
                        <button class="action-btn btn-primary" onclick="exportPayouts()">Export CSV</button>
                    </div>
                </div>
                <div id="payoutsTable"></div>
            </div>
        </div>

        <!-- Settings Tab -->
        <div class="admin-content" id="settings">
            <div class="data-table">
                <div class="table-header">
                    <h2>System Settings</h2>
                </div>
                <div id="settingsForm" style="padding: 30px;"></div>
            </div>
        </div>

        <!-- Activity Logs Tab -->
        <div class="admin-content" id="logs">
            <div class="data-table">
                <div class="table-header">
                    <h2>Admin Activity Logs</h2>
                    <div class="table-controls">
                        <select class="filter-select" id="logActionFilter">
                            <option value="all">All Actions</option>
                            <option value="update_user">Update User</option>
                            <option value="delete_user">Delete User</option>
                            <option value="update_note">Update Note</option>
                            <option value="delete_note">Delete Note</option>
                            <option value="update_transaction">Update Transaction</option>
                            <option value="update_settings">Update Settings</option>
                        </select>
                    </div>
                </div>
                <div id="logsTable"></div>
            </div>
        </div>
    </div>

    <!-- Modal for editing -->
    <div class="modal" id="editModal">
        <div class="modal-content" id="modalContent"></div>
    </div>

    <script src="admin.js"></script>
</body>
</html>
