<?php
session_start();

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$transaction_id = isset($_GET['transaction_id']) ? $_GET['transaction_id'] : '';
$note_id = isset($_GET['note_id']) ? (int)$_GET['note_id'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        
        .success-container {
            max-width: 600px;
            width: 100%;
        }
        
        .success-card {
            background: white;
            border-radius: 25px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 3rem;
            text-align: center;
            animation: slideUp 0.5s ease;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .success-icon {
            font-size: 5rem;
            margin-bottom: 1.5rem;
            animation: bounce 1s ease infinite;
        }
        
        @keyframes bounce {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px);
            }
        }
        
        .success-card h1 {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 0 0 1rem 0;
            font-size: 2.5rem;
        }
        
        .success-card p {
            color: #6c757d;
            font-size: 1.1rem;
            margin-bottom: 2rem;
            line-height: 1.6;
        }
        
        .transaction-info {
            background: linear-gradient(135deg, #f8f9ff 0%, #ffffff 100%);
            border-radius: 15px;
            padding: 1.5rem;
            margin: 2rem 0;
            border: 2px solid rgba(102, 126, 234, 0.2);
        }
        
        .transaction-row {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            border-bottom: 1px dashed rgba(102, 126, 234, 0.2);
        }
        
        .transaction-row:last-child {
            border-bottom: none;
        }
        
        .transaction-row .label {
            color: #6c757d;
            font-weight: 600;
        }
        
        .transaction-row .value {
            color: #2c3e50;
            font-weight: 600;
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .btn {
            flex: 1;
            padding: 1rem 2rem;
            border-radius: 12px;
            border: none;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
        }
        
        .btn-secondary {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }
        
        .btn-secondary:hover {
            background: #667eea;
            color: white;
        }
    </style>
</head>
<body>
    <div class="success-container">
        <div class="success-card">
            <div class="success-icon">🎉</div>
            <h1>Payment Successful!</h1>
            <p>Thank you for your purchase! Your payment has been processed successfully.</p>
            
            <?php if($transaction_id): ?>
            <div class="transaction-info">
                <div class="transaction-row">
                    <span class="label">Transaction ID:</span>
                    <span class="value"><?php echo htmlspecialchars($transaction_id); ?></span>
                </div>
                <div class="transaction-row">
                    <span class="label">Status:</span>
                    <span class="value" style="color: #28a745;">✅ Completed</span>
                </div>
                <div class="transaction-row">
                    <span class="label">Access:</span>
                    <span class="value">Available Now</span>
                </div>
            </div>
            <?php endif; ?>
            
            <p style="font-size: 1rem; color: #667eea; font-weight: 600;">
                ✨ The note has been added to your library and is now accessible!
            </p>
            
            <div class="action-buttons">
                <?php if($note_id > 0): ?>
                <a href="view-note.php?id=<?php echo $note_id; ?>" class="btn btn-primary">
                    <span>📖</span>
                    <span>View Note Now</span>
                </a>
                <?php endif; ?>
                <a href="my-notes.php" class="btn btn-secondary">
                    <span>📚</span>
                    <span>My Library</span>
                </a>
            </div>
            
            <div style="margin-top: 2rem; padding-top: 2rem; border-top: 2px dashed rgba(102, 126, 234, 0.2);">
                <p style="font-size: 0.9rem; color: #6c757d; margin: 0;">
                    A confirmation email has been sent to your email address.
                </p>
            </div>
        </div>
    </div>
</body>
</html>
