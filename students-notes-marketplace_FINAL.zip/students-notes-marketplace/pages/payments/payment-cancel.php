<?php
session_start();

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$note_id = isset($_GET['note_id']) ? (int)$_GET['note_id'] : 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Cancelled - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }
        
        .cancel-container {
            max-width: 600px;
            width: 100%;
        }
        
        .cancel-card {
            background: white;
            border-radius: 25px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            padding: 3rem;
            text-align: center;
            animation: slideUp 0.5s ease;
        }
        
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .cancel-icon {
            font-size: 5rem;
            margin-bottom: 1.5rem;
        }
        
        .cancel-card h1 {
            color: #2c3e50;
            margin: 0 0 1rem 0;
            font-size: 2.5rem;
        }
        
        .cancel-card p {
            color: #6c757d;
            font-size: 1.1rem;
            margin-bottom: 2rem;
            line-height: 1.6;
        }
        
        .info-box {
            background: linear-gradient(135deg, #fff5e6 0%, #ffffff 100%);
            border-radius: 15px;
            padding: 1.5rem;
            margin: 2rem 0;
            border: 2px solid rgba(255, 152, 0, 0.2);
        }
        
        .info-box p {
            margin: 0;
            color: #856404;
            font-size: 1rem;
        }
        
        .action-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }
        
        .btn {
            flex: 1;
            padding: 1rem 2rem;
            border-radius: 12px;
            border: none;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.5);
        }
        
        .btn-secondary {
            background: white;
            color: #667eea;
            border: 2px solid #667eea;
        }
        
        .btn-secondary:hover {
            background: #667eea;
            color: white;
        }
    </style>
</head>
<body>
    <div class="cancel-container">
        <div class="cancel-card">
            <div class="cancel-icon">😕</div>
            <h1>Payment Cancelled</h1>
            <p>Your payment was cancelled. No charges have been made to your account.</p>
            
            <div class="info-box">
                <p>
                    <strong>💡 Need help?</strong><br>
                    If you encountered any issues during checkout, please contact our support team.
                </p>
            </div>
            
            <p style="font-size: 1rem;">
                You can try again anytime or browse other available notes.
            </p>
            
            <div class="action-buttons">
                <?php if($note_id > 0): ?>
                <a href="note-detail.php?id=<?php echo $note_id; ?>" class="btn btn-primary">
                    <span>🔄</span>
                    <span>Try Again</span>
                </a>
                <?php endif; ?>
                <a href="browse.php" class="btn btn-secondary">
                    <span>📚</span>
                    <span>Browse Notes</span>
                </a>
            </div>
        </div>
    </div>
</body>
</html>
