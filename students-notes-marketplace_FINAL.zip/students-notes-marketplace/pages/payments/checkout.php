<?php
session_start();

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get note ID from URL
$note_id = isset($_GET['note_id']) ? (int)$_GET['note_id'] : 0;

if ($note_id === 0) {
    header('Location: browse.php');
    exit();
}

// Get PayPal Client ID
require_once 'api/config/paypal.php';
$paypalClientId = PayPalConfig::getClientId();
$isConfigured = PayPalConfig::isConfigured();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - KwikPaper</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <!-- PayPal SDK -->
    <?php if($isConfigured): ?>
    <script src="https://www.paypal.com/sdk/js?client-id=<?php echo $paypalClientId; ?>&currency=USD"></script>
    <?php endif; ?>
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem 0;
        }
        
        .checkout-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 0 1rem;
        }
        
        .checkout-card {
            background: white;
            border-radius: 25px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            margin-bottom: 2rem;
        }
        
        .checkout-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 2rem;
            text-align: center;
        }
        
        .checkout-header h1 {
            margin: 0 0 0.5rem 0;
            font-size: 2rem;
        }
        
        .checkout-header p {
            margin: 0;
            opacity: 0.9;
        }
        
        .checkout-content {
            padding: 2.5rem;
        }
        
        .order-summary {
            background: linear-gradient(135deg, #f8f9ff 0%, #ffffff 100%);
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            border: 2px solid rgba(102, 126, 234, 0.2);
        }
        
        .order-summary h2 {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 0 0 1.5rem 0;
            font-size: 1.5rem;
        }
        
        .note-item {
            display: flex;
            gap: 1.5rem;
            padding: 1.5rem;
            background: white;
            border-radius: 12px;
            border: 2px solid rgba(102, 126, 234, 0.15);
            margin-bottom: 1.5rem;
        }
        
        .note-icon {
            font-size: 3rem;
            flex-shrink: 0;
        }
        
        .note-details {
            flex: 1;
        }
        
        .note-details h3 {
            margin: 0 0 0.5rem 0;
            color: #2c3e50;
            font-size: 1.2rem;
        }
        
        .note-details p {
            margin: 0;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .note-price {
            font-size: 2rem;
            font-weight: 700;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            flex-shrink: 0;
        }
        
        .price-breakdown {
            border-top: 2px dashed rgba(102, 126, 234, 0.2);
            padding-top: 1.5rem;
        }
        
        .price-row {
            display: flex;
            justify-content: space-between;
            padding: 0.5rem 0;
            font-size: 1rem;
        }
        
        .price-row.total {
            font-size: 1.5rem;
            font-weight: 700;
            border-top: 2px solid rgba(102, 126, 234, 0.3);
            margin-top: 1rem;
            padding-top: 1rem;
        }
        
        .price-row.total .amount {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .payment-section {
            background: linear-gradient(135deg, #f8f9ff 0%, #ffffff 100%);
            border-radius: 15px;
            padding: 2rem;
            border: 2px solid rgba(102, 126, 234, 0.2);
        }
        
        .payment-section h2 {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin: 0 0 1.5rem 0;
            font-size: 1.5rem;
        }
        
        #paypal-button-container {
            margin-top: 1.5rem;
        }
        
        .security-badges {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-top: 2rem;
            padding-top: 2rem;
            border-top: 2px dashed rgba(102, 126, 234, 0.2);
        }
        
        .security-badge {
            text-align: center;
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .security-badge .icon {
            font-size: 2rem;
            margin-bottom: 0.5rem;
        }
        
        .loading-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.8);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }
        
        .loading-overlay.active {
            display: flex;
        }
        
        .loading-content {
            text-align: center;
            color: white;
        }
        
        .spinner {
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top: 4px solid white;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin: 0 auto 1rem;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            color: white;
            text-decoration: none;
            font-weight: 600;
            margin-bottom: 1.5rem;
            transition: all 0.3s;
        }
        
        .back-link:hover {
            transform: translateX(-5px);
        }
        
        .error-message {
            background: #fee;
            border: 2px solid #fcc;
            border-radius: 12px;
            padding: 1.5rem;
            color: #c33;
            text-align: center;
            margin-bottom: 1.5rem;
        }
        
        .error-message .icon {
            font-size: 3rem;
            margin-bottom: 0.5rem;
        }
    </style>
</head>
<body>
    <div class="checkout-container">
        <a href="javascript:history.back()" class="back-link">
            <span>←</span>
            <span>Back to Note Details</span>
        </a>
        
        <div class="checkout-card">
            <div class="checkout-header">
                <h1>🛒 Secure Checkout</h1>
                <p>Complete your purchase securely with PayPal</p>
            </div>
            
            <div class="checkout-content">
                <div id="checkoutContainer" class="loading-spinner">
                    <div class="spinner"></div>
                    <p>Loading checkout...</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-content">
            <div class="spinner"></div>
            <h2>Processing Payment...</h2>
            <p>Please wait while we complete your transaction</p>
        </div>
    </div>

    <script src="api-helper.js"></script>
    <script>
        const noteId = <?php echo $note_id; ?>;
        const isPayPalConfigured = <?php echo $isConfigured ? 'true' : 'false'; ?>;
        let noteData = null;
        
        async function loadCheckout() {
            const container = document.getElementById('checkoutContainer');
            
            // Get note details
            const result = await NotesAPI.getDetail(noteId);
            
            if (!result.success || !result.data) {
                container.innerHTML = `
                    <div class="error-message">
                        <div class="icon">😢</div>
                        <h2>Note Not Found</h2>
                        <p>The note you're trying to purchase doesn't exist.</p>
                        <button onclick="location.href='browse.php'" class="btn-purchase" style="margin-top: 1rem;">
                            Browse Notes
                        </button>
                    </div>
                `;
                return;
            }
            
            noteData = result.data;
            
            // Check if note is free
            if (noteData.is_free || noteData.price <= 0) {
                container.innerHTML = `
                    <div class="error-message">
                        <div class="icon">💡</div>
                        <h2>This Note is Free!</h2>
                        <p>You don't need to purchase this note. It's available for free.</p>
                        <button onclick="location.href='note-detail.php?id=${noteId}'" class="btn-purchase" style="margin-top: 1rem;">
                            Back to Note
                        </button>
                    </div>
                `;
                return;
            }
            
            // Check if PayPal is configured
            if (!isPayPalConfigured) {
                container.innerHTML = `
                    <div class="error-message">
                        <div class="icon">⚠️</div>
                        <h2>Payment System Not Configured</h2>
                        <p>The payment system is currently being set up. Please try again later or contact support.</p>
                    </div>
                `;
                return;
            }
            
            // Display checkout form
            container.innerHTML = `
                <div class="order-summary">
                    <h2>📋 Order Summary</h2>
                    <div class="note-item">
                        <div class="note-icon">📄</div>
                        <div class="note-details">
                            <h3>${noteData.title}</h3>
                            <p>Category: ${noteData.category} • ${noteData.pages || 0} pages</p>
                            <p>By ${noteData.username}</p>
                        </div>
                        <div class="note-price">$${parseFloat(noteData.price).toFixed(2)}</div>
                    </div>
                    
                    <div class="price-breakdown">
                        <div class="price-row">
                            <span>Note Price</span>
                            <span class="amount">$${parseFloat(noteData.price).toFixed(2)}</span>
                        </div>
                        <div class="price-row">
                            <span>Processing Fee</span>
                            <span class="amount">$0.00</span>
                        </div>
                        <div class="price-row total">
                            <span>Total</span>
                            <span class="amount">$${parseFloat(noteData.price).toFixed(2)}</span>
                        </div>
                    </div>
                </div>
                
                <div class="payment-section">
                    <h2>💳 Payment Method</h2>
                    <p style="color: #6c757d; margin-bottom: 1rem;">
                        Pay securely using your PayPal account or credit/debit card
                    </p>
                    <div id="paypal-button-container"></div>
                    
                    <div class="security-badges">
                        <div class="security-badge">
                            <div class="icon">🔒</div>
                            <div>Secure Payment</div>
                        </div>
                        <div class="security-badge">
                            <div class="icon">✅</div>
                            <div>Instant Access</div>
                        </div>
                        <div class="security-badge">
                            <div class="icon">💯</div>
                            <div>Money Back</div>
                        </div>
                    </div>
                </div>
            `;
            
            // Initialize PayPal buttons
            initializePayPal();
        }
        
        function initializePayPal() {
            paypal.Buttons({
                style: {
                    layout: 'vertical',
                    color: 'blue',
                    shape: 'rect',
                    label: 'paypal',
                    height: 45
                },
                
                createOrder: async function() {
                    try {
                        const response = await fetch('api/payments/create-order.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                note_id: noteId
                            })
                        });
                        
                        // Log the raw response for debugging
                        const responseText = await response.text();
                        console.log('Raw API Response:', responseText);
                        console.log('Response Status:', response.status);
                        
                        let data;
                        try {
                            data = JSON.parse(responseText);
                        } catch (parseError) {
                            console.error('JSON Parse Error:', parseError);
                            console.error('Response was not valid JSON. Received:', responseText.substring(0, 500));
                            alert('❌ Server error. Check console for details.');
                            throw new Error('Invalid JSON response from server');
                        }
                        
                        if (data.success) {
                            return data.order_id;
                        } else {
                            alert('❌ ' + data.message);
                            throw new Error(data.message);
                        }
                    } catch (error) {
                        console.error('Error creating order:', error);
                        if (!error.message.includes('Invalid JSON')) {
                            alert('❌ Failed to create order. Please try again.');
                        }
                        throw error;
                    }
                },
                
                onApprove: async function(data) {
                    // Show loading overlay
                    document.getElementById('loadingOverlay').classList.add('active');
                    
                    try {
                        const response = await fetch('api/payments/capture-order.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                order_id: data.orderID
                            })
                        });
                        
                        const result = await response.json();
                        
                        if (result.success) {
                            // Redirect to success page
                            window.location.href = 'payment-success.php?transaction_id=' + result.transaction_id + '&note_id=' + result.note_id;
                        } else {
                            document.getElementById('loadingOverlay').classList.remove('active');
                            alert('❌ ' + result.message);
                        }
                    } catch (error) {
                        document.getElementById('loadingOverlay').classList.remove('active');
                        console.error('Error capturing payment:', error);
                        alert('❌ Failed to complete payment. Please contact support.');
                    }
                },
                
                onError: function(err) {
                    console.error('PayPal Error:', err);
                    alert('❌ An error occurred with PayPal. Please try again.');
                },
                
                onCancel: function() {
                    alert('Payment cancelled. You can try again when ready.');
                }
            }).render('#paypal-button-container');
        }
        
        // Load checkout on page load
        loadCheckout();
    </script>
</body>
</html>
