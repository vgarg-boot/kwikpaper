/**
 * Admin Dashboard JavaScript
 * Handles all admin functionality including user, notes, and transaction management
 */

let currentPage = 1;
let currentTab = 'overview';
let dashboardStats = null;

// Initialize admin dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is admin
    checkAdminAccess();
    
    // Setup tab navigation
    setupTabs();
    
    // Load initial data
    loadDashboardStats();
    
    // Setup search and filter handlers
    setupSearchHandlers();
});

// Check if user has admin access
async function checkAdminAccess() {
    try {
        const response = await fetch('api/auth/session.php');
        const data = await response.json();
        
        if (!data.logged_in) {
            window.location.href = 'login.php';
            return;
        }
        
        if (data.user.role !== 'admin') {
            alert('Access denied. Admin privileges required.');
            window.location.href = 'index.php';
            return;
        }
        
        // Update user info in nav
        document.getElementById('userName').textContent = data.user.username;
        document.getElementById('userAvatar').textContent = data.user.avatar;
        
    } catch (error) {
        console.error('Error checking admin access:', error);
        window.location.href = 'login.php';
    }
}

// Setup tab navigation
function setupTabs() {
    const tabs = document.querySelectorAll('.admin-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const tabName = this.dataset.tab;
            switchTab(tabName);
        });
    });
}

// Switch between tabs
function switchTab(tabName) {
    // Update tab buttons
    document.querySelectorAll('.admin-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    
    // Update content
    document.querySelectorAll('.admin-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById(tabName).classList.add('active');
    
    currentTab = tabName;
    currentPage = 1;
    
    // Load data for specific tab
    switch(tabName) {
        case 'overview':
            loadDashboardStats();
            break;
        case 'users':
            loadUsers();
            break;
        case 'notes':
            loadNotes();
            break;
        case 'transactions':
            loadTransactions();
            break;
        case 'payouts':
            loadPayouts();
            break;
        case 'settings':
            loadSettings();
            break;
        case 'logs':
            loadActivityLogs();
            break;
    }
}

// Load dashboard statistics
async function loadDashboardStats() {
    try {
        const response = await fetch('api/admin/dashboard-stats.php');
        const data = await response.json();
        
        if (data.success) {
            dashboardStats = data;
            displayStats(data.stats);
            displayRecentTransactions(data.recent_transactions);
        }
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
        showError('Failed to load dashboard statistics');
    }
}

// Display statistics cards
function displayStats(stats) {
    const statsGrid = document.getElementById('statsGrid');
    statsGrid.innerHTML = `
        <div class="stat-card">
            <h3>Total Users</h3>
            <div class="value">${stats.users.total}</div>
            <div class="change">+${stats.users.new_this_month} this month</div>
        </div>
        <div class="stat-card">
            <h3>Total Notes</h3>
            <div class="value">${stats.notes.total}</div>
            <div class="change">${stats.notes.pending} pending approval</div>
        </div>
        <div class="stat-card">
            <h3>Total Transactions</h3>
            <div class="value">${stats.transactions.total}</div>
            <div class="change">${stats.transactions.monthly} this month</div>
        </div>
        <div class="stat-card">
            <h3>Total Revenue</h3>
            <div class="value">$${stats.revenue.total}</div>
            <div class="change">$${stats.revenue.monthly} this month</div>
        </div>
        <div class="stat-card">
            <h3>Platform Fees</h3>
            <div class="value">$${stats.revenue.platform_fees}</div>
            <div class="change">$${stats.revenue.monthly_platform_fees} this month</div>
        </div>
    `;
}

// Display recent transactions
function displayRecentTransactions(transactions) {
    const container = document.getElementById('recentTransactions');
    
    if (!transactions || transactions.length === 0) {
        container.innerHTML = '<div class="empty-state">No recent transactions</div>';
        return;
    }
    
    let html = '<table><thead><tr><th>Transaction ID</th><th>Buyer</th><th>Note</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead><tbody>';
    
    transactions.forEach(t => {
        html += `
            <tr>
                <td>${t.transaction_id.substring(0, 12)}...</td>
                <td>${t.buyer_name}</td>
                <td>${t.note_title}</td>
                <td>$${t.amount}</td>
                <td><span class="status-badge status-${t.status}">${t.status}</span></td>
                <td>${new Date(t.transaction_date).toLocaleDateString()}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// Load users
async function loadUsers() {
    const search = document.getElementById('userSearch').value;
    const role = document.getElementById('userRoleFilter').value;
    const status = document.getElementById('userStatusFilter').value;
    
    try {
        const response = await fetch(`api/admin/users.php?search=${search}&role=${role}&status=${status}&limit=50&offset=${(currentPage - 1) * 50}`);
        const data = await response.json();
        
        if (data.success) {
            displayUsers(data.data);
        }
    } catch (error) {
        console.error('Error loading users:', error);
        showError('Failed to load users');
    }
}

// Display users table
function displayUsers(users) {
    const container = document.getElementById('usersTable');
    
    if (!users || users.length === 0) {
        container.innerHTML = '<div class="empty-state">No users found</div>';
        return;
    }
    
    let html = '<table><thead><tr><th>User</th><th>Email</th><th>University</th><th>Notes</th><th>Earnings</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead><tbody>';
    
    users.forEach(user => {
        html += `
            <tr>
                <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 24px;">${user.avatar}</span>
                        <strong>${user.username}</strong>
                    </div>
                </td>
                <td>${user.email}</td>
                <td>${user.university || 'N/A'}</td>
                <td>${user.notes_uploaded}</td>
                <td>$${parseFloat(user.earnings).toFixed(2)}</td>
                <td><span class="status-badge ${user.role === 'admin' ? 'status-approved' : ''}">${user.role}</span></td>
                <td><span class="status-badge status-${user.active == 1 ? 'active' : 'inactive'}">${user.active == 1 ? 'Active' : 'Inactive'}</span></td>
                <td>${new Date(user.join_date).toLocaleDateString()}</td>
                <td>
                    <button class="action-btn btn-primary" onclick="editUser(${user.id})">Edit</button>
                    ${user.role !== 'admin' ? `<button class="action-btn btn-danger" onclick="deleteUser(${user.id}, '${user.username}')">Delete</button>` : ''}
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// Edit user
function editUser(userId) {
    fetch(`api/admin/users.php?search=&role=all&status=all&limit=1000`)
        .then(response => response.json())
        .then(data => {
            const user = data.data.find(u => u.id === userId);
            if (!user) return;
            
            const modal = document.getElementById('editModal');
            const content = document.getElementById('modalContent');
            
            content.innerHTML = `
                <div class="modal-header">
                    <h2>Edit User: ${user.username}</h2>
                </div>
                <form id="editUserForm">
                    <div class="form-group">
                        <label>Role</label>
                        <select id="userRole" class="form-control">
                            <option value="user" ${user.role === 'user' ? 'selected' : ''}>User</option>
                            <option value="admin" ${user.role === 'admin' ? 'selected' : ''}>Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status</label>
                        <select id="userActive" class="form-control">
                            <option value="1" ${user.active == 1 ? 'selected' : ''}>Active</option>
                            <option value="0" ${user.active == 0 ? 'selected' : ''}>Inactive</option>
                        </select>
                    </div>
                    <div class="form-actions">
                        <button type="button" class="action-btn" onclick="closeModal()">Cancel</button>
                        <button type="submit" class="action-btn btn-primary">Save Changes</button>
                    </div>
                </form>
            `;
            
            document.getElementById('editUserForm').addEventListener('submit', function(e) {
                e.preventDefault();
                updateUser(userId, {
                    role: document.getElementById('userRole').value,
                    active: parseInt(document.getElementById('userActive').value)
                });
            });
            
            modal.classList.add('active');
        });
}

// Update user
async function updateUser(userId, data) {
    try {
        const response = await fetch('api/admin/users.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: userId, ...data })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('User updated successfully');
            closeModal();
            loadUsers();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error updating user:', error);
        showError('Failed to update user');
    }
}

// Delete user
async function deleteUser(userId, username) {
    if (!confirm(`Are you sure you want to delete user "${username}"? This action cannot be undone.`)) {
        return;
    }
    
    try {
        const response = await fetch('api/admin/users.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: userId })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('User deleted successfully');
            loadUsers();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        showError('Failed to delete user');
    }
}

// Load notes
async function loadNotes() {
    const search = document.getElementById('noteSearch').value;
    const category = document.getElementById('noteCategoryFilter').value;
    const status = document.getElementById('noteStatusFilter').value;
    
    try {
        const response = await fetch(`api/admin/notes.php?search=${search}&category=${category}&status=${status}&limit=50&offset=${(currentPage - 1) * 50}`);
        const data = await response.json();
        
        if (data.success) {
            displayNotes(data.data);
        }
    } catch (error) {
        console.error('Error loading notes:', error);
        showError('Failed to load notes');
    }
}

// Display notes table
function displayNotes(notes) {
    const container = document.getElementById('notesTable');
    
    if (!notes || notes.length === 0) {
        container.innerHTML = '<div class="empty-state">No notes found</div>';
        return;
    }
    
    let html = '<table><thead><tr><th>Title</th><th>Author</th><th>Category</th><th>Price</th><th>Downloads</th><th>Rating</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead><tbody>';
    
    notes.forEach(note => {
        html += `
            <tr>
                <td><strong>${note.title}</strong></td>
                <td>${note.username}</td>
                <td>${note.category}</td>
                <td>${note.is_free == 1 ? 'FREE' : '$' + parseFloat(note.price).toFixed(2)}</td>
                <td>${note.downloads}</td>
                <td>⭐ ${parseFloat(note.rating).toFixed(1)} (${note.total_ratings})</td>
                <td><span class="status-badge status-${note.status}">${note.status}</span></td>
                <td>${new Date(note.created_at).toLocaleDateString()}</td>
                <td>
                    <button class="action-btn btn-primary" onclick="viewNoteDetails(${note.id})">View</button>
                    ${note.status === 'pending' ? `
                        <button class="action-btn btn-success" onclick="updateNoteStatus(${note.id}, 'approved')">Approve</button>
                        <button class="action-btn btn-warning" onclick="updateNoteStatus(${note.id}, 'rejected')">Reject</button>
                    ` : ''}
                    <button class="action-btn btn-danger" onclick="deleteNote(${note.id}, '${note.title.replace(/'/g, "\\'")}')">Delete</button>
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// View note details in modal
async function viewNoteDetails(noteId) {
    try {
        // Fetch note details from the API
        const response = await fetch(`api/notes/detail.php?id=${noteId}`);
        const result = await response.json();
        
        if (!result.success) {
            showError(result.message || 'Failed to load note details');
            return;
        }
        
        const note = result.note;
        const modal = document.getElementById('editModal');
        const modalContent = document.getElementById('modalContent');
        
        // Build modal content
        let html = `
            <div class="modal-header">
                <h2>📄 Note Details</h2>
            </div>
            <div class="note-preview">
                <div class="form-group">
                    <label>Title</label>
                    <p style="font-size: 18px; font-weight: bold; margin: 5px 0;">${note.title}</p>
                </div>
                
                <div class="form-group">
                    <label>Author</label>
                    <p style="margin: 5px 0;">${note.username} (${note.email || 'N/A'})</p>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="form-group">
                        <label>Category</label>
                        <p style="margin: 5px 0;">${note.category}</p>
                    </div>
                    
                    <div class="form-group">
                        <label>Price</label>
                        <p style="margin: 5px 0;">${note.is_free == 1 ? '<strong style="color: #28a745;">FREE</strong>' : '<strong>$' + parseFloat(note.price).toFixed(2) + '</strong>'}</p>
                    </div>
                    
                    <div class="form-group">
                        <label>Pages</label>
                        <p style="margin: 5px 0;">${note.pages || 'N/A'}</p>
                    </div>
                    
                    <div class="form-group">
                        <label>Status</label>
                        <p style="margin: 5px 0;"><span class="status-badge status-${note.status}">${note.status}</span></p>
                    </div>
                    
                    <div class="form-group">
                        <label>Downloads</label>
                        <p style="margin: 5px 0;">${note.downloads || 0}</p>
                    </div>
                    
                    <div class="form-group">
                        <label>Rating</label>
                        <p style="margin: 5px 0;">⭐ ${parseFloat(note.rating || 0).toFixed(1)} (${note.total_ratings || 0} reviews)</p>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <p style="margin: 5px 0; line-height: 1.6;">${note.description}</p>
                </div>
                
                <div class="form-group">
                    <label>File</label>
                    <p style="margin: 5px 0;">
                        ${note.file_path ? `
                            <a href="${note.file_path.replace('../../', '')}" download class="action-btn btn-primary" style="display: inline-block; margin-top: 5px;">
                                📥 Download File
                            </a>
                            <span style="display: block; margin-top: 5px; font-size: 12px; color: #666;">
                                File: ${note.file_path.split('/').pop()}
                            </span>
                        ` : 'No file attached'}
                    </p>
                </div>
                
                <div class="form-group">
                    <label>Created At</label>
                    <p style="margin: 5px 0;">${new Date(note.created_at).toLocaleString()}</p>
                </div>
            </div>
            
            <div class="form-actions">
                <button class="action-btn btn-danger" onclick="closeModal()">Close</button>
                ${note.status === 'pending' ? `
                    <button class="action-btn btn-warning" onclick="updateNoteStatusFromModal(${note.id}, 'rejected')">❌ Reject</button>
                    <button class="action-btn btn-success" onclick="updateNoteStatusFromModal(${note.id}, 'approved')">✅ Approve</button>
                ` : ''}
            </div>
        `;
        
        modalContent.innerHTML = html;
        modal.classList.add('active');
    } catch (error) {
        console.error('Error loading note details:', error);
        showError('Failed to load note details');
    }
}

// Update note status from modal and close
async function updateNoteStatusFromModal(noteId, status) {
    await updateNoteStatus(noteId, status);
    closeModal();
}

// Update note status
async function updateNoteStatus(noteId, status) {
    try {
        const response = await fetch('api/admin/notes.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ note_id: noteId, status: status })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess(`Note ${status} successfully`);
            loadNotes();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error updating note:', error);
        showError('Failed to update note');
    }
}

// Delete note
async function deleteNote(noteId, title) {
    if (!confirm(`Are you sure you want to delete note "${title}"? This action cannot be undone.`)) {
        return;
    }
    
    try {
        const response = await fetch('api/admin/notes.php', {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ note_id: noteId })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('Note deleted successfully');
            loadNotes();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error deleting note:', error);
        showError('Failed to delete note');
    }
}

// Load transactions
async function loadTransactions() {
    const search = document.getElementById('transactionSearch').value;
    const status = document.getElementById('transactionStatusFilter').value;
    
    try {
        const response = await fetch(`api/admin/transactions.php?search=${search}&status=${status}&limit=50&offset=${(currentPage - 1) * 50}`);
        const data = await response.json();
        
        if (data.success) {
            displayTransactions(data.data);
        }
    } catch (error) {
        console.error('Error loading transactions:', error);
        showError('Failed to load transactions');
    }
}

// Display transactions table
function displayTransactions(transactions) {
    const container = document.getElementById('transactionsTable');
    
    if (!transactions || transactions.length === 0) {
        container.innerHTML = '<div class="empty-state">No transactions found</div>';
        return;
    }
    
    let html = '<table><thead><tr><th>Transaction ID</th><th>Note</th><th>Buyer</th><th>Seller</th><th>Amount</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead><tbody>';
    
    transactions.forEach(t => {
        html += `
            <tr>
                <td>${t.transaction_id.substring(0, 12)}...</td>
                <td>${t.note_title}</td>
                <td>${t.buyer_name}</td>
                <td>${t.seller_name}</td>
                <td>$${parseFloat(t.amount).toFixed(2)}</td>
                <td><span class="status-badge status-${t.status}">${t.status}</span></td>
                <td>${new Date(t.transaction_date).toLocaleDateString()}</td>
                <td>
                    ${t.status === 'completed' ? `
                        <button class="action-btn btn-warning" onclick="refundTransaction(${t.id})">Refund</button>
                    ` : ''}
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// Refund transaction
function refundTransaction(transactionId) {
    const reason = prompt('Enter refund reason:');
    if (!reason) return;
    
    fetch('api/admin/transactions.php', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
            transaction_id: transactionId, 
            status: 'refunded',
            refund_reason: reason
        })
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showSuccess('Transaction refunded successfully');
            loadTransactions();
        } else {
            showError(result.message);
        }
    })
    .catch(error => {
        console.error('Error refunding transaction:', error);
        showError('Failed to refund transaction');
    });
}

// Export transactions
async function exportTransactions() {
    try {
        const response = await fetch('api/admin/transactions.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ date_from: '', date_to: '' })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Convert to CSV
            let csv = 'Transaction ID,Date,Amount,Currency,Status,Note,Category,Buyer,Seller,Seller Earnings,Platform Fee\n';
            
            data.data.forEach(t => {
                csv += `"${t.transaction_id}","${t.transaction_date}","${t.amount}","${t.currency}","${t.status}","${t.note_title}","${t.category}","${t.buyer}","${t.seller}","${t.seller_earnings}","${t.platform_fee}"\n`;
            });
            
            // Download CSV
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `transactions_${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            showSuccess('Transactions exported successfully');
        }
    } catch (error) {
        console.error('Error exporting transactions:', error);
        showError('Failed to export transactions');
    }
}

// Load settings
async function loadSettings() {
    try {
        const response = await fetch('api/admin/settings.php');
        const data = await response.json();
        
        if (data.success) {
            displaySettings(data.data);
        }
    } catch (error) {
        console.error('Error loading settings:', error);
        showError('Failed to load settings');
    }
}

// Display settings form
function displaySettings(settings) {
    const container = document.getElementById('settingsForm');
    
    let html = '<form id="systemSettingsForm">';
    
    for (const [key, value] of Object.entries(settings)) {
        const displayKey = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        html += `
            <div class="form-group">
                <label>${displayKey}</label>
                <input type="text" id="setting_${key}" value="${value.value}" class="form-control">
                <small style="color: #666;">${value.description}</small>
            </div>
        `;
    }
    
    html += `
        <div class="form-actions">
            <button type="submit" class="action-btn btn-primary">Save Settings</button>
        </div>
    </form>`;
    
    container.innerHTML = html;
    
    document.getElementById('systemSettingsForm').addEventListener('submit', function(e) {
        e.preventDefault();
        saveSettings(settings);
    });
}

// Save settings
async function saveSettings(settings) {
    const updatedSettings = {};
    
    for (const key of Object.keys(settings)) {
        updatedSettings[key] = document.getElementById(`setting_${key}`).value;
    }
    
    try {
        const response = await fetch('api/admin/settings.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ settings: updatedSettings })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess('Settings saved successfully');
            loadSettings();
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error saving settings:', error);
        showError('Failed to save settings');
    }
}

// Load activity logs
async function loadActivityLogs() {
    const action = document.getElementById('logActionFilter').value;
    
    try {
        const response = await fetch(`api/admin/activity-logs.php?action=${action}&limit=100`);
        const data = await response.json();
        
        if (data.success) {
            displayActivityLogs(data.data);
        }
    } catch (error) {
        console.error('Error loading activity logs:', error);
        showError('Failed to load activity logs');
    }
}

// Display activity logs
function displayActivityLogs(logs) {
    const container = document.getElementById('logsTable');
    
    if (!logs || logs.length === 0) {
        container.innerHTML = '<div class="empty-state">No activity logs found</div>';
        return;
    }
    
    let html = '<table><thead><tr><th>Admin</th><th>Action</th><th>Target Type</th><th>Details</th><th>IP Address</th><th>Date</th></tr></thead><tbody>';
    
    logs.forEach(log => {
        html += `
            <tr>
                <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span style="font-size: 20px;">${log.admin_avatar}</span>
                        <strong>${log.admin_username}</strong>
                    </div>
                </td>
                <td>${log.action.replace(/_/g, ' ')}</td>
                <td><span class="status-badge">${log.target_type}</span></td>
                <td>${log.details || 'N/A'}</td>
                <td>${log.ip_address}</td>
                <td>${new Date(log.created_at).toLocaleString()}</td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// Setup search handlers
function setupSearchHandlers() {
    // User search
    let userSearchTimeout;
    document.getElementById('userSearch')?.addEventListener('input', function() {
        clearTimeout(userSearchTimeout);
        userSearchTimeout = setTimeout(() => loadUsers(), 500);
    });
    
    document.getElementById('userRoleFilter')?.addEventListener('change', loadUsers);
    document.getElementById('userStatusFilter')?.addEventListener('change', loadUsers);
    
    // Note search
    let noteSearchTimeout;
    document.getElementById('noteSearch')?.addEventListener('input', function() {
        clearTimeout(noteSearchTimeout);
        noteSearchTimeout = setTimeout(() => loadNotes(), 500);
    });
    
    document.getElementById('noteCategoryFilter')?.addEventListener('change', loadNotes);
    document.getElementById('noteStatusFilter')?.addEventListener('change', loadNotes);
    
    // Transaction search
    let transactionSearchTimeout;
    document.getElementById('transactionSearch')?.addEventListener('input', function() {
        clearTimeout(transactionSearchTimeout);
        transactionSearchTimeout = setTimeout(() => loadTransactions(), 500);
    });
    
    document.getElementById('transactionStatusFilter')?.addEventListener('change', loadTransactions);
    
    // Payout search
    let payoutSearchTimeout;
    document.getElementById('payoutSearch')?.addEventListener('input', function() {
        clearTimeout(payoutSearchTimeout);
        payoutSearchTimeout = setTimeout(() => loadPayouts(), 500);
    });
    
    document.getElementById('payoutStatusFilter')?.addEventListener('change', loadPayouts);
    
    // Log filter
    document.getElementById('logActionFilter')?.addEventListener('change', loadActivityLogs);
}

// Close modal
function closeModal() {
    document.getElementById('editModal').classList.remove('active');
}

// Utility functions
function showSuccess(message) {
    alert('✅ ' + message);
}

function showError(message) {
    alert('❌ ' + message);
}

// Close modal when clicking outside
document.getElementById('editModal')?.addEventListener('click', function(e) {
    if (e.target === this) {
        closeModal();
    }
});

// Logout function
async function logout() {
    try {
        const response = await fetch('api/auth/logout.php');
        const data = await response.json();
        
        if (data.success) {
            alert('✅ Logged out successfully!');
            window.location.href = 'index.php';
        }
    } catch (error) {
        console.error('Logout error:', error);
        alert('✅ Logged out successfully!');
        window.location.href = 'index.php';
    }
}

// ==================== SELLER PAYOUTS FUNCTIONS ====================

// Load seller payouts
async function loadPayouts() {
    const search = document.getElementById('payoutSearch').value;
    const status = document.getElementById('payoutStatusFilter').value;
    
    try {
        const response = await fetch(`api/admin/seller-earnings.php?search=${search}&status=${status}&limit=50&offset=${(currentPage - 1) * 50}`);
        const data = await response.json();
        
        if (data.success) {
            displayPayoutsStats(data.summary);
            displayPayouts(data.data);
        } else {
            showError('Failed to load seller earnings');
        }
    } catch (error) {
        console.error('Error loading payouts:', error);
        showError('Failed to load seller earnings');
    }
}

// Display payouts statistics
function displayPayoutsStats(summary) {
    const statsGrid = document.getElementById('payoutsStatsGrid');
    if (!summary) return;
    
    statsGrid.innerHTML = `
        <div class="stat-card">
            <h3>Total Sellers</h3>
            <div class="value">${summary.total_sellers || 0}</div>
            <div class="change">Active sellers with sales</div>
        </div>
        <div class="stat-card">
            <h3>Total Earnings</h3>
            <div class="value">$${parseFloat(summary.total_earnings || 0).toFixed(2)}</div>
            <div class="change">All time seller earnings</div>
        </div>
        <div class="stat-card">
            <h3>Unpaid Earnings</h3>
            <div class="value" style="color: #dc3545;">$${parseFloat(summary.total_unpaid || 0).toFixed(2)}</div>
            <div class="change">Awaiting payout</div>
        </div>
        <div class="stat-card">
            <h3>Paid Earnings</h3>
            <div class="value" style="color: #28a745;">$${parseFloat(summary.total_paid || 0).toFixed(2)}</div>
            <div class="change">Already paid out</div>
        </div>
    `;
}

// Display payouts table
function displayPayouts(payouts) {
    const container = document.getElementById('payoutsTable');
    
    if (!payouts || payouts.length === 0) {
        container.innerHTML = '<div class="empty-state">No seller earnings found</div>';
        return;
    }
    
    let html = '<table><thead><tr><th>Seller</th><th>Email</th><th>Total Sales</th><th>Notes Sold</th><th>Total Earnings</th><th>Unpaid</th><th>Paid</th><th>First Sale</th><th>Last Sale</th><th>Actions</th></tr></thead><tbody>';
    
    payouts.forEach(payout => {
        const unpaid = parseFloat(payout.unpaid_earnings || 0);
        const paid = parseFloat(payout.paid_earnings || 0);
        const total = parseFloat(payout.total_earnings || 0);
        
        html += `
            <tr>
                <td><strong>${payout.seller_name}</strong></td>
                <td>${payout.seller_email}</td>
                <td>${payout.total_sales}</td>
                <td>${payout.notes_sold}</td>
                <td>$${total.toFixed(2)}</td>
                <td style="color: ${unpaid > 0 ? '#dc3545' : '#666'}; font-weight: ${unpaid > 0 ? 'bold' : 'normal'};">
                    $${unpaid.toFixed(2)}
                </td>
                <td style="color: #28a745;">$${paid.toFixed(2)}</td>
                <td>${payout.first_sale_date ? new Date(payout.first_sale_date).toLocaleDateString() : 'N/A'}</td>
                <td>${payout.last_sale_date ? new Date(payout.last_sale_date).toLocaleDateString() : 'N/A'}</td>
                <td>
                    <button class="action-btn btn-primary" onclick="viewSellerDetails(${payout.seller_id})">View Details</button>
                    ${unpaid > 0 ? `
                        <button class="action-btn btn-success" onclick="markAsPaid(${payout.seller_id}, '${payout.seller_name}', ${unpaid})">Mark as Paid</button>
                    ` : ''}
                </td>
            </tr>
        `;
    });
    
    html += '</tbody></table>';
    container.innerHTML = html;
}

// View seller transaction details
async function viewSellerDetails(sellerId) {
    try {
        // Fetch seller's transactions
        const response = await fetch(`api/admin/transactions.php?seller_id=${sellerId}&limit=100`);
        const data = await response.json();
        
        if (!data.success) {
            showError('Failed to load seller details');
            return;
        }
        
        const transactions = data.data;
        const sellerName = transactions.length > 0 ? transactions[0].seller_name : 'Seller';
        
        let modalHtml = `
            <div class="modal-header">
                <h2>Transaction Details - ${sellerName}</h2>
            </div>
            <div style="max-height: 500px; overflow-y: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>Note</th>
                            <th>Buyer</th>
                            <th>Amount</th>
                            <th>Earnings</th>
                            <th>Platform Fee</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Payout Status</th>
                        </tr>
                    </thead>
                    <tbody>
        `;
        
        transactions.forEach(t => {
            modalHtml += `
                <tr>
                    <td>${t.transaction_id.substring(0, 12)}...</td>
                    <td>${t.note_title}</td>
                    <td>${t.buyer_name}</td>
                    <td>$${parseFloat(t.amount).toFixed(2)}</td>
                    <td>$${parseFloat(t.seller_earnings || 0).toFixed(2)}</td>
                    <td>$${parseFloat(t.platform_fee || 0).toFixed(2)}</td>
                    <td>${new Date(t.transaction_date).toLocaleDateString()}</td>
                    <td><span class="status-badge status-${t.status}">${t.status}</span></td>
                    <td><span class="status-badge status-${t.payout_status || 'unpaid'}">${t.payout_status || 'unpaid'}</span></td>
                </tr>
            `;
        });
        
        modalHtml += `
                    </tbody>
                </table>
            </div>
            <div class="form-actions">
                <button class="action-btn btn-primary" onclick="closeModal()">Close</button>
            </div>
        `;
        
        document.getElementById('modalContent').innerHTML = modalHtml;
        document.getElementById('editModal').classList.add('active');
        
    } catch (error) {
        console.error('Error loading seller details:', error);
        showError('Failed to load seller details');
    }
}

// Mark seller earnings as paid
function markAsPaid(sellerId, sellerName, amount) {
    const payoutMethod = prompt(`Mark $${amount.toFixed(2)} as paid to ${sellerName}?\n\nEnter payout method (e.g., PayPal, Bank Transfer, Check):`, 'PayPal');
    
    if (!payoutMethod) return; // User cancelled
    
    const payoutReference = prompt('Enter payout reference/transaction ID (optional):', '');
    const notes = prompt('Additional notes (optional):', '');
    
    if (!confirm(`Confirm payment of $${amount.toFixed(2)} to ${sellerName} via ${payoutMethod}?`)) {
        return;
    }
    
    markAsPayoutPaid(sellerId, payoutMethod, payoutReference, notes);
}

// API call to mark payout as paid
async function markAsPayoutPaid(sellerId, payoutMethod, payoutReference, notes) {
    try {
        const response = await fetch('api/admin/seller-earnings.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                seller_id: sellerId,
                payout_method: payoutMethod,
                payout_reference: payoutReference,
                notes: notes
            })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showSuccess(`Payout marked as paid! ${result.transactions_updated} transactions updated. Total: $${result.total_paid}`);
            loadPayouts(); // Reload the table
        } else {
            showError(result.message);
        }
    } catch (error) {
        console.error('Error marking payout as paid:', error);
        showError('Failed to mark payout as paid');
    }
}

// Export payouts to CSV
async function exportPayouts() {
    const search = document.getElementById('payoutSearch').value;
    const status = document.getElementById('payoutStatusFilter').value;
    
    try {
        const response = await fetch(`api/admin/seller-earnings.php?search=${search}&status=${status}&limit=10000`);
        const data = await response.json();
        
        if (!data.success) {
            showError('Failed to export payouts');
            return;
        }
        
        const payouts = data.data;
        
        // Create CSV content
        let csv = 'Seller Name,Email,Total Sales,Notes Sold,Total Earnings,Unpaid Earnings,Paid Earnings,First Sale,Last Sale\n';
        
        payouts.forEach(payout => {
            csv += `"${payout.seller_name}","${payout.seller_email}",${payout.total_sales},${payout.notes_sold},`;
            csv += `${parseFloat(payout.total_earnings || 0).toFixed(2)},`;
            csv += `${parseFloat(payout.unpaid_earnings || 0).toFixed(2)},`;
            csv += `${parseFloat(payout.paid_earnings || 0).toFixed(2)},`;
            csv += `"${payout.first_sale_date || 'N/A'}","${payout.last_sale_date || 'N/A'}"\n`;
        });
        
        // Download CSV
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `seller-payouts-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
        
        showSuccess('Payouts exported successfully!');
        
    } catch (error) {
        console.error('Error exporting payouts:', error);
        showError('Failed to export payouts');
    }
}
