<?php
/**
 * Note Model
 * Handles all note-related database operations
 */

class Note {
    private $conn;
    private $table_name = "notes";

    public $id;
    public $user_id;
    public $title;
    public $description;
    public $category;
    public $price;
    public $is_free;
    public $file_path;
    public $file_size;
    public $pages;
    public $downloads;
    public $views;
    public $rating;
    public $total_ratings;
    public $status;
    public $created_at;
    public $updated_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Create new note
     */
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  (user_id, title, description, category, price, is_free, file_path, 
                   file_size, pages, status) 
                  VALUES (:user_id, :title, :description, :category, :price, :is_free,
                          :file_path, :file_size, :pages, :status)";

        $stmt = $this->conn->prepare($query);

        // Sanitize
        $this->title = htmlspecialchars(strip_tags($this->title));
        $this->description = htmlspecialchars(strip_tags($this->description));
        $this->category = htmlspecialchars(strip_tags($this->category));

        // Bind values
        $stmt->bindParam(":user_id", $this->user_id);
        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":category", $this->category);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":is_free", $this->is_free);
        $stmt->bindParam(":file_path", $this->file_path);
        $stmt->bindParam(":file_size", $this->file_size);
        $stmt->bindParam(":pages", $this->pages);
        $stmt->bindParam(":status", $this->status);

        if($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            
            // Update user's notes_uploaded count
            $this->updateUserNotesCount();
            
            return true;
        }
        return false;
    }

    /**
     * Get all notes with pagination and filtering
     */
    public function getAll($page = 1, $limit = 12, $category = 'all', $search = '') {
        try {
            $offset = ($page - 1) * $limit;
            
            // Clean and trim search
            $search = trim($search);
            
            error_log("Note Model getAll - Search: '" . $search . "' (length: " . strlen($search) . ")");
            error_log("Note Model getAll - Category: " . $category);
            
            $query = "SELECT n.*, u.username, u.avatar,
                      (SELECT COUNT(*) FROM purchases p 
                       WHERE p.note_id = n.id) as purchased_count
                      FROM " . $this->table_name . " n 
                      LEFT JOIN users u ON n.user_id = u.id 
                      WHERE n.status = 'approved'";

            if($category !== 'all') {
                $query .= " AND n.category = :category";
            }

            if($search !== '') {
                $query .= " AND (n.title LIKE :search1 OR n.description LIKE :search2 OR n.category LIKE :search3 OR u.university LIKE :search4)";
            }

            $query .= " ORDER BY n.created_at DESC LIMIT :limit OFFSET :offset";
            
            error_log("Note Model getAll - Final query: " . $query);

            $stmt = $this->conn->prepare($query);

            if($category !== 'all') {
                $stmt->bindParam(":category", $category);
            }

            if($search !== '') {
                $search_param = "%{$search}%";
                error_log("Note Model getAll - Search param: '" . $search_param . "'");
                $stmt->bindParam(":search1", $search_param);
                $stmt->bindParam(":search2", $search_param);
                $stmt->bindParam(":search3", $search_param);
                $stmt->bindParam(":search4", $search_param);
            }

            $stmt->bindParam(":limit", $limit, PDO::PARAM_INT);
            $stmt->bindParam(":offset", $offset, PDO::PARAM_INT);

            $stmt->execute();
            $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            error_log("Note Model getAll - Results count: " . count($results));
            
            return $results;
        } catch (Exception $e) {
            error_log("Note Model getAll - Error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get total count for pagination
     */
    public function getTotalCount($category = 'all', $search = '') {
        try {
            // Clean and trim search
            $search = trim($search);
            
            $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " n
                      LEFT JOIN users u ON n.user_id = u.id
                      WHERE n.status = 'approved'";

            if($category !== 'all') {
                $query .= " AND n.category = :category";
            }

            if($search !== '') {
                $query .= " AND (n.title LIKE :search1 OR n.description LIKE :search2 OR n.category LIKE :search3 OR u.university LIKE :search4)";
            }

            $stmt = $this->conn->prepare($query);

            if($category !== 'all') {
                $stmt->bindParam(":category", $category);
            }

            if($search !== '') {
                $search_param = "%{$search}%";
                $stmt->bindParam(":search1", $search_param);
                $stmt->bindParam(":search2", $search_param);
                $stmt->bindParam(":search3", $search_param);
                $stmt->bindParam(":search4", $search_param);
            }

            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row['total'];
        } catch (Exception $e) {
            error_log("Note Model getTotalCount - Error: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Get note by ID
     */
    public function getById($note_id) {
        $query = "SELECT n.*, u.username, u.avatar, u.university, u.subject,
                  (SELECT COUNT(*) FROM purchases p 
                   WHERE p.note_id = n.id) as purchased_count
                  FROM " . $this->table_name . " n 
                  LEFT JOIN users u ON n.user_id = u.id 
                  WHERE n.id = :id AND n.status = 'approved' 
                  LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $note_id);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            // Increment view count
            $this->incrementViews($note_id);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    /**
     * Get notes by user ID
     */
    public function getByUserId($user_id) {
        $query = "SELECT n.*,
                  (SELECT COUNT(*) FROM purchases p 
                   WHERE p.note_id = n.id) as purchased_count
                  FROM " . $this->table_name . " n
                  WHERE n.user_id = :user_id 
                  ORDER BY n.created_at DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Increment view count
     */
    private function incrementViews($note_id) {
        $query = "UPDATE " . $this->table_name . " 
                  SET views = views + 1 
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $note_id);
        $stmt->execute();
    }

    /**
     * Update note
     */
    public function update() {
        $query = "UPDATE " . $this->table_name . " 
                  SET title = :title, description = :description, 
                      category = :category, price = :price, pages = :pages 
                  WHERE id = :id AND user_id = :user_id";

        $stmt = $this->conn->prepare($query);

        // Sanitize
        $this->title = htmlspecialchars(strip_tags($this->title));
        $this->description = htmlspecialchars(strip_tags($this->description));
        $this->category = htmlspecialchars(strip_tags($this->category));

        // Bind values
        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":category", $this->category);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":pages", $this->pages);
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":user_id", $this->user_id);

        return $stmt->execute();
    }

    /**
     * Delete note
     */
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " 
                  WHERE id = :id AND user_id = :user_id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":user_id", $this->user_id);

        return $stmt->execute();
    }

    /**
     * Update user's notes uploaded count
     */
    private function updateUserNotesCount() {
        $query = "UPDATE users 
                  SET notes_uploaded = notes_uploaded + 1 
                  WHERE id = :user_id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $this->user_id);
        $stmt->execute();
    }

    /**
     * Get popular/featured notes (based on total purchases - both free and paid)
     */
    public function getFeatured($limit = 10) {
        $query = "SELECT n.*, u.username, u.avatar,
                  (SELECT COUNT(*) FROM purchases p 
                   WHERE p.note_id = n.id) as purchased_count
                  FROM " . $this->table_name . " n 
                  LEFT JOIN users u ON n.user_id = u.id 
                  WHERE n.status = 'approved' 
                  AND (SELECT COUNT(*) FROM purchases p 
                       WHERE p.note_id = n.id) > 0
                  ORDER BY purchased_count DESC, n.rating DESC 
                  LIMIT :limit";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":limit", $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get latest notes uploaded in the last week
     */
    public function getLatest($limit = 10) {
        $query = "SELECT n.*, u.username, u.avatar,
                  (SELECT COUNT(*) FROM purchases p 
                   WHERE p.note_id = n.id) as purchased_count
                  FROM " . $this->table_name . " n 
                  LEFT JOIN users u ON n.user_id = u.id 
                  WHERE n.status = 'approved' 
                  AND n.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                  ORDER BY n.created_at DESC 
                  LIMIT :limit";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":limit", $limit, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
