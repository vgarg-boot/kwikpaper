<?php
/**
 * User Model
 * Handles all user-related database operations
 */

class User {
    private $conn;
    private $table_name = "users";

    public $id;
    public $username;
    public $email;
    public $password;
    public $avatar;
    public $bio;
    public $university;
    public $year;
    public $subject;
    public $notes_uploaded;
    public $notes_purchased;
    public $earnings;
    public $join_date;
    public $last_login;
    public $active;

    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Register new user
     */
    public function register() {
        $query = "INSERT INTO " . $this->table_name . " 
                  (username, email, password, avatar) 
                  VALUES (:username, :email, :password, :avatar)";

        $stmt = $this->conn->prepare($query);

        // Sanitize
        $this->username = htmlspecialchars(strip_tags($this->username));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->password = password_hash($this->password, PASSWORD_BCRYPT);
        $this->avatar = '👤';

        // Bind values
        $stmt->bindParam(":username", $this->username);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":password", $this->password);
        $stmt->bindParam(":avatar", $this->avatar);

        if($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    /**
     * Login user
     */
    public function login() {
        $query = "SELECT id, username, email, password, avatar, bio, university, 
                         year, subject, notes_uploaded, notes_purchased, earnings, 
                         join_date, active, role 
                  FROM " . $this->table_name . " 
                  WHERE email = :email AND active = 1 
                  LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":email", $this->email);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if(password_verify($this->password, $row['password'])) {
                $this->id = $row['id'];
                $this->username = $row['username'];
                $this->email = $row['email'];
                $this->avatar = $row['avatar'];
                $this->bio = $row['bio'];
                $this->university = $row['university'];
                $this->year = $row['year'];
                $this->subject = $row['subject'];
                $this->notes_uploaded = $row['notes_uploaded'];
                $this->notes_purchased = $row['notes_purchased'];
                $this->earnings = $row['earnings'];
                $this->join_date = $row['join_date'];
                $this->role = $row['role'] ?? 'user';
                
                // Update last login
                $this->updateLastLogin();
                
                return true;
            }
        }
        return false;
    }

    /**
     * Check if username exists
     */
    public function usernameExists() {
        $query = "SELECT id FROM " . $this->table_name . " 
                  WHERE username = :username LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $this->username);
        $stmt->execute();

        return $stmt->rowCount() > 0;
    }

    /**
     * Check if email exists
     */
    public function emailExists() {
        $query = "SELECT id FROM " . $this->table_name . " 
                  WHERE email = :email LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":email", $this->email);
        $stmt->execute();

        return $stmt->rowCount() > 0;
    }

    /**
     * Get user by ID
     */
    public function getUserById($user_id) {
        $query = "SELECT id, username, email, avatar, bio, university, year, 
                         subject, notes_uploaded, notes_purchased, earnings, join_date, role 
                  FROM " . $this->table_name . " 
                  WHERE id = :id AND active = 1 LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $user_id);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    /**
     * Update user profile
     */
    public function updateProfile() {
        $query = "UPDATE " . $this->table_name . " 
                  SET email = :email, avatar = :avatar, bio = :bio, 
                      university = :university, year = :year, subject = :subject 
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        // Sanitize
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->avatar = htmlspecialchars(strip_tags($this->avatar));
        $this->bio = htmlspecialchars(strip_tags($this->bio));
        $this->university = htmlspecialchars(strip_tags($this->university));
        $this->year = htmlspecialchars(strip_tags($this->year));
        $this->subject = htmlspecialchars(strip_tags($this->subject));

        // Bind values
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":avatar", $this->avatar);
        $stmt->bindParam(":bio", $this->bio);
        $stmt->bindParam(":university", $this->university);
        $stmt->bindParam(":year", $this->year);
        $stmt->bindParam(":subject", $this->subject);
        $stmt->bindParam(":id", $this->id);

        return $stmt->execute();
    }

    /**
     * Update last login timestamp
     */
    private function updateLastLogin() {
        $query = "UPDATE " . $this->table_name . " 
                  SET last_login = NOW() 
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        $stmt->execute();
    }

    /**
     * Get user statistics
     */
    public function getUserStats($user_id) {
        $query = "SELECT notes_uploaded, notes_purchased, earnings 
                  FROM " . $this->table_name . " 
                  WHERE id = :id LIMIT 1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $user_id);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    /**
     * Generate email verification token
     */
    public function generateVerificationToken() {
        // Generate random token
        $token = bin2hex(random_bytes(32));
        
        // Calculate expiry time
        $expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
        
        $query = "UPDATE " . $this->table_name . " 
                  SET verification_token = :token, 
                      verification_token_expires = :expiry,
                      verification_sent_at = CURRENT_TIMESTAMP
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":token", $token);
        $stmt->bindParam(":expiry", $expiry);
        $stmt->bindParam(":id", $this->id);
        
        if($stmt->execute()) {
            return $token;
        }
        return false;
    }

    /**
     * Verify email with token
     */
    public function verifyEmail($token) {
        $query = "SELECT id, username, email, verification_token_expires 
                  FROM " . $this->table_name . " 
                  WHERE verification_token = :token 
                  AND email_verified = 0 
                  AND active = 1 
                  LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":token", $token);
        $stmt->execute();
        
        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Check if token has expired
            if(strtotime($row['verification_token_expires']) < time()) {
                return ['success' => false, 'message' => 'Verification link has expired'];
            }
            
            // Mark email as verified
            $update_query = "UPDATE " . $this->table_name . " 
                           SET email_verified = 1, 
                               verification_token = NULL,
                               verification_token_expires = NULL
                           WHERE id = :id";
            
            $update_stmt = $this->conn->prepare($update_query);
            $update_stmt->bindParam(":id", $row['id']);
            
            if($update_stmt->execute()) {
                $this->id = $row['id'];
                $this->username = $row['username'];
                $this->email = $row['email'];
                return ['success' => true, 'message' => 'Email verified successfully'];
            }
        }
        
        return ['success' => false, 'message' => 'Invalid or expired verification link'];
    }

    /**
     * Check if email is verified
     */
    public function isEmailVerified() {
        $query = "SELECT email_verified FROM " . $this->table_name . " 
                  WHERE id = :id LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        $stmt->execute();
        
        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row['email_verified'] == 1;
        }
        return false;
    }

    /**
     * Resend verification email
     */
    public function canResendVerification() {
        $query = "SELECT verification_sent_at FROM " . $this->table_name . " 
                  WHERE id = :id AND email_verified = 0 LIMIT 1";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        $stmt->execute();
        
        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Allow resend if last email was sent more than 5 minutes ago
            if($row['verification_sent_at']) {
                $last_sent = strtotime($row['verification_sent_at']);
                $current_time = time();
                return ($current_time - $last_sent) > 300; // 5 minutes
            }
            return true;
        }
        return false;
    }
}
?>
