<?php
/**
 * Create/Upload Note API Endpoint
 * POST: api/notes/create.php
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../models/Note.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Debug: Check if we have any POST data at all
error_log("=== CREATE.PHP REQUEST DEBUG ===");
error_log("Request Method: " . $_SERVER['REQUEST_METHOD']);
error_log("Content-Type: " . (isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : 'NOT SET'));
error_log("POST data count: " . count($_POST));
error_log("FILES data count: " . count($_FILES));
error_log("Raw POST keys: " . implode(', ', array_keys($_POST)));
error_log("Raw POST data: " . json_encode($_POST));
error_log("PHP Input: " . file_get_contents('php://input'));
error_log("Session active: " . (isset($_SESSION) ? 'yes' : 'no'));
error_log("User ID in session: " . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 'NOT SET'));
error_log("================================");

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Authentication required. Please login."
    ]);
    exit();
}

$database = new Database();
$db = $database->getConnection();
$note = new Note($db);

// Debug: Log received POST data
error_log("Received POST data: " . print_r($_POST, true));
error_log("Received FILES data: " . print_r($_FILES, true));

// Handle file upload
$upload_dir = "../../uploads/notes/";
if(!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

$file_path = null;
$file_size = null;

if(isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
    $allowed_extensions = ['pdf', 'doc', 'docx', 'txt'];
    $file_extension = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
    
    if(!in_array($file_extension, $allowed_extensions)) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "Invalid file type. Only PDF, DOC, DOCX, and TXT files are allowed."
        ]);
        exit();
    }
    
    // Generate unique filename
    $file_name = uniqid() . '_' . basename($_FILES['file']['name']);
    $file_path = $upload_dir . $file_name;
    $file_size = $_FILES['file']['size'];
    
    if(!move_uploaded_file($_FILES['file']['tmp_name'], $file_path)) {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Failed to upload file"
        ]);
        exit();
    }
}

// Get form data
$title = isset($_POST['title']) ? trim($_POST['title']) : '';
$description = isset($_POST['description']) ? trim($_POST['description']) : '';
$category = isset($_POST['category']) ? trim($_POST['category']) : '';
$is_free = isset($_POST['is_free']) && $_POST['is_free'] == '1' ? 1 : 0;
$price = $is_free ? 0 : (isset($_POST['price']) && $_POST['price'] !== '' ? (float)$_POST['price'] : null);
$pages = isset($_POST['pages']) && $_POST['pages'] !== '' ? (int)$_POST['pages'] : 0;

// Debug log - check what we received
error_log("=== UPLOAD DEBUG ===");
error_log("Raw POST: " . json_encode($_POST));
error_log("Title: '" . $title . "' (length: " . strlen($title) . ")");
error_log("Category: '" . $category . "'");
error_log("Description length: " . strlen($description));
error_log("Is Free: " . ($is_free ? "YES" : "NO"));
error_log("Price: " . ($price === null ? "NULL" : $price));
error_log("===================");

// Validate required fields
if(empty($title)) {
    error_log("ERROR: Title is empty after trim. Raw value: '" . (isset($_POST['title']) ? $_POST['title'] : 'NOT SET') . "'");
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Title is required. Received: " . (isset($_POST['title']) ? "'{$_POST['title']}'" : "nothing")
    ]);
    exit();
}

if(empty($description)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Description is required"
    ]);
    exit();
}

if(empty($category)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Category is required. Please select a category from the dropdown."
    ]);
    exit();
}

if(!$is_free && ($price === null || $price < 0)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Valid price is required for paid notes (must be greater than 0). Current value: " . ($price === null ? 'not set' : $price)
    ]);
    exit();
}

// Set note properties
$note->user_id = $_SESSION['user_id'];
$note->title = $title;
$note->description = $description;
$note->category = $category;
$note->price = $price;
$note->is_free = $is_free;
$note->file_path = $file_path;
$note->file_size = $file_size;
$note->pages = $pages;

// Check if admin approval is required
$setting_query = "SELECT setting_value FROM system_settings WHERE setting_key = 'require_note_approval'";
$setting_stmt = $db->prepare($setting_query);
$setting_stmt->execute();
$require_approval = $setting_stmt->fetchColumn();

// Set status based on admin setting
$note->status = ($require_approval == '1') ? 'pending' : 'approved';

// Create note
if($note->create()) {
    http_response_code(201);
    echo json_encode([
        "success" => true,
        "message" => "Note uploaded successfully",
        "note_id" => $note->id
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Unable to upload note"
    ]);
}
?>
