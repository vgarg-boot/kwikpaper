<?php
/**
 * List/Browse Notes API Endpoint
 * GET: api/notes/list.php?page=1&limit=12&category=all&search=
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

try {
    include_once '../config/database.php';
    include_once '../models/Note.php';

    $database = new Database();
    $db = $database->getConnection();

    if($db === null) {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Database connection failed"
        ]);
        exit();
    }

    $note = new Note($db);

    // Get query parameters
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 12;
    $category = isset($_GET['category']) ? $_GET['category'] : 'all';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';

    // Debug logging
    error_log("Notes List API - Search parameter: '" . $search . "'");
    error_log("Notes List API - Category: " . $category);
    error_log("Notes List API - Page: " . $page);

    // Get notes
    $notes = $note->getAll($page, $limit, $category, $search);
    $total = $note->getTotalCount($category, $search);
    $total_pages = ceil($total / $limit);

    http_response_code(200);
    echo json_encode([
        "success" => true,
        "data" => $notes,
        "pagination" => [
            "current_page" => $page,
            "total_pages" => $total_pages,
            "total_records" => $total,
            "limit" => $limit
        ]
    ]);
    
} catch (Exception $e) {
    error_log("Notes List API Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "An error occurred: " . $e->getMessage()
    ]);
}
?>
