<?php
/**
 * Add Note to Library API Endpoint
 * Adds a note (free or paid) to user's library without downloading
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Please login to add notes to your library"
    ]);
    exit();
}

// Get note ID from query parameter
if(!isset($_GET['id']) || empty($_GET['id'])) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Note ID is required"
    ]);
    exit();
}

$note_id = (int)$_GET['id'];
$user_id = $_SESSION['user_id'];

$database = new Database();
$db = $database->getConnection();

// Get note details
$query = "SELECT n.*, u.username, u.avatar 
          FROM notes n 
          LEFT JOIN users u ON n.user_id = u.id 
          WHERE n.id = :note_id";

$stmt = $db->prepare($query);
$stmt->bindParam(':note_id', $note_id);
$stmt->execute();

$note = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$note) {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "Note not found"
    ]);
    exit();
}

// Check if user is the owner
if($note['user_id'] == $user_id) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "You cannot add your own notes to library. They are already in 'My Uploads'."
    ]);
    exit();
}

// Check if note is free
$is_free = ($note['is_free'] == 1 || !$note['price'] || floatval($note['price']) === 0.0);

if(!$is_free) {
    http_response_code(403);
    echo json_encode([
        "success" => false,
        "message" => "This is a paid note. Please purchase it first."
    ]);
    exit();
}

// Check if already in library
$check_query = "SELECT id FROM purchases WHERE user_id = :user_id AND note_id = :note_id";
$check_stmt = $db->prepare($check_query);
$check_stmt->bindParam(':user_id', $user_id);
$check_stmt->bindParam(':note_id', $note_id);
$check_stmt->execute();

if($check_stmt->rowCount() > 0) {
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => "This note is already in your library!",
        "already_exists" => true
    ]);
    exit();
}

// Add to library (purchases table with amount = 0)
$insert_query = "INSERT INTO purchases (user_id, note_id, amount, purchase_date) 
                 VALUES (:user_id, :note_id, 0, NOW())";
$insert_stmt = $db->prepare($insert_query);
$insert_stmt->bindParam(':user_id', $user_id);
$insert_stmt->bindParam(':note_id', $note_id);

if($insert_stmt->execute()) {
    // Increment both downloads and views count
    $update_query = "UPDATE notes SET downloads = downloads + 1, views = views + 1 WHERE id = :note_id";
    $update_stmt = $db->prepare($update_query);
    $update_stmt->bindParam(':note_id', $note_id);
    $update_stmt->execute();
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => "Note successfully added to your library!"
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Failed to add note to library. Please try again."
    ]);
}
?>
