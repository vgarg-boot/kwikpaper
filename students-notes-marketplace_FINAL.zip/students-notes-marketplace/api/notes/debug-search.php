<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");

include_once '../config/database.php';

// Test search term (change this to test different searches)
$test_search = isset($_GET['search']) ? trim($_GET['search']) : 'PDF';

try {
    $database = new Database();
    $db = $database->getConnection();
    
    // Check total approved notes
    $query = "SELECT COUNT(*) as total FROM notes WHERE status = 'approved'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $total_notes = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Get some sample notes to see what we're searching
    $query = "SELECT id, title, description, category, status 
              FROM notes 
              LIMIT 10";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $sample_notes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Test the search query
    $search_query = "SELECT n.id, n.title, n.description, n.category, u.university
                     FROM notes n
                     LEFT JOIN users u ON n.user_id = u.id
                     WHERE n.status = 'approved'
                     AND (n.title LIKE :search1 OR n.description LIKE :search2 OR n.category LIKE :search3 OR u.university LIKE :search4)
                     LIMIT 10";
    
    $stmt = $db->prepare($search_query);
    $search_param = "%{$test_search}%";
    $stmt->bindParam(":search1", $search_param);
    $stmt->bindParam(":search2", $search_param);
    $stmt->bindParam(":search3", $search_param);
    $stmt->bindParam(":search4", $search_param);
    $stmt->execute();
    $search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'debug_info' => [
            'search_term' => $test_search,
            'search_param' => $search_param,
            'total_approved_notes' => $total_notes,
            'sample_notes_count' => count($sample_notes),
            'sample_notes' => $sample_notes,
            'search_results_count' => count($search_results),
            'search_results' => $search_results,
            'query' => $search_query
        ]
    ], JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
