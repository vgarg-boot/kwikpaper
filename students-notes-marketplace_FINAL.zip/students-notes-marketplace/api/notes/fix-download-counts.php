<?php
/**
 * One-time script to fix download counts based on existing purchases
 * Run this once to update all download counts
 */

include_once '../config/database.php';

header("Content-Type: application/json; charset=UTF-8");

try {
    $database = new Database();
    $db = $database->getConnection();
    
    if($db === null) {
        throw new Exception("Database connection failed");
    }
    
    // Get the correct download count for each note based on purchases table
    $query = "SELECT note_id, COUNT(*) as actual_downloads 
              FROM purchases 
              GROUP BY note_id";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $purchase_counts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $updated_count = 0;
    $errors = [];
    
    // Update each note's download count
    foreach ($purchase_counts as $row) {
        $note_id = $row['note_id'];
        $actual_downloads = $row['actual_downloads'];
        
        $update_query = "UPDATE notes SET downloads = :downloads WHERE id = :note_id";
        $update_stmt = $db->prepare($update_query);
        $update_stmt->bindParam(':downloads', $actual_downloads, PDO::PARAM_INT);
        $update_stmt->bindParam(':note_id', $note_id, PDO::PARAM_INT);
        
        if($update_stmt->execute()) {
            $updated_count++;
        } else {
            $errors[] = "Failed to update note ID: " . $note_id;
        }
    }
    
    // Get notes that have no purchases (set downloads to 0)
    $zero_query = "UPDATE notes 
                   SET downloads = 0 
                   WHERE id NOT IN (SELECT DISTINCT note_id FROM purchases)";
    $zero_stmt = $db->prepare($zero_query);
    $zero_stmt->execute();
    $zeroed_count = $zero_stmt->rowCount();
    
    echo json_encode([
        'success' => true,
        'message' => 'Download counts updated successfully!',
        'stats' => [
            'notes_with_downloads_updated' => $updated_count,
            'notes_set_to_zero' => $zeroed_count,
            'total_processed' => $updated_count + $zeroed_count,
            'errors' => $errors
        ]
    ], JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Error: ' . $e->getMessage()
    ]);
}
?>
