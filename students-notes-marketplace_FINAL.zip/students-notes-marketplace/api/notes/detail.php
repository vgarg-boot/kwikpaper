<?php
/**
 * Get Note Details API Endpoint
 * GET: api/notes/detail.php?id=1
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../models/Note.php';

// Start session to check if user is admin
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$database = new Database();
$db = $database->getConnection();
$note = new Note($db);

// Get note ID from query parameter
if(!isset($_GET['id']) || empty($_GET['id'])) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Note ID is required"
    ]);
    exit();
}

$note_id = (int)$_GET['id'];

// Check if user is admin - admins can view all notes including pending
$isAdmin = isset($_SESSION['role']) && $_SESSION['role'] === 'admin';

if ($isAdmin) {
    // Admin query - no status filter, include email
    $query = "SELECT n.*, u.username, u.email, u.avatar, u.university, u.subject,
              (SELECT COUNT(*) FROM purchases p 
               WHERE p.note_id = n.id) as purchased_count
              FROM notes n 
              LEFT JOIN users u ON n.user_id = u.id 
              WHERE n.id = :id 
              LIMIT 1";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(":id", $note_id);
    $stmt->execute();
    
    if($stmt->rowCount() > 0) {
        $noteData = $stmt->fetch(PDO::FETCH_ASSOC);
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "note" => $noteData
        ]);
    } else {
        http_response_code(404);
        echo json_encode([
            "success" => false,
            "message" => "Note not found"
        ]);
    }
} else {
    // Regular user query - only approved notes
    $noteData = $note->getById($note_id);

    if($noteData) {
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "note" => $noteData
        ]);
    } else {
        http_response_code(404);
        echo json_encode([
            "success" => false,
            "message" => "Note not found"
        ]);
    }
}
?>
