<?php
/**
 * Check Note Access API Endpoint
 * Returns whether user has access to view full note
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

// Get note ID from query parameter
if(!isset($_GET['id']) || empty($_GET['id'])) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Note ID is required",
        "has_access" => false
    ]);
    exit();
}

$note_id = (int)$_GET['id'];
$has_access = false;
$access_type = null;

$database = new Database();
$db = $database->getConnection();

// Get note details
$query = "SELECT user_id, is_free, price FROM notes WHERE id = :note_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':note_id', $note_id);
$stmt->execute();

$note = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$note) {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "Note not found",
        "has_access" => false
    ]);
    exit();
}

// If user is logged in, check access
if(isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // Check if user is the owner
    if($note['user_id'] == $user_id) {
        $has_access = true;
        $access_type = "owner";
    } else {
        // Check if note is in user's library (purchased or added)
        $purchase_query = "SELECT id FROM purchases WHERE user_id = :user_id AND note_id = :note_id";
        $purchase_stmt = $db->prepare($purchase_query);
        $purchase_stmt->bindParam(':user_id', $user_id);
        $purchase_stmt->bindParam(':note_id', $note_id);
        $purchase_stmt->execute();
        
        if($purchase_stmt->rowCount() > 0) {
            $has_access = true;
            $access_type = "library";
        }
    }
}

http_response_code(200);
echo json_encode([
    "success" => true,
    "has_access" => $has_access,
    "access_type" => $access_type,
    "is_free" => ($note['is_free'] == 1 || !$note['price'] || floatval($note['price']) === 0.0)
]);
?>
