<?php
/**
 * Create PayPal Order API Endpoint
 * Creates a PayPal order for note purchase
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to browser
ini_set('log_errors', 1);

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

try {
    include_once '../config/database.php';
    include_once '../config/paypal.php';

    // Check if user is logged in
    if(!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode([
            "success" => false,
            "message" => "Please login to purchase notes"
        ]);
        exit();
    }

    // Check if PayPal is configured
    if(!PayPalConfig::isConfigured()) {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Payment system is not configured. Please contact administrator."
        ]);
        exit();
    }

    // Get POST data
    $data = json_decode(file_get_contents("php://input"));

    if(!isset($data->note_id)) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "Note ID is required"
        ]);
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $note_id = $data->note_id;

    $database = new Database();
    $db = $database->getConnection();
    
    if(!$db) {
        throw new Exception("Database connection failed");
    }

// Get note details
$query = "SELECT n.*, u.username as seller_name, u.email as seller_email 
          FROM notes n 
          LEFT JOIN users u ON n.user_id = u.id 
          WHERE n.id = :note_id AND n.status = 'approved'";
$stmt = $db->prepare($query);
$stmt->bindParam(':note_id', $note_id);
$stmt->execute();

if($stmt->rowCount() === 0) {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "Note not found"
    ]);
    exit();
}

$note = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if note is free
if($note['is_free'] || $note['price'] <= 0) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "This note is free. Use 'Add to Library' instead."
    ]);
    exit();
}

// Check if user is the seller
if($note['user_id'] == $user_id) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "You cannot purchase your own note"
    ]);
    exit();
}

// Check if already purchased
$check_query = "SELECT id FROM purchases WHERE user_id = :user_id AND note_id = :note_id";
$check_stmt = $db->prepare($check_query);
$check_stmt->bindParam(':user_id', $user_id);
$check_stmt->bindParam(':note_id', $note_id);
$check_stmt->execute();

if($check_stmt->rowCount() > 0) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "You have already purchased this note"
    ]);
    exit();
}

// Get access token from PayPal
$accessToken = PayPalConfig::getAccessToken();

if(!$accessToken || is_array($accessToken)) {
    // Detailed error message for debugging
    $errorMsg = "Failed to connect to payment gateway";
    if(is_array($accessToken) && isset($accessToken['message'])) {
        $errorMsg .= ": " . $accessToken['error'];
        error_log("PayPal API Error: " . json_encode($accessToken));
    }
    
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => $errorMsg,
        "debug" => is_array($accessToken) ? $accessToken : null
    ]);
    exit();
}

// Create PayPal order
$orderData = [
    'intent' => 'CAPTURE',
    'purchase_units' => [
        [
            'reference_id' => 'NOTE_' . $note_id . '_USER_' . $user_id . '_' . time(),
            'description' => 'Purchase: ' . $note['title'],
            'amount' => [
                'currency_code' => PayPalConfig::CURRENCY,
                'value' => number_format($note['price'], 2, '.', '')
            ],
            'custom_id' => json_encode([
                'note_id' => $note_id,
                'user_id' => $user_id,
                'seller_id' => $note['user_id']
            ])
        ]
    ],
    'application_context' => [
        'brand_name' => 'KwikPaper',
        'landing_page' => 'BILLING',
        'user_action' => 'PAY_NOW',
        'return_url' => PayPalConfig::SUCCESS_URL . '?note_id=' . $note_id,
        'cancel_url' => PayPalConfig::CANCEL_URL . '?note_id=' . $note_id
    ]
];

$ch = curl_init();

curl_setopt_array($ch, [
    CURLOPT_URL => PayPalConfig::getApiUrl() . '/v2/checkout/orders',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($orderData),
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $accessToken
    ],
    CURLOPT_SSL_VERIFYPEER => false, // Disable SSL verification for localhost testing
    CURLOPT_SSL_VERIFYHOST => false
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

    if($httpCode === 201) {
        $responseData = json_decode($response, true);
        
        // Create pending transaction record
        $transaction_id = 'TXN_' . uniqid() . '_' . time();
        
        $insert_query = "INSERT INTO transactions 
                         (transaction_id, paypal_order_id, user_id, note_id, seller_id, amount, currency, status) 
                         VALUES (:transaction_id, :paypal_order_id, :user_id, :note_id, :seller_id, :amount, :currency, 'pending')";
        $insert_stmt = $db->prepare($insert_query);
        $insert_stmt->bindParam(':transaction_id', $transaction_id);
        $insert_stmt->bindParam(':paypal_order_id', $responseData['id']);
        $insert_stmt->bindParam(':user_id', $user_id);
        $insert_stmt->bindParam(':note_id', $note_id);
        $insert_stmt->bindParam(':seller_id', $note['user_id']);
        $insert_stmt->bindParam(':amount', $note['price']);
        $insert_stmt->bindValue(':currency', PayPalConfig::CURRENCY);
        $insert_stmt->execute();
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "order_id" => $responseData['id'],
            "transaction_id" => $transaction_id,
            "message" => "Order created successfully"
        ]);
    } else {
        error_log('PayPal Order Creation Error (HTTP ' . $httpCode . '): ' . $response);
        
        $debugInfo = [
            'http_code' => $httpCode,
            'curl_error' => $curlError ?: null,
            'response' => json_decode($response, true) ?: substr($response, 0, 500)
        ];
        
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Failed to create payment order. Please try again.",
            "debug" => $debugInfo
        ]);
    }
} catch (PDOException $e) {
    error_log('Database Error in create-order.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Database error occurred",
        "error" => $e->getMessage(),
        "hint" => "Have you run the add_transactions_table.sql script?"
    ]);
} catch (Exception $e) {
    error_log('Error in create-order.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "An error occurred",
        "error" => $e->getMessage()
    ]);
}
?>
