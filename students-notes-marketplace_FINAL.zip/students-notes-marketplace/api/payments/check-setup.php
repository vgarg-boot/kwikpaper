<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 0);

$diagnostics = [
    'success' => true,
    'checks' => []
];

try {
    // Check 1: Database connection
    require_once __DIR__ . '/../config/database.php';
    $diagnostics['checks']['database'] = [
        'status' => 'ok',
        'message' => 'Database connection successful'
    ];
    
    // Check 2: Transactions table
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'transactions'");
        $tableExists = $stmt->fetch();
        
        if ($tableExists) {
            $diagnostics['checks']['transactions_table'] = [
                'status' => 'ok',
                'message' => 'Transactions table exists'
            ];
            
            // Check table structure
            $stmt = $pdo->query("DESCRIBE transactions");
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            $diagnostics['checks']['transactions_table']['columns'] = $columns;
        } else {
            $diagnostics['checks']['transactions_table'] = [
                'status' => 'error',
                'message' => 'Transactions table does NOT exist. Run api/config/add_transactions_table.sql',
                'action_needed' => 'Execute the SQL migration file'
            ];
            $diagnostics['success'] = false;
        }
    } catch (Exception $e) {
        $diagnostics['checks']['transactions_table'] = [
            'status' => 'error',
            'message' => 'Error checking transactions table: ' . $e->getMessage()
        ];
        $diagnostics['success'] = false;
    }
    
    // Check 3: PayPal configuration
    require_once __DIR__ . '/../config/paypal.php';
    
    if (PayPalConfig::isConfigured()) {
        $diagnostics['checks']['paypal_config'] = [
            'status' => 'ok',
            'message' => 'PayPal credentials configured'
        ];
        
        // Check 4: PayPal API connection
        $accessToken = PayPalConfig::getAccessToken();
        if (is_array($accessToken) && isset($accessToken['error'])) {
            $diagnostics['checks']['paypal_api'] = [
                'status' => 'error',
                'message' => 'PayPal API connection failed',
                'details' => $accessToken
            ];
            $diagnostics['success'] = false;
        } else {
            $diagnostics['checks']['paypal_api'] = [
                'status' => 'ok',
                'message' => 'PayPal API connection successful',
                'token_preview' => substr($accessToken, 0, 20) . '...'
            ];
        }
    } else {
        $diagnostics['checks']['paypal_config'] = [
            'status' => 'error',
            'message' => 'PayPal credentials not configured'
        ];
        $diagnostics['success'] = false;
    }
    
    // Check 5: Session
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if (isset($_SESSION['user_id'])) {
        $diagnostics['checks']['session'] = [
            'status' => 'ok',
            'message' => 'User session active',
            'user_id' => $_SESSION['user_id']
        ];
    } else {
        $diagnostics['checks']['session'] = [
            'status' => 'warning',
            'message' => 'No user session (login required for purchases)'
        ];
    }
    
    // Check 6: PHP cURL extension
    if (function_exists('curl_init')) {
        $diagnostics['checks']['curl'] = [
            'status' => 'ok',
            'message' => 'cURL extension enabled'
        ];
    } else {
        $diagnostics['checks']['curl'] = [
            'status' => 'error',
            'message' => 'cURL extension not enabled (required for PayPal)'
        ];
        $diagnostics['success'] = false;
    }
    
} catch (Exception $e) {
    $diagnostics['success'] = false;
    $diagnostics['error'] = $e->getMessage();
    $diagnostics['trace'] = $e->getTraceAsString();
}

echo json_encode($diagnostics, JSON_PRETTY_PRINT);
