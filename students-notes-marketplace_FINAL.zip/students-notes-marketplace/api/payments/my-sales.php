<?php
/**
 * Get Seller Sales API Endpoint
 * Returns all sales transactions for the logged-in user as a seller
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Please login to view sales"
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];

$database = new Database();
$db = $database->getConnection();

// Get filter parameters
$status = isset($_GET['status']) ? $_GET['status'] : 'all';

// Build query
$query = "SELECT t.*, n.title as note_title, n.category, u.username as buyer_name, u.avatar as buyer_avatar
          FROM transactions t
          LEFT JOIN notes n ON t.note_id = n.id
          LEFT JOIN users u ON t.user_id = u.id
          WHERE t.seller_id = :user_id";

if($status !== 'all') {
    $query .= " AND t.status = :status";
}

$query .= " ORDER BY t.transaction_date DESC";

$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $user_id);

if($status !== 'all') {
    $stmt->bindParam(':status', $status);
}

$stmt->execute();

$sales = [];
$totalRevenue = 0;
$totalEarnings = 0;
$totalPlatformFees = 0;
$completedCount = 0;

while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $sales[] = [
        'id' => $row['id'],
        'transaction_id' => $row['transaction_id'],
        'note_id' => $row['note_id'],
        'note_title' => $row['note_title'],
        'category' => $row['category'],
        'buyer_name' => $row['buyer_name'],
        'buyer_avatar' => $row['buyer_avatar'],
        'amount' => $row['amount'],
        'seller_earnings' => $row['seller_earnings'],
        'platform_fee' => $row['platform_fee'],
        'currency' => $row['currency'],
        'status' => $row['status'],
        'payment_method' => $row['payment_method'],
        'payer_email' => $row['payer_email'],
        'transaction_date' => $row['transaction_date'],
        'completed_date' => $row['completed_date']
    ];
    
    if($row['status'] === 'completed') {
        $totalRevenue += floatval($row['amount']);
        $totalEarnings += floatval($row['seller_earnings']);
        $totalPlatformFees += floatval($row['platform_fee']);
        $completedCount++;
    }
}

http_response_code(200);
echo json_encode([
    "success" => true,
    "count" => count($sales),
    "total_revenue" => number_format($totalRevenue, 2),
    "total_earnings" => number_format($totalEarnings, 2),
    "total_platform_fees" => number_format($totalPlatformFees, 2),
    "completed_count" => $completedCount,
    "data" => $sales
]);
?>
