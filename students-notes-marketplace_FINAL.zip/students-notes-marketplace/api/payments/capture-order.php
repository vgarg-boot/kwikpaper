<?php
/**
 * Capture PayPal Payment API Endpoint
 * Captures/completes a PayPal payment after user approval
 */

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors to browser
ini_set('log_errors', 1);

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

try {
    include_once '../config/database.php';
    include_once '../config/paypal.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Please login to complete purchase"
    ]);
    exit();
}

// Get POST data
$data = json_decode(file_get_contents("php://input"));

if(!isset($data->order_id)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Order ID is required"
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];
$order_id = $data->order_id;

$database = new Database();
$db = $database->getConnection();

// Get transaction details
$query = "SELECT * FROM transactions WHERE paypal_order_id = :order_id AND user_id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(':order_id', $order_id);
$stmt->bindParam(':user_id', $user_id);
$stmt->execute();

if($stmt->rowCount() === 0) {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "Transaction not found"
    ]);
    exit();
}

$transaction = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if already completed
if($transaction['status'] === 'completed') {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Transaction already completed"
    ]);
    exit();
}

// Get access token from PayPal
$accessToken = PayPalConfig::getAccessToken();

if(!$accessToken) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Failed to connect to payment gateway"
    ]);
    exit();
}

// Capture PayPal order
$ch = curl_init();

curl_setopt_array($ch, [
    CURLOPT_URL => PayPalConfig::getApiUrl() . '/v2/checkout/orders/' . $order_id . '/capture',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $accessToken
    ],
    CURLOPT_SSL_VERIFYPEER => false, // Disable SSL verification for localhost testing
    CURLOPT_SSL_VERIFYHOST => false
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if($httpCode === 201) {
    $responseData = json_decode($response, true);
    $captureStatus = $responseData['status'];
    
    if($captureStatus === 'COMPLETED') {
        // Extract payer info
        $payerInfo = $responseData['payer'] ?? [];
        $payerEmail = $payerInfo['email_address'] ?? null;
        $payerName = ($payerInfo['name']['given_name'] ?? '') . ' ' . ($payerInfo['name']['surname'] ?? '');
        $paypalPayerId = $payerInfo['payer_id'] ?? null;
        
        // Calculate earnings
        $amount = floatval($transaction['amount']);
        $platformFee = PayPalConfig::calculatePlatformFee($amount);
        $sellerEarnings = PayPalConfig::calculateSellerEarnings($amount);
        
        // Begin transaction
        $db->beginTransaction();
        
        try {
            // Update transaction status
            $update_query = "UPDATE transactions SET 
                           status = 'completed',
                           paypal_payer_id = :payer_id,
                           payer_email = :payer_email,
                           payer_name = :payer_name,
                           seller_earnings = :seller_earnings,
                           platform_fee = :platform_fee,
                           completed_date = NOW()
                           WHERE paypal_order_id = :order_id";
            $update_stmt = $db->prepare($update_query);
            $update_stmt->bindParam(':payer_id', $paypalPayerId);
            $update_stmt->bindParam(':payer_email', $payerEmail);
            $update_stmt->bindParam(':payer_name', $payerName);
            $update_stmt->bindParam(':seller_earnings', $sellerEarnings);
            $update_stmt->bindParam(':platform_fee', $platformFee);
            $update_stmt->bindParam(':order_id', $order_id);
            $update_stmt->execute();
            
            // Add to purchases table
            $purchase_query = "INSERT INTO purchases 
                             (user_id, note_id, amount, transaction_id, payment_status, purchase_date) 
                             VALUES (:user_id, :note_id, :amount, :transaction_id, 'paid', NOW())";
            $purchase_stmt = $db->prepare($purchase_query);
            $purchase_stmt->bindParam(':user_id', $user_id);
            $purchase_stmt->bindParam(':note_id', $transaction['note_id']);
            $purchase_stmt->bindParam(':amount', $transaction['amount']);
            $purchase_stmt->bindParam(':transaction_id', $transaction['transaction_id']);
            $purchase_stmt->execute();
            
            // Update note downloads count
            $downloads_query = "UPDATE notes SET downloads = downloads + 1 WHERE id = :note_id";
            $downloads_stmt = $db->prepare($downloads_query);
            $downloads_stmt->bindParam(':note_id', $transaction['note_id']);
            $downloads_stmt->execute();
            
            // Update user's notes_purchased count
            $user_update = "UPDATE users SET notes_purchased = notes_purchased + 1 WHERE id = :user_id";
            $user_stmt = $db->prepare($user_update);
            $user_stmt->bindParam(':user_id', $user_id);
            $user_stmt->execute();
            
            // Update seller's earnings
            $seller_update = "UPDATE users SET earnings = earnings + :earnings WHERE id = :seller_id";
            $seller_stmt = $db->prepare($seller_update);
            $seller_stmt->bindParam(':earnings', $sellerEarnings);
            $seller_stmt->bindParam(':seller_id', $transaction['seller_id']);
            $seller_stmt->execute();
            
            // Commit transaction
            $db->commit();
            
            http_response_code(200);
            echo json_encode([
                "success" => true,
                "message" => "Payment completed successfully",
                "transaction_id" => $transaction['transaction_id'],
                "note_id" => $transaction['note_id']
            ]);
        } catch(Exception $e) {
            $db->rollBack();
            error_log('Transaction Error: ' . $e->getMessage());
            
            http_response_code(500);
            echo json_encode([
                "success" => false,
                "message" => "Failed to complete transaction. Please contact support."
            ]);
        }
    } else {
        // Update transaction as failed
        $update_query = "UPDATE transactions SET status = 'failed' WHERE paypal_order_id = :order_id";
        $update_stmt = $db->prepare($update_query);
        $update_stmt->bindParam(':order_id', $order_id);
        $update_stmt->execute();
        
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "Payment not completed. Status: " . $captureStatus
        ]);
    }
} else {
    error_log('PayPal Capture Error: ' . $response);
    
    // Update transaction as failed
    $update_query = "UPDATE transactions SET status = 'failed' WHERE paypal_order_id = :order_id";
    $update_stmt = $db->prepare($update_query);
    $update_stmt->bindParam(':order_id', $order_id);
    $update_stmt->execute();
    
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Failed to capture payment. Please try again.",
        "debug" => json_decode($response, true)
    ]);
}
} catch (PDOException $e) {
    error_log('Database Error in capture-order.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Database error occurred",
        "error" => $e->getMessage()
    ]);
} catch (Exception $e) {
    error_log('Error in capture-order.php: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "An error occurred",
        "error" => $e->getMessage()
    ]);
}
?>
