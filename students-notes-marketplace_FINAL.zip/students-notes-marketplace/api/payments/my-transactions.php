<?php
/**
 * Get User Transactions (Buyer) API Endpoint
 * Returns all transactions for the logged-in user as a buyer
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Please login to view transactions"
    ]);
    exit();
}

$user_id = $_SESSION['user_id'];

$database = new Database();
$db = $database->getConnection();

// Get filter parameters
$status = isset($_GET['status']) ? $_GET['status'] : 'all';

// Build query
$query = "SELECT t.*, n.title as note_title, n.category, u.username as seller_name, u.avatar as seller_avatar
          FROM transactions t
          LEFT JOIN notes n ON t.note_id = n.id
          LEFT JOIN users u ON t.seller_id = u.id
          WHERE t.user_id = :user_id";

if($status !== 'all') {
    $query .= " AND t.status = :status";
}

$query .= " ORDER BY t.transaction_date DESC";

$stmt = $db->prepare($query);
$stmt->bindParam(':user_id', $user_id);

if($status !== 'all') {
    $stmt->bindParam(':status', $status);
}

$stmt->execute();

$transactions = [];
$totalSpent = 0;
$completedCount = 0;

while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $transactions[] = [
        'id' => $row['id'],
        'transaction_id' => $row['transaction_id'],
        'note_id' => $row['note_id'],
        'note_title' => $row['note_title'],
        'category' => $row['category'],
        'seller_name' => $row['seller_name'],
        'seller_avatar' => $row['seller_avatar'],
        'amount' => $row['amount'],
        'currency' => $row['currency'],
        'status' => $row['status'],
        'payment_method' => $row['payment_method'],
        'transaction_date' => $row['transaction_date'],
        'completed_date' => $row['completed_date']
    ];
    
    if($row['status'] === 'completed') {
        $totalSpent += floatval($row['amount']);
        $completedCount++;
    }
}

http_response_code(200);
echo json_encode([
    "success" => true,
    "count" => count($transactions),
    "total_spent" => number_format($totalSpent, 2),
    "completed_count" => $completedCount,
    "data" => $transactions
]);
?>
