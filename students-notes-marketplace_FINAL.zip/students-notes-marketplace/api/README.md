# KwikPaper API Documentation

## Overview
This is a comprehensive PHP REST API for the KwikPaper platform. The API provides endpoints for user authentication, note management, and profile operations.

## Setup Instructions

### 1. Database Setup
1. Import the database schema:
   ```bash
   mysql -u root -p < api/config/database.sql
   ```
2. Update database credentials in `api/config/database.php` if needed

### 2. Directory Structure
```
api/
├── config/
│   ├── database.php          # Database configuration
│   └── database.sql          # Database schema
├── models/
│   ├── User.php              # User model
│   └── Note.php              # Note model
├── auth/
│   ├── register.php          # User registration
│   ├── login.php             # User login
│   ├── logout.php            # User logout
│   └── session.php           # Check session
├── notes/
│   ├── list.php              # Browse notes
│   ├── detail.php            # Note details
│   ├── create.php            # Upload note
│   ├── user-notes.php        # User's notes
│   └── featured.php          # Featured notes
└── user/
    ├── profile.php           # Get profile
    ├── update-profile.php    # Update profile
    └── stats.php             # User statistics
```

### 3. File Upload Directory
Create the uploads directory:
```bash
mkdir -p uploads/notes
chmod 777 uploads/notes
```

## API Endpoints

### Authentication

#### Register User
- **URL**: `POST /api/auth/register.php`
- **Body**:
  ```json
  {
    "username": "john_doe",
    "email": "john@example.com",
    "password": "password123"
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "message": "User registered successfully",
    "user": {
      "id": 1,
      "username": "john_doe",
      "email": "john@example.com"
    }
  }
  ```

#### Login
- **URL**: `POST /api/auth/login.php`
- **Body**:
  ```json
  {
    "username": "john_doe",
    "password": "password123"
  }
  ```
- **Response**:
  ```json
  {
    "success": true,
    "message": "Login successful",
    "user": {
      "id": 1,
      "username": "john_doe",
      "email": "john@example.com",
      "notes_uploaded": 5,
      "notes_purchased": 3,
      "earnings": 125.50
    },
    "session_token": "abc123..."
  }
  ```

#### Logout
- **URL**: `POST /api/auth/logout.php`
- **Response**:
  ```json
  {
    "success": true,
    "message": "Logged out successfully"
  }
  ```

#### Check Session
- **URL**: `GET /api/auth/session.php`
- **Response**:
  ```json
  {
    "success": true,
    "logged_in": true,
    "user": { ... }
  }
  ```

### Notes

#### Browse Notes
- **URL**: `GET /api/notes/list.php?page=1&limit=12&category=all&search=biology`
- **Parameters**:
  - `page`: Page number (default: 1)
  - `limit`: Items per page (default: 12)
  - `category`: Filter by category (default: all)
  - `search`: Search term (optional)
- **Response**:
  ```json
  {
    "success": true,
    "data": [
      {
        "id": 1,
        "title": "Biology 101",
        "description": "Complete notes",
        "category": "science",
        "price": 15.99,
        "username": "sarah",
        "avatar": "👩‍🎓",
        "rating": 4.9
      }
    ],
    "pagination": {
      "current_page": 1,
      "total_pages": 5,
      "total_records": 60,
      "limit": 12
    }
  }
  ```

#### Get Note Details
- **URL**: `GET /api/notes/detail.php?id=1`
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "title": "Biology 101",
      "description": "Complete notes covering all chapters",
      "category": "science",
      "price": 15.99,
      "pages": 120,
      "views": 1247,
      "downloads": 234,
      "rating": 4.9,
      "username": "sarah",
      "university": "Stanford University"
    }
  }
  ```

#### Upload Note
- **URL**: `POST /api/notes/create.php`
- **Method**: multipart/form-data
- **Body**:
  - `title`: Note title
  - `description`: Note description
  - `category`: Category (science, math, history, etc.)
  - `price`: Price in USD
  - `pages`: Number of pages
  - `file`: PDF/DOC file
- **Requires**: Authentication
- **Response**:
  ```json
  {
    "success": true,
    "message": "Note uploaded successfully",
    "note_id": 123
  }
  ```

#### Get User's Notes
- **URL**: `GET /api/notes/user-notes.php?user_id=1`
- **Response**:
  ```json
  {
    "success": true,
    "data": [ ... ],
    "count": 5
  }
  ```

#### Get Featured Notes
- **URL**: `GET /api/notes/featured.php?limit=6`
- **Response**:
  ```json
  {
    "success": true,
    "data": [ ... ],
    "count": 6
  }
  ```

### User Profile

#### Get Profile
- **URL**: `GET /api/user/profile.php?user_id=1`
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "id": 1,
      "username": "john_doe",
      "email": "john@example.com",
      "avatar": "👤",
      "bio": "Student at MIT",
      "university": "MIT",
      "year": "Junior",
      "subject": "Computer Science",
      "notes_uploaded": 5,
      "notes_purchased": 3,
      "earnings": 125.50
    }
  }
  ```

#### Update Profile
- **URL**: `PUT /api/user/update-profile.php`
- **Body**:
  ```json
  {
    "email": "newemail@example.com",
    "avatar": "👨‍🎓",
    "bio": "CS student passionate about algorithms",
    "university": "MIT",
    "year": "Junior",
    "subject": "Computer Science"
  }
  ```
- **Requires**: Authentication
- **Response**:
  ```json
  {
    "success": true,
    "message": "Profile updated successfully"
  }
  ```

#### Get User Stats
- **URL**: `GET /api/user/stats.php`
- **Requires**: Authentication
- **Response**:
  ```json
  {
    "success": true,
    "data": {
      "notes_uploaded": 5,
      "notes_purchased": 3,
      "earnings": 125.50
    }
  }
  ```

## Integration Examples

### JavaScript/Fetch Example

```javascript
// Register user
async function registerUser(username, email, password) {
  const response = await fetch('api/auth/register.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ username, email, password })
  });
  return await response.json();
}

// Login
async function login(username, password) {
  const response = await fetch('api/auth/login.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ username, password })
  });
  const data = await response.json();
  if (data.success) {
    localStorage.setItem('user', JSON.stringify(data.user));
  }
  return data;
}

// Browse notes
async function browseNotes(page = 1, category = 'all', search = '') {
  const response = await fetch(
    `api/notes/list.php?page=${page}&category=${category}&search=${search}`
  );
  return await response.json();
}

// Upload note
async function uploadNote(formData) {
  const response = await fetch('api/notes/create.php', {
    method: 'POST',
    body: formData // FormData with file and other fields
  });
  return await response.json();
}
```

### jQuery/Ajax Example

```javascript
// Login
$.ajax({
  url: 'api/auth/login.php',
  type: 'POST',
  contentType: 'application/json',
  data: JSON.stringify({
    username: 'john_doe',
    password: 'password123'
  }),
  success: function(response) {
    if (response.success) {
      localStorage.setItem('user', JSON.stringify(response.user));
      window.location.href = 'dashboard.html';
    }
  }
});

// Browse notes
$.get('api/notes/list.php', {
  page: 1,
  category: 'science',
  search: 'biology'
}, function(response) {
  if (response.success) {
    displayNotes(response.data);
  }
});
```

## Error Codes

- **200**: Success
- **201**: Created
- **400**: Bad Request (validation error)
- **401**: Unauthorized (authentication required)
- **404**: Not Found
- **409**: Conflict (duplicate entry)
- **500**: Internal Server Error

## Security Features

- Password hashing using bcrypt
- SQL injection prevention using prepared statements
- XSS protection with input sanitization
- Session management
- File upload validation

## Notes

- All responses are in JSON format
- Dates are in ISO 8601 format
- Prices are in USD (decimal 10,2)
- File uploads limited to PDF, DOC, DOCX, TXT
- Session timeout: 24 hours (configurable in php.ini)
