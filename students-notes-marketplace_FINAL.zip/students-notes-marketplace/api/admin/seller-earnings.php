<?php
/**
 * Admin Seller Earnings API
 * GET: List all sellers with their earnings to be paid
 * PUT: Mark earnings as paid
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, PUT");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../auth/admin-auth.php';

// Require admin authentication
requireAdmin();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch($method) {
        case 'GET':
            handleGetSellerEarnings($db);
            break;
        case 'PUT':
            handleMarkAsPaid($db);
            break;
        default:
            http_response_code(405);
            echo json_encode(["success" => false, "message" => "Method not allowed"]);
    }
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Server error: " . $e->getMessage()
    ]);
}

function handleGetSellerEarnings($db) {
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $status = isset($_GET['status']) ? $_GET['status'] : 'unpaid'; // unpaid, paid, all
    $dateFrom = isset($_GET['date_from']) ? $_GET['date_from'] : '';
    $dateTo = isset($_GET['date_to']) ? $_GET['date_to'] : '';
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;
    $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
    
    // Build the query to aggregate earnings by seller
    $query = "SELECT 
                s.id as seller_id,
                s.username as seller_name,
                s.email as seller_email,
                COUNT(DISTINCT t.id) as total_sales,
                COUNT(DISTINCT t.note_id) as notes_sold,
                SUM(CASE WHEN t.status = 'completed' THEN t.seller_earnings ELSE 0 END) as total_earnings,
                SUM(CASE WHEN t.status = 'completed' AND (t.payout_status IS NULL OR t.payout_status = 'unpaid') THEN t.seller_earnings ELSE 0 END) as unpaid_earnings,
                SUM(CASE WHEN t.status = 'completed' AND t.payout_status = 'paid' THEN t.seller_earnings ELSE 0 END) as paid_earnings,
                MIN(t.transaction_date) as first_sale_date,
                MAX(t.transaction_date) as last_sale_date
              FROM users s
              INNER JOIN transactions t ON s.id = t.seller_id
              WHERE t.status = 'completed'";
    
    $params = [];
    
    if ($search !== '') {
        $query .= " AND (s.username LIKE :search OR s.email LIKE :search)";
        $params[':search'] = "%$search%";
    }
    
    if ($dateFrom !== '') {
        $query .= " AND t.transaction_date >= :date_from";
        $params[':date_from'] = $dateFrom;
    }
    
    if ($dateTo !== '') {
        $query .= " AND t.transaction_date <= :date_to";
        $params[':date_to'] = $dateTo . ' 23:59:59';
    }
    
    $query .= " GROUP BY s.id, s.username, s.email";
    
    // Filter by payment status
    if ($status === 'unpaid') {
        $query .= " HAVING unpaid_earnings > 0";
    } elseif ($status === 'paid') {
        $query .= " HAVING paid_earnings > 0 AND unpaid_earnings = 0";
    }
    
    $query .= " ORDER BY unpaid_earnings DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $sellers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count for pagination
    $countQuery = "SELECT COUNT(DISTINCT t.seller_id) as total
                   FROM transactions t
                   INNER JOIN users s ON t.seller_id = s.id
                   WHERE t.status = 'completed'";
    
    if ($search !== '') {
        $countQuery .= " AND (s.username LIKE :search OR s.email LIKE :search)";
    }
    
    if ($dateFrom !== '') {
        $countQuery .= " AND t.transaction_date >= :date_from";
    }
    
    if ($dateTo !== '') {
        $countQuery .= " AND t.transaction_date <= :date_to";
    }
    
    $countStmt = $db->prepare($countQuery);
    foreach ($params as $key => $value) {
        if ($key !== ':limit' && $key !== ':offset') {
            $countStmt->bindValue($key, $value);
        }
    }
    $countStmt->execute();
    $totalCount = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Get summary statistics
    $summaryQuery = "SELECT 
                        COUNT(DISTINCT t.seller_id) as total_sellers,
                        SUM(CASE WHEN t.status = 'completed' THEN t.seller_earnings ELSE 0 END) as total_earnings,
                        SUM(CASE WHEN t.status = 'completed' AND (t.payout_status IS NULL OR t.payout_status = 'unpaid') THEN t.seller_earnings ELSE 0 END) as total_unpaid,
                        SUM(CASE WHEN t.status = 'completed' AND t.payout_status = 'paid' THEN t.seller_earnings ELSE 0 END) as total_paid
                     FROM transactions t
                     WHERE t.status = 'completed'";
    
    $summaryStmt = $db->prepare($summaryQuery);
    $summaryStmt->execute();
    $summary = $summaryStmt->fetch(PDO::FETCH_ASSOC);
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "data" => $sellers,
        "total" => $totalCount,
        "page" => ceil($offset / $limit) + 1,
        "limit" => $limit,
        "summary" => $summary
    ]);
}

function handleMarkAsPaid($db) {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (!isset($data['seller_id'])) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "Seller ID is required"
        ]);
        return;
    }
    
    $seller_id = $data['seller_id'];
    $payout_date = isset($data['payout_date']) ? $data['payout_date'] : date('Y-m-d H:i:s');
    $payout_method = isset($data['payout_method']) ? $data['payout_method'] : 'manual';
    $payout_reference = isset($data['payout_reference']) ? $data['payout_reference'] : null;
    $notes = isset($data['notes']) ? $data['notes'] : null;
    
    // Start transaction
    $db->beginTransaction();
    
    try {
        // Mark all unpaid completed transactions for this seller as paid
        $query = "UPDATE transactions 
                  SET payout_status = 'paid',
                      payout_date = :payout_date,
                      payout_method = :payout_method,
                      payout_reference = :payout_reference,
                      payout_notes = :notes
                  WHERE seller_id = :seller_id 
                  AND status = 'completed'
                  AND (payout_status IS NULL OR payout_status = 'unpaid')";
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':seller_id', $seller_id, PDO::PARAM_INT);
        $stmt->bindParam(':payout_date', $payout_date);
        $stmt->bindParam(':payout_method', $payout_method);
        $stmt->bindParam(':payout_reference', $payout_reference);
        $stmt->bindParam(':notes', $notes);
        $stmt->execute();
        
        $updated_count = $stmt->rowCount();
        
        // Get total amount paid
        $amountQuery = "SELECT SUM(seller_earnings) as total_paid
                       FROM transactions
                       WHERE seller_id = :seller_id 
                       AND payout_date = :payout_date";
        $amountStmt = $db->prepare($amountQuery);
        $amountStmt->bindParam(':seller_id', $seller_id, PDO::PARAM_INT);
        $amountStmt->bindParam(':payout_date', $payout_date);
        $amountStmt->execute();
        $result = $amountStmt->fetch(PDO::FETCH_ASSOC);
        $total_paid = $result['total_paid'];
        
        // Log the action
        $logQuery = "INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details, created_at)
                    VALUES (:user_id, 'mark_payout', 'seller', :seller_id, :details, NOW())";
        $logStmt = $db->prepare($logQuery);
        $logStmt->bindParam(':user_id', $_SESSION['user_id'], PDO::PARAM_INT);
        $logStmt->bindParam(':seller_id', $seller_id, PDO::PARAM_INT);
        $details = json_encode([
            'transactions_updated' => $updated_count,
            'total_paid' => $total_paid,
            'payout_method' => $payout_method,
            'payout_reference' => $payout_reference
        ]);
        $logStmt->bindParam(':details', $details);
        $logStmt->execute();
        
        $db->commit();
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Payout marked as paid successfully",
            "transactions_updated" => $updated_count,
            "total_paid" => $total_paid
        ]);
        
    } catch(Exception $e) {
        $db->rollBack();
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Failed to mark payout as paid: " . $e->getMessage()
        ]);
    }
}
?>
