<?php
/**
 * Admin Dashboard Statistics API
 * GET: api/admin/dashboard-stats.php
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../auth/admin-auth.php';

// Require admin authentication
requireAdmin();

$database = new Database();
$db = $database->getConnection();

try {
    // Get total users
    $query = "SELECT COUNT(*) as total FROM users WHERE active = 1";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $totalUsers = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Get new users this month
    $query = "SELECT COUNT(*) as total FROM users WHERE active = 1 AND join_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $newUsersThisMonth = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Get total notes
    $query = "SELECT COUNT(*) as total FROM notes";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $totalNotes = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Get pending notes
    $query = "SELECT COUNT(*) as total FROM notes WHERE status = 'pending'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $pendingNotes = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Get total transactions
    $query = "SELECT COUNT(*) as total, SUM(amount) as total_amount FROM transactions WHERE status = 'completed'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $transactionStats = $stmt->fetch(PDO::FETCH_ASSOC);
    $totalTransactions = $transactionStats['total'];
    $totalRevenue = $transactionStats['total_amount'] ?? 0;
    
    // Get transactions this month
    $query = "SELECT COUNT(*) as total, SUM(amount) as total_amount FROM transactions WHERE status = 'completed' AND transaction_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $monthStats = $stmt->fetch(PDO::FETCH_ASSOC);
    $monthlyTransactions = $monthStats['total'];
    $monthlyRevenue = $monthStats['total_amount'] ?? 0;
    
    // Get platform fees (10% of revenue)
    $platformFeePercentage = 10;
    $platformFees = $totalRevenue * ($platformFeePercentage / 100);
    $monthlyPlatformFees = $monthlyRevenue * ($platformFeePercentage / 100);
    
    // Get top sellers
    $query = "SELECT u.id, u.username, u.avatar, u.earnings, COUNT(DISTINCT n.id) as notes_count
              FROM users u
              LEFT JOIN notes n ON u.id = n.user_id
              WHERE u.active = 1
              GROUP BY u.id, u.username, u.avatar, u.earnings
              ORDER BY u.earnings DESC
              LIMIT 5";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $topSellers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get recent transactions
    $query = "SELECT t.*, n.title as note_title, u.username as buyer_name, s.username as seller_name
              FROM transactions t
              LEFT JOIN notes n ON t.note_id = n.id
              LEFT JOIN users u ON t.user_id = u.id
              LEFT JOIN users s ON t.seller_id = s.id
              ORDER BY t.transaction_date DESC
              LIMIT 10";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $recentTransactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get category statistics
    $query = "SELECT category, COUNT(*) as count FROM notes GROUP BY category ORDER BY count DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $categoryStats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "stats" => [
            "users" => [
                "total" => intval($totalUsers),
                "new_this_month" => intval($newUsersThisMonth)
            ],
            "notes" => [
                "total" => intval($totalNotes),
                "pending" => intval($pendingNotes)
            ],
            "transactions" => [
                "total" => intval($totalTransactions),
                "monthly" => intval($monthlyTransactions)
            ],
            "revenue" => [
                "total" => number_format($totalRevenue, 2),
                "monthly" => number_format($monthlyRevenue, 2),
                "platform_fees" => number_format($platformFees, 2),
                "monthly_platform_fees" => number_format($monthlyPlatformFees, 2)
            ]
        ],
        "top_sellers" => $topSellers,
        "recent_transactions" => $recentTransactions,
        "category_stats" => $categoryStats
    ]);
    
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error fetching dashboard statistics: " . $e->getMessage()
    ]);
}
?>
