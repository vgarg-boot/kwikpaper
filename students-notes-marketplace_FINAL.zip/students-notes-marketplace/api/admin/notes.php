<?php
/**
 * Admin Notes Management API
 * GET: List all notes
 * PUT: Update note (approve/reject/feature)
 * DELETE: Delete note
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../auth/admin-auth.php';

// Require admin authentication
requireAdmin();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch($method) {
        case 'GET':
            handleGetNotes($db);
            break;
        case 'PUT':
            handleUpdateNote($db);
            break;
        case 'DELETE':
            handleDeleteNote($db);
            break;
        default:
            http_response_code(405);
            echo json_encode(["success" => false, "message" => "Method not allowed"]);
    }
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Server error: " . $e->getMessage()
    ]);
}

function handleGetNotes($db) {
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $category = isset($_GET['category']) ? $_GET['category'] : 'all';
    $status = isset($_GET['status']) ? $_GET['status'] : 'all';
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;
    $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
    
    $query = "SELECT n.*, u.username, u.avatar 
              FROM notes n
              LEFT JOIN users u ON n.user_id = u.id
              WHERE 1=1";
    
    $params = [];
    
    if ($search !== '') {
        $query .= " AND (n.title LIKE :search OR n.description LIKE :search)";
        $params[':search'] = "%$search%";
    }
    
    if ($category !== 'all') {
        $query .= " AND n.category = :category";
        $params[':category'] = $category;
    }
    
    if ($status !== 'all') {
        $query .= " AND n.status = :status";
        $params[':status'] = $status;
    }
    
    $query .= " ORDER BY n.created_at DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $notes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM notes n WHERE 1=1";
    if ($search !== '') {
        $countQuery .= " AND (n.title LIKE :search OR n.description LIKE :search)";
    }
    if ($category !== 'all') {
        $countQuery .= " AND n.category = :category";
    }
    if ($status !== 'all') {
        $countQuery .= " AND n.status = :status";
    }
    
    $countStmt = $db->prepare($countQuery);
    foreach ($params as $key => $value) {
        if (strpos($key, 'limit') === false && strpos($key, 'offset') === false) {
            $countStmt->bindValue($key, $value);
        }
    }
    $countStmt->execute();
    $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "total" => intval($total),
        "count" => count($notes),
        "data" => $notes
    ]);
}

function handleUpdateNote($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!isset($data->note_id)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "Note ID is required"]);
        return;
    }
    
    $updates = [];
    $params = [':note_id' => $data->note_id];
    
    if (isset($data->status)) {
        $updates[] = "status = :status";
        $params[':status'] = $data->status;
    }
    
    if (isset($data->price)) {
        $updates[] = "price = :price";
        $params[':price'] = $data->price;
    }
    
    if (isset($data->is_free)) {
        $updates[] = "is_free = :is_free";
        $params[':is_free'] = $data->is_free ? 1 : 0;
    }
    
    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "No fields to update"]);
        return;
    }
    
    $query = "UPDATE notes SET " . implode(", ", $updates) . " WHERE id = :note_id";
    $stmt = $db->prepare($query);
    
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    if ($stmt->execute()) {
        // Log admin action
        logAdminAction($db, $_SESSION['user_id'], 'update_note', 'note', $data->note_id, 
                      "Updated note fields: " . implode(", ", array_keys((array)$data)));
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Note updated successfully"
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Failed to update note"
        ]);
    }
}

function handleDeleteNote($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!isset($data->note_id)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "Note ID is required"]);
        return;
    }
    
    // Get note file path before deletion
    $query = "SELECT file_path FROM notes WHERE id = :note_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':note_id', $data->note_id);
    $stmt->execute();
    $note = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Delete note from database
    $query = "DELETE FROM notes WHERE id = :note_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':note_id', $data->note_id);
    
    if ($stmt->execute()) {
        // Delete physical file if exists
        if ($note && !empty($note['file_path'])) {
            $filePath = '../../' . $note['file_path'];
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }
        
        // Log admin action
        logAdminAction($db, $_SESSION['user_id'], 'delete_note', 'note', $data->note_id, 
                      "Deleted note and associated file");
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Note deleted successfully"
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Failed to delete note"
        ]);
    }
}
?>
