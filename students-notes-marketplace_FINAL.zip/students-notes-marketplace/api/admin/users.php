<?php
/**
 * Admin User Management API
 * GET: List all users
 * PUT: Update user
 * DELETE: Delete user
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../auth/admin-auth.php';

// Require admin authentication
requireAdmin();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch($method) {
        case 'GET':
            handleGetUsers($db);
            break;
        case 'PUT':
            handleUpdateUser($db);
            break;
        case 'DELETE':
            handleDeleteUser($db);
            break;
        default:
            http_response_code(405);
            echo json_encode(["success" => false, "message" => "Method not allowed"]);
    }
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Server error: " . $e->getMessage()
    ]);
}

function handleGetUsers($db) {
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $role = isset($_GET['role']) ? $_GET['role'] : 'all';
    $status = isset($_GET['status']) ? $_GET['status'] : 'all';
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;
    $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
    
    $query = "SELECT id, username, email, avatar, bio, university, year, subject, 
                     notes_uploaded, notes_purchased, earnings, join_date, last_login, 
                     active, role 
              FROM users WHERE 1=1";
    
    $params = [];
    
    if ($search !== '') {
        $query .= " AND (username LIKE :search OR email LIKE :search)";
        $params[':search'] = "%$search%";
    }
    
    if ($role !== 'all') {
        $query .= " AND role = :role";
        $params[':role'] = $role;
    }
    
    if ($status === 'active') {
        $query .= " AND active = 1";
    } elseif ($status === 'inactive') {
        $query .= " AND active = 0";
    }
    
    $query .= " ORDER BY join_date DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM users WHERE 1=1";
    if ($search !== '') {
        $countQuery .= " AND (username LIKE :search OR email LIKE :search)";
    }
    if ($role !== 'all') {
        $countQuery .= " AND role = :role";
    }
    if ($status === 'active') {
        $countQuery .= " AND active = 1";
    } elseif ($status === 'inactive') {
        $countQuery .= " AND active = 0";
    }
    
    $countStmt = $db->prepare($countQuery);
    foreach ($params as $key => $value) {
        if (strpos($key, 'limit') === false && strpos($key, 'offset') === false) {
            $countStmt->bindValue($key, $value);
        }
    }
    $countStmt->execute();
    $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "total" => intval($total),
        "count" => count($users),
        "data" => $users
    ]);
}

function handleUpdateUser($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!isset($data->user_id)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "User ID is required"]);
        return;
    }
    
    $updates = [];
    $params = [':user_id' => $data->user_id];
    
    if (isset($data->active)) {
        $updates[] = "active = :active";
        $params[':active'] = $data->active ? 1 : 0;
    }
    
    if (isset($data->role)) {
        $updates[] = "role = :role";
        $params[':role'] = $data->role;
    }
    
    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "No fields to update"]);
        return;
    }
    
    $query = "UPDATE users SET " . implode(", ", $updates) . " WHERE id = :user_id";
    $stmt = $db->prepare($query);
    
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    if ($stmt->execute()) {
        // Log admin action
        logAdminAction($db, $_SESSION['user_id'], 'update_user', 'user', $data->user_id, 
                      "Updated user fields: " . implode(", ", array_keys((array)$data)));
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "User updated successfully"
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Failed to update user"
        ]);
    }
}

function handleDeleteUser($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!isset($data->user_id)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "User ID is required"]);
        return;
    }
    
    // Prevent deleting yourself
    if ($data->user_id == $_SESSION['user_id']) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "Cannot delete your own account"]);
        return;
    }
    
    $query = "DELETE FROM users WHERE id = :user_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':user_id', $data->user_id);
    
    if ($stmt->execute()) {
        // Log admin action
        logAdminAction($db, $_SESSION['user_id'], 'delete_user', 'user', $data->user_id, 
                      "Deleted user account");
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "User deleted successfully"
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Failed to delete user"
        ]);
    }
}
?>
