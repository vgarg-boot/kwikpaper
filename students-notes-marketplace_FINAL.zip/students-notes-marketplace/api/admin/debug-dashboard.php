<?php
/**
 * Debug Dashboard Stats - Shows detailed error messages
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

header("Content-Type: text/html; charset=UTF-8");

echo "<h2>Debug Dashboard Stats API</h2>";

echo "<h3>Session Check:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

include_once '../config/database.php';
include_once '../auth/admin-auth.php';

echo "<h3>Admin Auth Check:</h3>";
try {
    requireAdmin();
    echo "<p style='color: green;'>✓ Admin authentication passed</p>";
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Admin auth failed: " . $e->getMessage() . "</p>";
    exit();
}

echo "<h3>Database Connection:</h3>";
try {
    $database = new Database();
    $db = $database->getConnection();
    echo "<p style='color: green;'>✓ Database connected</p>";
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Database connection failed: " . $e->getMessage() . "</p>";
    exit();
}

echo "<h3>Testing Queries:</h3>";

// Test 1: Check if transactions table exists
echo "<h4>1. Transactions Table:</h4>";
try {
    $query = "SHOW TABLES LIKE 'transactions'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        echo "<p style='color: green;'>✓ transactions table EXISTS</p>";
    } else {
        echo "<p style='color: red;'>✗ transactions table MISSING - Run run-admin-setup.php</p>";
    }
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Error: " . $e->getMessage() . "</p>";
}

// Test 2: Users query
echo "<h4>2. Total Users Query:</h4>";
try {
    $query = "SELECT COUNT(*) as total FROM users WHERE active = 1";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $totalUsers = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "<p style='color: green;'>✓ Total Users: $totalUsers</p>";
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Error: " . $e->getMessage() . "</p>";
}

// Test 3: Notes query
echo "<h4>3. Total Notes Query:</h4>";
try {
    $query = "SELECT COUNT(*) as total FROM notes";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $totalNotes = $stmt->fetch(PDO::FETCH_ASSOC)['total'];
    echo "<p style='color: green;'>✓ Total Notes: $totalNotes</p>";
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Error: " . $e->getMessage() . "</p>";
}

// Test 4: Transactions query (this is likely the problem)
echo "<h4>4. Transactions Query:</h4>";
try {
    $query = "SELECT COUNT(*) as total, SUM(amount) as total_amount FROM transactions WHERE status = 'completed'";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $transactionStats = $stmt->fetch(PDO::FETCH_ASSOC);
    $totalTransactions = $transactionStats['total'];
    $totalRevenue = $transactionStats['total_amount'] ?? 0;
    echo "<p style='color: green;'>✓ Total Transactions: $totalTransactions</p>";
    echo "<p style='color: green;'>✓ Total Revenue: $totalRevenue</p>";
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Error querying transactions: " . $e->getMessage() . "</p>";
    echo "<p style='color: orange;'>⚠ You need to create the transactions table!</p>";
}

// Test 5: Top sellers query
echo "<h4>5. Top Sellers Query:</h4>";
try {
    $query = "SELECT u.id, u.username, u.avatar, u.earnings, COUNT(DISTINCT n.id) as notes_count
              FROM users u
              LEFT JOIN notes n ON u.id = n.user_id
              WHERE u.active = 1
              GROUP BY u.id, u.username, u.avatar, u.earnings
              ORDER BY u.earnings DESC
              LIMIT 5";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $topSellers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<p style='color: green;'>✓ Top Sellers Query: " . count($topSellers) . " sellers</p>";
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Error: " . $e->getMessage() . "</p>";
}

// Test 6: Recent transactions query
echo "<h4>6. Recent Transactions Query:</h4>";
try {
    $query = "SELECT t.*, n.title as note_title, u.username as buyer_name, s.username as seller_name
              FROM transactions t
              LEFT JOIN notes n ON t.note_id = n.id
              LEFT JOIN users u ON t.user_id = u.id
              LEFT JOIN users s ON t.seller_id = s.id
              ORDER BY t.transaction_date DESC
              LIMIT 10";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $recentTransactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo "<p style='color: green;'>✓ Recent Transactions Query: " . count($recentTransactions) . " transactions</p>";
} catch(Exception $e) {
    echo "<p style='color: red;'>✗ Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h3>Actions:</h3>";
echo "<p><a href='../../run-admin-setup.php'>Run Admin Setup</a> - Creates all required tables</p>";
echo "<p><a href='../../check-db-tables.php'>Check Database Tables</a> - Verify structure</p>";
echo "<p><a href='../../admin.php'>Go to Admin Dashboard</a></p>";
?>
