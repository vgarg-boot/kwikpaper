<?php
/**
 * Admin Transactions Management API
 * GET: List all transactions
 * PUT: Update transaction (refund, status change)
 * POST: Export transactions
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, PUT, POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../auth/admin-auth.php';

// Require admin authentication
requireAdmin();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch($method) {
        case 'GET':
            handleGetTransactions($db);
            break;
        case 'PUT':
            handleUpdateTransaction($db);
            break;
        case 'POST':
            handleExportTransactions($db);
            break;
        default:
            http_response_code(405);
            echo json_encode(["success" => false, "message" => "Method not allowed"]);
    }
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Server error: " . $e->getMessage()
    ]);
}

function handleGetTransactions($db) {
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $status = isset($_GET['status']) ? $_GET['status'] : 'all';
    $dateFrom = isset($_GET['date_from']) ? $_GET['date_from'] : '';
    $dateTo = isset($_GET['date_to']) ? $_GET['date_to'] : '';
    $sellerId = isset($_GET['seller_id']) ? intval($_GET['seller_id']) : 0;
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;
    $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
    
    $query = "SELECT t.*, 
                     n.title as note_title, n.category,
                     u.username as buyer_name, u.email as buyer_email,
                     s.username as seller_name, s.email as seller_email
              FROM transactions t
              LEFT JOIN notes n ON t.note_id = n.id
              LEFT JOIN users u ON t.user_id = u.id
              LEFT JOIN users s ON t.seller_id = s.id
              WHERE 1=1";
    
    $params = [];
    
    if ($search !== '') {
        $query .= " AND (t.transaction_id LIKE :search OR n.title LIKE :search OR u.username LIKE :search OR s.username LIKE :search)";
        $params[':search'] = "%$search%";
    }
    
    if ($status !== 'all') {
        $query .= " AND t.status = :status";
        $params[':status'] = $status;
    }
    
    if ($sellerId > 0) {
        $query .= " AND t.seller_id = :seller_id";
        $params[':seller_id'] = $sellerId;
    }
    
    if ($dateFrom !== '') {
        $query .= " AND t.transaction_date >= :date_from";
        $params[':date_from'] = $dateFrom;
    }
    
    if ($dateTo !== '') {
        $query .= " AND t.transaction_date <= :date_to";
        $params[':date_to'] = $dateTo . ' 23:59:59';
    }
    
    $query .= " ORDER BY t.transaction_date DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count and sum
    $countQuery = "SELECT COUNT(*) as total, SUM(amount) as total_amount FROM transactions t 
                   LEFT JOIN notes n ON t.note_id = n.id
                   LEFT JOIN users u ON t.user_id = u.id
                   LEFT JOIN users s ON t.seller_id = s.id
                   WHERE 1=1";
    
    if ($search !== '') {
        $countQuery .= " AND (t.transaction_id LIKE :search OR n.title LIKE :search OR u.username LIKE :search OR s.username LIKE :search)";
    }
    if ($status !== 'all') {
        $countQuery .= " AND t.status = :status";
    }
    if ($dateFrom !== '') {
        $countQuery .= " AND t.transaction_date >= :date_from";
    }
    if ($dateTo !== '') {
        $countQuery .= " AND t.transaction_date <= :date_to";
    }
    
    $countStmt = $db->prepare($countQuery);
    foreach ($params as $key => $value) {
        if (strpos($key, 'limit') === false && strpos($key, 'offset') === false) {
            $countStmt->bindValue($key, $value);
        }
    }
    $countStmt->execute();
    $countData = $countStmt->fetch(PDO::FETCH_ASSOC);
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "total" => intval($countData['total']),
        "total_amount" => number_format($countData['total_amount'] ?? 0, 2),
        "count" => count($transactions),
        "data" => $transactions
    ]);
}

function handleUpdateTransaction($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!isset($data->transaction_id)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "Transaction ID is required"]);
        return;
    }
    
    $updates = [];
    $params = [':transaction_id' => $data->transaction_id];
    
    if (isset($data->status)) {
        $updates[] = "status = :status";
        $params[':status'] = $data->status;
        
        if ($data->status === 'refunded') {
            $updates[] = "refund_date = NOW()";
            if (isset($data->refund_reason)) {
                $updates[] = "refund_reason = :refund_reason";
                $params[':refund_reason'] = $data->refund_reason;
            }
        }
    }
    
    if (isset($data->notes)) {
        $updates[] = "notes = :notes";
        $params[':notes'] = $data->notes;
    }
    
    if (empty($updates)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "No fields to update"]);
        return;
    }
    
    $query = "UPDATE transactions SET " . implode(", ", $updates) . " WHERE id = :transaction_id";
    $stmt = $db->prepare($query);
    
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    if ($stmt->execute()) {
        // Log admin action
        logAdminAction($db, $_SESSION['user_id'], 'update_transaction', 'transaction', $data->transaction_id, 
                      "Updated transaction: " . implode(", ", array_keys((array)$data)));
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Transaction updated successfully"
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Failed to update transaction"
        ]);
    }
}

function handleExportTransactions($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    $dateFrom = isset($data->date_from) ? $data->date_from : '';
    $dateTo = isset($data->date_to) ? $data->date_to : '';
    
    $query = "SELECT t.transaction_id, t.transaction_date, t.amount, t.currency, t.status,
                     n.title as note_title, n.category,
                     u.username as buyer, s.username as seller,
                     t.seller_earnings, t.platform_fee
              FROM transactions t
              LEFT JOIN notes n ON t.note_id = n.id
              LEFT JOIN users u ON t.user_id = u.id
              LEFT JOIN users s ON t.seller_id = s.id
              WHERE 1=1";
    
    $params = [];
    
    if ($dateFrom !== '') {
        $query .= " AND t.transaction_date >= :date_from";
        $params[':date_from'] = $dateFrom;
    }
    
    if ($dateTo !== '') {
        $query .= " AND t.transaction_date <= :date_to";
        $params[':date_to'] = $dateTo . ' 23:59:59';
    }
    
    $query .= " ORDER BY t.transaction_date DESC";
    
    $stmt = $db->prepare($query);
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->execute();
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Log admin action
    logAdminAction($db, $_SESSION['user_id'], 'export_transactions', 'transaction', null, 
                  "Exported " . count($transactions) . " transactions");
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "count" => count($transactions),
        "data" => $transactions
    ]);
}
?>
