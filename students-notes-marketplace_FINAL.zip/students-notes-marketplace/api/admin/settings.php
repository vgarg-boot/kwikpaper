<?php
/**
 * Admin Settings Management API
 * GET: Get all settings
 * PUT: Update settings
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, PUT");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../auth/admin-auth.php';

// Require admin authentication
requireAdmin();

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch($method) {
        case 'GET':
            handleGetSettings($db);
            break;
        case 'PUT':
            handleUpdateSettings($db);
            break;
        default:
            http_response_code(405);
            echo json_encode(["success" => false, "message" => "Method not allowed"]);
    }
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Server error: " . $e->getMessage()
    ]);
}

function handleGetSettings($db) {
    $query = "SELECT * FROM system_settings ORDER BY setting_key";
    $stmt = $db->prepare($query);
    $stmt->execute();
    $settings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Convert to key-value format
    $settingsData = [];
    foreach ($settings as $setting) {
        $settingsData[$setting['setting_key']] = [
            'value' => $setting['setting_value'],
            'description' => $setting['description'],
            'updated_at' => $setting['updated_at']
        ];
    }
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "data" => $settingsData
    ]);
}

function handleUpdateSettings($db) {
    $data = json_decode(file_get_contents("php://input"));
    
    if (!isset($data->settings) || !is_object($data->settings)) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "Settings object is required"]);
        return;
    }
    
    $db->beginTransaction();
    
    try {
        foreach ($data->settings as $key => $value) {
            $query = "UPDATE system_settings SET setting_value = :value WHERE setting_key = :key";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':value', $value);
            $stmt->bindParam(':key', $key);
            $stmt->execute();
        }
        
        $db->commit();
        
        // Log admin action
        logAdminAction($db, $_SESSION['user_id'], 'update_settings', 'system', null, 
                      "Updated settings: " . implode(", ", array_keys((array)$data->settings)));
        
        http_response_code(200);
        echo json_encode([
            "success" => true,
            "message" => "Settings updated successfully"
        ]);
    } catch(Exception $e) {
        $db->rollBack();
        http_response_code(500);
        echo json_encode([
            "success" => false,
            "message" => "Failed to update settings: " . $e->getMessage()
        ]);
    }
}
?>
