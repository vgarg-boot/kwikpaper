<?php
/**
 * Admin Activity Logs API
 * GET: Retrieve admin activity logs
 */

session_start();

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../auth/admin-auth.php';

// Require admin authentication
requireAdmin();

$database = new Database();
$db = $database->getConnection();

try {
    $action = isset($_GET['action']) ? $_GET['action'] : 'all';
    $targetType = isset($_GET['target_type']) ? $_GET['target_type'] : 'all';
    $adminId = isset($_GET['admin_id']) ? $_GET['admin_id'] : 'all';
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 100;
    $offset = isset($_GET['offset']) ? intval($_GET['offset']) : 0;
    
    $query = "SELECT l.*, u.username as admin_username, u.avatar as admin_avatar
              FROM admin_logs l
              LEFT JOIN users u ON l.admin_id = u.id
              WHERE 1=1";
    
    $params = [];
    
    if ($action !== 'all') {
        $query .= " AND l.action = :action";
        $params[':action'] = $action;
    }
    
    if ($targetType !== 'all') {
        $query .= " AND l.target_type = :target_type";
        $params[':target_type'] = $targetType;
    }
    
    if ($adminId !== 'all') {
        $query .= " AND l.admin_id = :admin_id";
        $params[':admin_id'] = $adminId;
    }
    
    $query .= " ORDER BY l.created_at DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $db->prepare($query);
    
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count
    $countQuery = "SELECT COUNT(*) as total FROM admin_logs l WHERE 1=1";
    if ($action !== 'all') {
        $countQuery .= " AND l.action = :action";
    }
    if ($targetType !== 'all') {
        $countQuery .= " AND l.target_type = :target_type";
    }
    if ($adminId !== 'all') {
        $countQuery .= " AND l.admin_id = :admin_id";
    }
    
    $countStmt = $db->prepare($countQuery);
    foreach ($params as $key => $value) {
        if (strpos($key, 'limit') === false && strpos($key, 'offset') === false) {
            $countStmt->bindValue($key, $value);
        }
    }
    $countStmt->execute();
    $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "total" => intval($total),
        "count" => count($logs),
        "data" => $logs
    ]);
    
} catch(Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error fetching activity logs: " . $e->getMessage()
    ]);
}
?>
