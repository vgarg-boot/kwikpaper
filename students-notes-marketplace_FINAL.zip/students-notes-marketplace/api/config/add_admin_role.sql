-- Add Admin Role Support to Users Table
-- Run this script to enable admin functionality

USE notes_marketplace;

-- Add role column to users table
ALTER TABLE users 
ADD COLUMN role ENUM('user', 'admin') DEFAULT 'user' AFTER active;

-- Create index on role for faster queries
ALTER TABLE users ADD INDEX idx_role (role);

-- Update an existing user to admin (change username as needed)
-- Uncomment and modify the line below to set an admin user
-- UPDATE users SET role = 'admin' WHERE username = 'admin' OR email = 'admin@example.com';

-- Create admin activity logs table
CREATE TABLE IF NOT EXISTS admin_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    action VARCHAR(100) NOT NULL,
    target_type ENUM('user', 'note', 'transaction', 'system') NOT NULL,
    target_id INT,
    details TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_admin_id (admin_id),
    INDEX idx_action (action),
    INDEX idx_target_type (target_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add system settings table
CREATE TABLE IF NOT EXISTS system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_setting_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert default system settings
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('site_name', 'Student Notes Marketplace', 'Name of the marketplace'),
('platform_fee_percentage', '10', 'Platform fee percentage on sales'),
('require_note_approval', '0', 'Whether notes need admin approval (1 = yes, 0 = no)'),
('max_upload_size_mb', '50', 'Maximum file upload size in MB'),
('enable_free_notes', '1', 'Allow users to upload free notes (1 = yes, 0 = no)')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- Success message
SELECT 'Admin role support has been added successfully!' as message;
