-- Add is_free column to notes table
-- Run this to add free/paid functionality

USE notes_marketplace;

-- Add is_free column (default FALSE means it's a paid note)
ALTER TABLE notes 
ADD COLUMN is_free TINYINT(1) DEFAULT 0 AFTER price;

-- Update existing notes to be paid (if needed)
-- UPDATE notes SET is_free = 0 WHERE is_free IS NULL;

-- Add index for quick filtering of free notes
ALTER TABLE notes ADD INDEX idx_is_free (is_free);
