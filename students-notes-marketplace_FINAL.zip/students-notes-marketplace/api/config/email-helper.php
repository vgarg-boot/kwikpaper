<?php
/**
 * Email Helper Class
 * Handles sending emails for verification, notifications, etc.
 */

require_once __DIR__ . '/email.php';

class EmailHelper {
    
    /**
     * Send an email using PHP mail function
     */
    public static function sendEmail($to, $subject, $message, $headers = []) {
        // Default headers
        $default_headers = [
            'MIME-Version' => '1.0',
            'Content-type' => 'text/html; charset=UTF-8',
            'From' => EmailConfig::$from_name . ' <' . EmailConfig::$from_email . '>',
            'Reply-To' => EmailConfig::$from_email,
            'X-Mailer' => 'PHP/' . phpversion()
        ];
        
        // Merge headers
        $headers = array_merge($default_headers, $headers);
        
        // Format headers for mail()
        $headers_string = '';
        foreach ($headers as $key => $value) {
            $headers_string .= $key . ': ' . $value . "\r\n";
        }
        
        // Send email
        try {
            $result = mail($to, $subject, $message, $headers_string);
            return $result;
        } catch (Exception $e) {
            error_log('Email sending failed: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Send verification email to new user
     */
    public static function sendVerificationEmail($email, $username, $token) {
        $verification_link = EmailConfig::$base_url . '/api/auth/verify-email.php?token=' . $token;
        
        $subject = 'Verify Your Email - KwikPaper';
        
        $message = self::getVerificationEmailTemplate($username, $verification_link);
        
        return self::sendEmail($email, $subject, $message);
    }
    
    /**
     * Send welcome email after verification
     */
    public static function sendWelcomeEmail($email, $username) {
        $subject = 'Welcome to KwikPaper!';
        
        $message = self::getWelcomeEmailTemplate($username);
        
        return self::sendEmail($email, $subject, $message);
    }

    /**
     * Send password reset email
     */
    public static function sendPasswordResetEmail($email, $username, $token) {
        $reset_link = EmailConfig::$base_url . '/reset-password.php?token=' . urlencode($token);

        $subject = 'Reset Your Password - KwikPaper';
        $message = self::getPasswordResetEmailTemplate($username, $reset_link);

        return self::sendEmail($email, $subject, $message);
    }
    
    /**
     * Get verification email template
     */
    private static function getVerificationEmailTemplate($username, $verification_link) {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Email Verification</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    max-width: 600px;
                    margin: 40px auto;
                    background-color: #ffffff;
                    padding: 0;
                    border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    overflow: hidden;
                }
                .header {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    padding: 40px 20px;
                    text-align: center;
                    color: white;
                }
                .header h1 {
                    margin: 0;
                    font-size: 32px;
                }
                .content {
                    padding: 40px 30px;
                    color: #333;
                    line-height: 1.6;
                }
                .button {
                    display: inline-block;
                    padding: 15px 40px;
                    margin: 20px 0;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    text-decoration: none;
                    border-radius: 5px;
                    font-weight: bold;
                }
                .footer {
                    padding: 20px 30px;
                    background-color: #f8f9fa;
                    text-align: center;
                    color: #6c757d;
                    font-size: 12px;
                }
                .warning {
                    background-color: #fff3cd;
                    border-left: 4px solid #ffc107;
                    padding: 15px;
                    margin: 20px 0;
                    color: #856404;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>📚 KwikPaper</h1>
                </div>
                <div class="content">
                    <h2>Hi ' . htmlspecialchars($username) . ',</h2>
                    <p>Welcome to <strong>KwikPaper</strong>! We\'re excited to have you join our community of students sharing and accessing quality study notes.</p>
                    
                    <p>To complete your registration and start using your account, please verify your email address by clicking the button below:</p>
                    
                    <div style="text-align: center;">
                        <a href="' . $verification_link . '" class="button">Verify Email Address</a>
                    </div>
                    
                    <p>Or copy and paste this link into your browser:</p>
                    <p style="word-break: break-all; color: #667eea;"><a href="' . $verification_link . '">' . $verification_link . '</a></p>
                    
                    <div class="warning">
                        <strong>⚠️ Important:</strong> This verification link will expire in ' . EmailConfig::$verification_token_expiry . ' hours. If you didn\'t create an account on KwikPaper, you can safely ignore this email.
                    </div>
                    
                    <p>Once verified, you\'ll be able to:</p>
                    <ul>
                        <li>📝 Upload and share your study notes</li>
                        <li>🎓 Access quality notes from other students</li>
                        <li>💰 Earn money from your study materials</li>
                    </ul>
                    
                    <p>If you have any questions, feel free to reach out to our support team.</p>
                    
                    <p>Best regards,<br>The KwikPaper Team</p>
                </div>
                <div class="footer">
                    <p>&copy; ' . date('Y') . ' KwikPaper. All rights reserved.</p>
                    <p>This is an automated email. Please do not reply to this message.</p>
                </div>
            </div>
        </body>
        </html>
        ';
    }
    
    /**
     * Get welcome email template
     */
    private static function getWelcomeEmailTemplate($username) {
        $dashboard_link = EmailConfig::$base_url . '/dashboard.php';
        
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Welcome to KwikPaper</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    max-width: 600px;
                    margin: 40px auto;
                    background-color: #ffffff;
                    padding: 0;
                    border-radius: 8px;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    overflow: hidden;
                }
                .header {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    padding: 40px 20px;
                    text-align: center;
                    color: white;
                }
                .header h1 {
                    margin: 0;
                    font-size: 32px;
                }
                .content {
                    padding: 40px 30px;
                    color: #333;
                    line-height: 1.6;
                }
                .button {
                    display: inline-block;
                    padding: 15px 40px;
                    margin: 20px 0;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    text-decoration: none;
                    border-radius: 5px;
                    font-weight: bold;
                }
                .footer {
                    padding: 20px 30px;
                    background-color: #f8f9fa;
                    text-align: center;
                    color: #6c757d;
                    font-size: 12px;
                }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>🎉 Welcome to KwikPaper!</h1>
                </div>
                <div class="content">
                    <h2>Hi ' . htmlspecialchars($username) . ',</h2>
                    <p>Your email has been successfully verified! You\'re now a full member of the KwikPaper community.</p>
                    
                    <p>Get started by:</p>
                    <ul>
                        <li>Completing your profile</li>
                        <li>Browsing available study notes</li>
                        <li>Uploading your first notes to start earning</li>
                    </ul>
                    
                    <div style="text-align: center;">
                        <a href="' . $dashboard_link . '" class="button">Go to Dashboard</a>
                    </div>
                    
                    <p>Happy studying and sharing!</p>
                    
                    <p>Best regards,<br>The KwikPaper Team</p>
                </div>
                <div class="footer">
                    <p>&copy; ' . date('Y') . ' KwikPaper. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ';
    }

    /**
     * Get password reset email template
     */
    private static function getPasswordResetEmailTemplate($username, $reset_link) {
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Password Reset</title>
            <style>
                body { font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 0; }
                .container { max-width: 600px; margin: 40px auto; background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); overflow: hidden; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 32px 20px; text-align: center; color: white; }
                .content { padding: 30px; color: #333; line-height: 1.6; }
                .button { display: inline-block; padding: 12px 30px; margin: 20px 0; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; text-decoration: none; border-radius: 6px; font-weight: bold; }
                .warning { background-color: #fff3cd; border-left: 4px solid #ffc107; padding: 12px; margin: 16px 0; color: #856404; }
                .footer { padding: 16px 30px; background-color: #f8f9fa; text-align: center; color: #6c757d; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header"><h1>🔐 Password Reset</h1></div>
                <div class="content">
                    <h2>Hi ' . htmlspecialchars($username) . ',</h2>
                    <p>We received a request to reset your KwikPaper account password.</p>
                    <div style="text-align:center;">
                        <a href="' . $reset_link . '" class="button">Reset Password</a>
                    </div>
                    <p>Or open this link in your browser:</p>
                    <p style="word-break: break-all;"><a href="' . $reset_link . '">' . $reset_link . '</a></p>
                    <div class="warning"><strong>Important:</strong> This link expires in 1 hour. If you did not request this, you can ignore this email.</div>
                    <p>Best regards,<br>The KwikPaper Team</p>
                </div>
                <div class="footer">
                    <p>&copy; ' . date('Y') . ' KwikPaper. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ';
    }
}
?>
