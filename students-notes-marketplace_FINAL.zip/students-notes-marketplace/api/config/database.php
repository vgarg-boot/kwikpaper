<?php
/**
 * Database Configuration for External MySQL
 * Update these values according to your MySQL setup
 */

class Database {
    // External MySQL Configuration
    private $host = "127.0.0.1";        // Use 127.0.0.1 for external MySQL
    private $port = "3306";              // Default MySQL port (change if different)
    private $db_name = "notes_marketplace";
    private $username = "root";
    private $password = "password";      // Your MySQL root password
    private $charset = "utf8mb4";
    public $conn;

    /**
     * Get database connection (External MySQL)
     */
    public function getConnection() {
        $this->conn = null;

        try {
            // Build DSN for external MySQL with port and charset
            $dsn = "mysql:host=" . $this->host . 
                   ";port=" . $this->port . 
                   ";dbname=" . $this->db_name . 
                   ";charset=" . $this->charset;
            
            $this->conn = new PDO($dsn, $this->username, $this->password);
            
            // Set PDO attributes
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
        } catch(PDOException $exception) {
            // Log error instead of echoing (prevents headers already sent errors)
            error_log("Database Connection Error: " . $exception->getMessage());
            
            // Return null so calling code can handle it
            return null;
        }

        return $this->conn;
    }
}
?>
