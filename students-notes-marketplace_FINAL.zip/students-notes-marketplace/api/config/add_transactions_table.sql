-- Add Transactions Table for PayPal Payment Tracking
-- Run this script to add payment tracking functionality

USE notes_marketplace;

-- Transactions Table
CREATE TABLE IF NOT EXISTS transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id VARCHAR(255) UNIQUE NOT NULL,
    paypal_order_id VARCHAR(255),
    paypal_payer_id VARCHAR(255),
    user_id INT NOT NULL,
    note_id INT NOT NULL,
    seller_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    status ENUM('pending', 'completed', 'failed', 'refunded') DEFAULT 'pending',
    payment_method VARCHAR(50) DEFAULT 'paypal',
    payer_email VARCHAR(100),
    payer_name VARCHAR(100),
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_date TIMESTAMP NULL,
    refund_date TIMESTAMP NULL,
    refund_reason TEXT,
    seller_earnings DECIMAL(10, 2),
    platform_fee DECIMAL(10, 2),
    notes TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (note_id) REFERENCES notes(id) ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_transaction_id (transaction_id),
    INDEX idx_user_id (user_id),
    INDEX idx_seller_id (seller_id),
    INDEX idx_note_id (note_id),
    INDEX idx_status (status),
    INDEX idx_transaction_date (transaction_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Add payment columns to purchases table
-- Note: If columns already exist, you may see errors - this is safe to ignore
ALTER TABLE purchases 
ADD COLUMN transaction_id VARCHAR(255) AFTER amount;

ALTER TABLE purchases 
ADD COLUMN payment_status ENUM('free', 'paid') DEFAULT 'free' AFTER transaction_id;

-- Update existing purchases with payment status
UPDATE purchases SET payment_status = 'paid' WHERE amount > 0;
UPDATE purchases SET payment_status = 'free' WHERE amount = 0;

-- Create index on transaction_id
-- Note: If index already exists, you may see an error - this is safe to ignore
ALTER TABLE purchases ADD INDEX idx_transaction_id (transaction_id);

-- Sample comment
-- After running this script, your system will be ready for PayPal payment integration
