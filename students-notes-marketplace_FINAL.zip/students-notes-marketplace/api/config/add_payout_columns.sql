-- Add payout tracking columns to transactions table
-- Run this script to add seller payout functionality

USE notes_marketplace;

-- Add payout tracking columns
ALTER TABLE transactions 
ADD COLUMN payout_status ENUM('unpaid', 'paid') DEFAULT 'unpaid' AFTER platform_fee;

ALTER TABLE transactions 
ADD COLUMN payout_date TIMESTAMP NULL AFTER payout_status;

ALTER TABLE transactions 
ADD COLUMN payout_method VARCHAR(50) NULL AFTER payout_date;

ALTER TABLE transactions 
ADD COLUMN payout_reference VARCHAR(255) NULL AFTER payout_method;

ALTER TABLE transactions 
ADD COLUMN payout_notes TEXT NULL AFTER payout_reference;

-- Add index for faster queries
ALTER TABLE transactions ADD INDEX idx_payout_status (payout_status);
ALTER TABLE transactions ADD INDEX idx_payout_date (payout_date);

-- Sample comment
-- After running this script, admins can track seller payouts
