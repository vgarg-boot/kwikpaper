<?php
/**
 * Email Configuration
 * Configure email sending settings for the application
 */

class EmailConfig {
    // Email sending method: 'mail' (PHP mail()) or 'smtp' (for PHPMailer)
    public static $method = 'mail';
    
    // From email address
    public static $from_email = 'noreply@kwikpaper.com';
    public static $from_name = 'KwikPaper';
    
    // Base URL of your application (update this to your actual domain)
    public static $base_url = 'http://localhost/students-notes-marketplace';
    
    // SMTP Settings (if using PHPMailer)
    public static $smtp_host = 'smtp.gmail.com';
    public static $smtp_port = 587;
    public static $smtp_username = 'your-email@gmail.com';
    public static $smtp_password = 'your-app-password';
    public static $smtp_secure = 'tls'; // 'tls' or 'ssl'
    
    // Email verification settings
    public static $verification_token_expiry = 24; // hours
    public static $require_verification = true; // Set to false to allow login without verification
}
?>
