-- Add email verification columns to users table

USE notes_marketplace;

-- Add email verification columns
-- Note: If columns already exist, you'll get an error which can be safely ignored

-- Add email_verified column
ALTER TABLE users 
ADD COLUMN email_verified TINYINT(1) DEFAULT 0 AFTER active;

-- Add verification_token column
ALTER TABLE users 
ADD COLUMN verification_token VARCHAR(64) NULL AFTER email_verified;

-- Add verification_token_expires column
ALTER TABLE users 
ADD COLUMN verification_token_expires TIMESTAMP NULL AFTER verification_token;

-- Add verification_sent_at column
ALTER TABLE users
ADD COLUMN verification_sent_at TIMESTAMP NULL AFTER verification_token_expires;

-- Add index for faster token lookups
ALTER TABLE users 
ADD INDEX idx_verification_token (verification_token);

SELECT 'Email verification columns added successfully!' as status;
