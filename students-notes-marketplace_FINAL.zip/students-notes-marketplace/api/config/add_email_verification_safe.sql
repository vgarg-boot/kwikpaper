-- Add email verification columns to users table (Safe version)
-- This version checks if columns exist before adding them

USE notes_marketplace;

DELIMITER $$

-- Procedure to safely add columns
DROP PROCEDURE IF EXISTS add_email_verification_columns$$

CREATE PROCEDURE add_email_verification_columns()
BEGIN
    -- Check and add email_verified column
    IF NOT EXISTS (
        SELECT * FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = 'notes_marketplace' 
        AND TABLE_NAME = 'users' 
        AND COLUMN_NAME = 'email_verified'
    ) THEN
        ALTER TABLE users ADD COLUMN email_verified TINYINT(1) DEFAULT 0 AFTER active;
        SELECT 'Added email_verified column' AS message;
    ELSE
        SELECT 'email_verified column already exists' AS message;
    END IF;
    
    -- Check and add verification_token column
    IF NOT EXISTS (
        SELECT * FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = 'notes_marketplace' 
        AND TABLE_NAME = 'users' 
        AND COLUMN_NAME = 'verification_token'
    ) THEN
        ALTER TABLE users ADD COLUMN verification_token VARCHAR(64) NULL AFTER email_verified;
        SELECT 'Added verification_token column' AS message;
    ELSE
        SELECT 'verification_token column already exists' AS message;
    END IF;
    
    -- Check and add verification_token_expires column
    IF NOT EXISTS (
        SELECT * FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = 'notes_marketplace' 
        AND TABLE_NAME = 'users' 
        AND COLUMN_NAME = 'verification_token_expires'
    ) THEN
        ALTER TABLE users ADD COLUMN verification_token_expires TIMESTAMP NULL AFTER verification_token;
        SELECT 'Added verification_token_expires column' AS message;
    ELSE
        SELECT 'verification_token_expires column already exists' AS message;
    END IF;
    
    -- Check and add verification_sent_at column
    IF NOT EXISTS (
        SELECT * FROM information_schema.COLUMNS 
        WHERE TABLE_SCHEMA = 'notes_marketplace' 
        AND TABLE_NAME = 'users' 
        AND COLUMN_NAME = 'verification_sent_at'
    ) THEN
        ALTER TABLE users ADD COLUMN verification_sent_at TIMESTAMP NULL AFTER verification_token_expires;
        SELECT 'Added verification_sent_at column' AS message;
    ELSE
        SELECT 'verification_sent_at column already exists' AS message;
    END IF;
    
    -- Check and add index
    IF NOT EXISTS (
        SELECT * FROM information_schema.STATISTICS 
        WHERE TABLE_SCHEMA = 'notes_marketplace' 
        AND TABLE_NAME = 'users' 
        AND INDEX_NAME = 'idx_verification_token'
    ) THEN
        ALTER TABLE users ADD INDEX idx_verification_token (verification_token);
        SELECT 'Added idx_verification_token index' AS message;
    ELSE
        SELECT 'idx_verification_token index already exists' AS message;
    END IF;
    
    SELECT 'Email verification setup complete!' AS status;
END$$

DELIMITER ;

-- Execute the procedure
CALL add_email_verification_columns();

-- Clean up: Drop the procedure after use
DROP PROCEDURE IF EXISTS add_email_verification_columns;
