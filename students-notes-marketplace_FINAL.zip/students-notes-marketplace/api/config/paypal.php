<?php
/**
 * PayPal Configuration
 * Configure your PayPal API credentials here
 * 
 * IMPORTANT: Get your credentials from https://developer.paypal.com/
 * For Testing: Use Sandbox credentials
 * For Production: Use Live credentials
 */

class PayPalConfig {
    // PayPal Mode: 'sandbox' for testing, 'live' for production
    const MODE = 'sandbox';
    
    // Sandbox Credentials (for testing)
    const SANDBOX_CLIENT_ID = 'AYIZicVAZbPWYq4TAaD51etqs0z62MXFppUFlyrNqzBmzFuf_4Gj60Ff7g-qv4W9QIEJ31VPwzeVsLd2';
    const SANDBOX_CLIENT_SECRET = 'EN9mN1s7kHJXxMbcJeisXp2k5KiKLeTftuYIOUGl5DrwdtvmgyUjQpUWVFH2tUKvTmgV-MoPPlBhTFL0';
    
    // Live Credentials (for production)
    const LIVE_CLIENT_ID = 'YOUR_LIVE_CLIENT_ID_HERE';
    const LIVE_CLIENT_SECRET = 'YOUR_LIVE_CLIENT_SECRET_HERE';
    
    // Currency
    const CURRENCY = 'USD';
    
    // Platform Fee (percentage taken from each sale)
    const PLATFORM_FEE_PERCENTAGE = 10; // 10% platform fee
    
    // PayPal API URLs
    const SANDBOX_API_URL = 'https://api-m.sandbox.paypal.com';
    const LIVE_API_URL = 'https://api-m.paypal.com';
    
    // Return URLs (used by PayPal to redirect back)
    const SUCCESS_URL = 'http://localhost/students-notes-marketplace/payment-success.php';
    const CANCEL_URL = 'http://localhost/students-notes-marketplace/payment-cancel.php';
    
    /**
     * Get current client ID based on mode
     */
    public static function getClientId() {
        return self::MODE === 'sandbox' ? self::SANDBOX_CLIENT_ID : self::LIVE_CLIENT_ID;
    }
    
    /**
     * Get current client secret based on mode
     */
    public static function getClientSecret() {
        return self::MODE === 'sandbox' ? self::SANDBOX_CLIENT_SECRET : self::LIVE_CLIENT_SECRET;
    }
    
    /**
     * Get API base URL based on mode
     */
    public static function getApiUrl() {
        return self::MODE === 'sandbox' ? self::SANDBOX_API_URL : self::LIVE_API_URL;
    }
    
    /**
     * Calculate platform fee
     */
    public static function calculatePlatformFee($amount) {
        return round(($amount * self::PLATFORM_FEE_PERCENTAGE) / 100, 2);
    }
    
    /**
     * Calculate seller earnings after platform fee
     */
    public static function calculateSellerEarnings($amount) {
        return round($amount - self::calculatePlatformFee($amount), 2);
    }
    
    /**
     * Get access token from PayPal
     */
    public static function getAccessToken() {
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => self::getApiUrl() . '/v1/oauth2/token',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_USERPWD => self::getClientId() . ':' . self::getClientSecret(),
            CURLOPT_POSTFIELDS => 'grant_type=client_credentials',
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Accept-Language: en_US'
            ],
            CURLOPT_SSL_VERIFYPEER => false, // For localhost testing
            CURLOPT_SSL_VERIFYHOST => false  // For localhost testing
        ]);
        
        $response = curl_exec($ch);
        $curlError = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        // Check for cURL errors
        if ($curlError) {
            error_log('PayPal cURL Error: ' . $curlError);
            return ['error' => 'CURL_ERROR', 'message' => $curlError];
        }
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            return $data['access_token'] ?? null;
        }
        
        // Log detailed error
        error_log('PayPal Access Token Error - HTTP ' . $httpCode . ': ' . $response);
        return ['error' => 'HTTP_' . $httpCode, 'message' => $response];
    }
    
    /**
     * Validate PayPal configuration
     */
    public static function isConfigured() {
        $clientId = self::getClientId();
        $clientSecret = self::getClientSecret();
        
        return !empty($clientId) && 
               $clientId !== 'YOUR_SANDBOX_CLIENT_ID_HERE' && 
               $clientId !== 'YOUR_LIVE_CLIENT_ID_HERE' &&
               !empty($clientSecret) &&
               $clientSecret !== 'YOUR_SANDBOX_CLIENT_SECRET_HERE' &&
               $clientSecret !== 'YOUR_LIVE_CLIENT_SECRET_HERE';
    }
}
?>
