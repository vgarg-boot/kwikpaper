<?php
/**
 * Run Email Verification Migration
 * POST: api/config/run-migration.php
 */

header("Content-Type: application/json; charset=UTF-8");

include_once 'database.php';

try {
    $database = new Database();
    $db = $database->getConnection();
    
    // Read SQL file - use safe version if it exists, otherwise use regular version
    $sql_file_safe = __DIR__ . '/add_email_verification_safe.sql';
    $sql_file = __DIR__ . '/add_email_verification.sql';
    
    if (file_exists($sql_file_safe)) {
        $file_to_use = $sql_file_safe;
    } elseif (file_exists($sql_file)) {
        $file_to_use = $sql_file;
    } else {
        throw new Exception("Migration file not found");
    }
    
    $sql = file_get_contents($file_to_use);
    
    // For safe version (with procedures), execute as is
    if ($file_to_use === $sql_file_safe) {
        // Remove USE statement
        $sql = preg_replace('/USE\s+[^;]+;/i', '', $sql);
        $db->exec($sql);
    } else {
        // For regular version, split and execute individual statements
        $statements = array_filter(
            array_map('trim', explode(';', $sql)),
            function($stmt) {
                return !empty($stmt) && 
                       stripos($stmt, 'USE ') !== 0 && 
                       stripos($stmt, 'SELECT ') !== 0 &&
                       stripos($stmt, '--') !== 0;
            }
        );
        
        $errors = [];
        $success_count = 0;
        
        // Execute each statement, track errors but continue
        foreach ($statements as $statement) {
            if (!empty($statement)) {
                try {
                    $db->exec($statement);
                    $success_count++;
                } catch (PDOException $e) {
                    // Column already exists error (code 1060) is okay
                    if ($e->getCode() == '42S21' || strpos($e->getMessage(), 'Duplicate column') !== false) {
                        $errors[] = "Column already exists (this is okay)";
                    } else {
                        $errors[] = $e->getMessage();
                    }
                }
            }
        }
        
        // If we have some successes or only duplicate column errors, consider it successful
        if ($success_count > 0 || !empty($errors)) {
            if (count($errors) > 0 && $success_count == 0) {
                throw new Exception("Migration failed: " . implode("; ", $errors));
            }
        }
    }
    
    echo json_encode([
        "success" => true,
        "message" => "Database migration completed successfully! Email verification columns have been added."
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Migration failed: " . $e->getMessage()
    ]);
}
?>
