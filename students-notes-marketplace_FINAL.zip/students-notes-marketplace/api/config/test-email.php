<?php
/**
 * Test Email Sending
 * POST: api/config/test-email.php
 */

header("Content-Type: application/json; charset=UTF-8");

include_once 'email-helper.php';

// Get posted data
$data = json_decode(file_get_contents("php://input"));

if (empty($data->email)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Email address is required"
    ]);
    exit();
}

// Validate email
if (!filter_var($data->email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Invalid email address"
    ]);
    exit();
}

// Send test email
$subject = "Test Email - KwikPaper Email Verification";
$message = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Test Email</title>
</head>
<body style="font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f4;">
    <div style="max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px;">
        <h2 style="color: #667eea;">✅ Email Test Successful!</h2>
        <p>Your email configuration is working correctly.</p>
        <p>This is a test email sent from the KwikPaper email verification system.</p>
        <hr style="border: 1px solid #e9ecef; margin: 20px 0;">
        <h3>Configuration Details:</h3>
        <ul>
            <li><strong>From:</strong> ' . EmailConfig::$from_name . ' &lt;' . EmailConfig::$from_email . '&gt;</li>
            <li><strong>Method:</strong> ' . EmailConfig::$method . '</li>
            <li><strong>Base URL:</strong> ' . EmailConfig::$base_url . '</li>
            <li><strong>Verification Required:</strong> ' . (EmailConfig::$require_verification ? 'Yes' : 'No') . '</li>
            <li><strong>Token Expiry:</strong> ' . EmailConfig::$verification_token_expiry . ' hours</li>
        </ul>
        <p style="color: #6c757d; font-size: 12px; margin-top: 30px;">
            Sent: ' . date('Y-m-d H:i:s') . '<br>
            Server: ' . $_SERVER['SERVER_NAME'] . '
        </p>
    </div>
</body>
</html>
';

try {
    $result = EmailHelper::sendEmail($data->email, $subject, $message);
    
    if ($result) {
        echo json_encode([
            "success" => true,
            "message" => "Test email sent successfully to " . $data->email
        ]);
    } else {
        throw new Exception("Failed to send email. Check your email configuration.");
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ]);
}
?>
