<?php
/**
 * Update User Profile API Endpoint
 * PUT: api/user/update-profile.php
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: PUT, POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../models/User.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Authentication required. Please login."
    ]);
    exit();
}

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Validate email if provided
if(isset($data->email) && !filter_var($data->email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Invalid email format"
    ]);
    exit();
}

// Set user properties
$user->id = $_SESSION['user_id'];
$user->email = isset($data->email) ? $data->email : '';
$user->avatar = isset($data->avatar) ? $data->avatar : '👤';
$user->bio = isset($data->bio) ? $data->bio : '';
$user->university = isset($data->university) ? $data->university : '';
$user->year = isset($data->year) ? $data->year : '';
$user->subject = isset($data->subject) ? $data->subject : '';

// Update profile
if($user->updateProfile()) {
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => "Profile updated successfully"
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Unable to update profile"
    ]);
}
?>
