<?php
/**
 * Get User Profile API Endpoint
 * GET: api/user/profile.php?user_id=1
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../models/User.php';

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Get user ID from query parameter
if(!isset($_GET['user_id']) || empty($_GET['user_id'])) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "User ID is required"
    ]);
    exit();
}

$user_id = (int)$_GET['user_id'];
$userData = $user->getUserById($user_id);

if($userData) {
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "data" => $userData
    ]);
} else {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "User not found"
    ]);
}
?>
