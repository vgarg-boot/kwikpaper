<?php
/**
 * Resend Verification Email Endpoint
 * POST: api/auth/resend-verification.php
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../models/User.php';
include_once '../config/email-helper.php';

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Validate required fields
if(empty($data->email)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Email is required"
    ]);
    exit();
}

// Check if user exists
$user->email = $data->email;

$query = "SELECT id, username, email, email_verified FROM users 
          WHERE email = :email AND active = 1 LIMIT 1";
$stmt = $db->prepare($query);
$stmt->bindParam(":email", $user->email);
$stmt->execute();

if($stmt->rowCount() == 0) {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "No account found with this email address"
    ]);
    exit();
}

$row = $stmt->fetch(PDO::FETCH_ASSOC);

// Check if already verified
if($row['email_verified'] == 1) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Email is already verified. You can login now."
    ]);
    exit();
}

$user->id = $row['id'];
$user->username = $row['username'];

// Check if can resend
if(!$user->canResendVerification()) {
    http_response_code(429);
    echo json_encode([
        "success" => false,
        "message" => "Please wait at least 5 minutes before requesting another verification email"
    ]);
    exit();
}

// Generate new token
$token = $user->generateVerificationToken();

if(!$token) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Failed to generate verification token"
    ]);
    exit();
}

// Send verification email
$email_sent = EmailHelper::sendVerificationEmail(
    $user->email,
    $user->username,
    $token
);

if($email_sent) {
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => "Verification email has been sent. Please check your inbox."
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Failed to send verification email. Please try again later."
    ]);
}
?>
