<?php
/**
 * Email Verification Endpoint
 * GET: api/auth/verify-email.php?token=xxx
 */

include_once '../config/database.php';
include_once '../models/User.php';
include_once '../config/email-helper.php';

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Get token from query parameter
$token = isset($_GET['token']) ? $_GET['token'] : '';

if(empty($token)) {
    // Redirect to an error page or show message
    header('Location: ../../login.php?verification=missing_token');
    exit();
}

// Verify the email with token
$result = $user->verifyEmail($token);

if($result['success']) {
    // Send welcome email (optional)
    EmailHelper::sendWelcomeEmail($user->email, $user->username);
    
    // Redirect to login with success message
    header('Location: ../../login.php?verification=success');
    exit();
} else {
    // Redirect to login with error message
    if(strpos($result['message'], 'expired') !== false) {
        header('Location: ../../login.php?verification=expired');
    } else {
        header('Location: ../../login.php?verification=invalid');
    }
    exit();
}
?>
