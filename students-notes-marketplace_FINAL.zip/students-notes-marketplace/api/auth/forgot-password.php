<?php
/**
 * Forgot Password Endpoint
 * POST: api/auth/forgot-password.php
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../config/email-helper.php';

function ensurePasswordResetTable($db) {
    $sql = "CREATE TABLE IF NOT EXISTS password_resets (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                token_hash VARCHAR(64) NOT NULL,
                expires_at DATETIME NOT NULL,
                used_at DATETIME NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_token_hash (token_hash),
                INDEX idx_user_id (user_id),
                INDEX idx_expires_at (expires_at),
                CONSTRAINT fk_password_resets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    $db->exec($sql);
}

$database = new Database();
$db = $database->getConnection();

if (!$db) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed"
    ]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if (empty($data->email) || !filter_var($data->email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Please provide a valid email address"
    ]);
    exit();
}

$email = trim($data->email);

try {
    ensurePasswordResetTable($db);

    $query = "SELECT id, username, email FROM users WHERE email = :email AND active = 1 LIMIT 1";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        $db->beginTransaction();

        $cleanup = $db->prepare("DELETE FROM password_resets WHERE user_id = :user_id AND used_at IS NULL");
        $cleanup->bindParam(':user_id', $user['id']);
        $cleanup->execute();

        $token = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $token);
        $insert = $db->prepare("INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (:user_id, :token_hash, DATE_ADD(NOW(), INTERVAL 1 HOUR))");
        $insert->bindParam(':user_id', $user['id']);
        $insert->bindParam(':token_hash', $tokenHash);
        $insert->execute();

        $db->commit();

        $sent = EmailHelper::sendPasswordResetEmail($user['email'], $user['username'], $token);
        if (!$sent) {
            error_log('Failed to send password reset email to: ' . $user['email']);
        }
    }

    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => "If an account with that email exists, a password reset link has been sent."
    ]);
} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }

    error_log('Forgot password error: ' . $e->getMessage());

    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Unable to process password reset request"
    ]);
}
?>