<?php
/**
 * User Registration API Endpoint
 * POST: api/auth/register.php
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../models/User.php';
include_once '../config/email-helper.php';

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Validate required fields
if(empty($data->username) || empty($data->email) || empty($data->password)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "All fields are required (username, email, password)"
    ]);
    exit();
}

// Validate email format
if(!filter_var($data->email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Invalid email format"
    ]);
    exit();
}

// Validate password length
if(strlen($data->password) < 6) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Password must be at least 6 characters long"
    ]);
    exit();
}

// Set user properties
$user->username = $data->username;
$user->email = $data->email;
$user->password = $data->password;

// Check if username already exists
if($user->usernameExists()) {
    http_response_code(409);
    echo json_encode([
        "success" => false,
        "message" => "Username already exists"
    ]);
    exit();
}

// Check if email already exists
if($user->emailExists()) {
    http_response_code(409);
    echo json_encode([
        "success" => false,
        "message" => "Email already exists"
    ]);
    exit();
}

// Create user
if($user->register()) {
    // Generate verification token
    $token = $user->generateVerificationToken();
    
    if($token) {
        // Send verification email
        $email_sent = EmailHelper::sendVerificationEmail(
            $user->email,
            $user->username,
            $token
        );
        
        if($email_sent) {
            http_response_code(201);
            echo json_encode([
                "success" => true,
                "message" => "Registration successful! Please check your email to verify your account.",
                "user" => [
                    "id" => $user->id,
                    "username" => $user->username,
                    "email" => $user->email
                ],
                "verification_required" => true
            ]);
        } else {
            http_response_code(201);
            echo json_encode([
                "success" => true,
                "message" => "Registration successful! However, we couldn't send the verification email. Please try resending it.",
                "user" => [
                    "id" => $user->id,
                    "username" => $user->username,
                    "email" => $user->email
                ],
                "verification_required" => true,
                "email_error" => true
            ]);
        }
    } else {
        http_response_code(201);
        echo json_encode([
            "success" => true,
            "message" => "User registered successfully",
            "user" => [
                "id" => $user->id,
                "username" => $user->username,
                "email" => $user->email
            ]
        ]);
    }
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Unable to register user"
    ]);
}
?>
