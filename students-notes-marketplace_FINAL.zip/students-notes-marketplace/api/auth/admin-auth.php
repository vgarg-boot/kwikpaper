<?php
/**
 * Admin Authentication Middleware
 * Verifies that the current user is logged in and has admin role
 */

function requireAdmin() {
    // Start session if not already started
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    // Check if user is logged in
    if(!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode([
            "success" => false,
            "message" => "Authentication required"
        ]);
        exit();
    }
    
    // Check if user has admin role
    if(!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode([
            "success" => false,
            "message" => "Admin access required"
        ]);
        exit();
    }
    
    return true;
}

function isAdmin() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function logAdminAction($db, $admin_id, $action, $target_type, $target_id = null, $details = '') {
    try {
        $query = "INSERT INTO admin_logs (admin_id, action, target_type, target_id, details, ip_address) 
                  VALUES (:admin_id, :action, :target_type, :target_id, :details, :ip_address)";
        
        $stmt = $db->prepare($query);
        
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        
        $stmt->bindParam(':admin_id', $admin_id);
        $stmt->bindParam(':action', $action);
        $stmt->bindParam(':target_type', $target_type);
        $stmt->bindParam(':target_id', $target_id);
        $stmt->bindParam(':details', $details);
        $stmt->bindParam(':ip_address', $ip_address);
        
        $stmt->execute();
        return true;
    } catch(Exception $e) {
        error_log("Failed to log admin action: " . $e->getMessage());
        return false;
    }
}
?>
