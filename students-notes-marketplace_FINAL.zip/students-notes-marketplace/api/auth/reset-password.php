<?php
/**
 * Reset Password Endpoint
 * POST: api/auth/reset-password.php
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';

function ensurePasswordResetTable($db) {
    $sql = "CREATE TABLE IF NOT EXISTS password_resets (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                token_hash VARCHAR(64) NOT NULL,
                expires_at DATETIME NOT NULL,
                used_at DATETIME NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_token_hash (token_hash),
                INDEX idx_user_id (user_id),
                INDEX idx_expires_at (expires_at),
                CONSTRAINT fk_password_resets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

    $db->exec($sql);
}

$database = new Database();
$db = $database->getConnection();

if (!$db) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed"
    ]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if (empty($data->token) || empty($data->password) || empty($data->confirm_password)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Token, password, and confirm password are required"
    ]);
    exit();
}

$token = trim($data->token);
$password = $data->password;
$confirmPassword = $data->confirm_password;

if (strlen($password) < 6) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Password must be at least 6 characters long"
    ]);
    exit();
}

if ($password !== $confirmPassword) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Passwords do not match"
    ]);
    exit();
}

try {
    ensurePasswordResetTable($db);

    $tokenHash = hash('sha256', $token);

    $findQuery = "SELECT pr.id AS reset_id, pr.user_id
                  FROM password_resets pr
                  INNER JOIN users u ON u.id = pr.user_id
                  WHERE pr.token_hash = :token_hash
                    AND pr.used_at IS NULL
                    AND pr.expires_at > NOW()
                    AND u.active = 1
                  ORDER BY pr.created_at DESC
                  LIMIT 1";

    $findStmt = $db->prepare($findQuery);
    $findStmt->bindParam(':token_hash', $tokenHash);
    $findStmt->execute();

    if ($findStmt->rowCount() === 0) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "Invalid or expired reset token"
        ]);
        exit();
    }

    $resetRecord = $findStmt->fetch(PDO::FETCH_ASSOC);
    $passwordHash = password_hash($password, PASSWORD_BCRYPT);

    $db->beginTransaction();

    $updateUser = $db->prepare("UPDATE users SET password = :password WHERE id = :user_id");
    $updateUser->bindParam(':password', $passwordHash);
    $updateUser->bindParam(':user_id', $resetRecord['user_id']);
    $updateUser->execute();

    $markTokenUsed = $db->prepare("UPDATE password_resets SET used_at = NOW() WHERE id = :reset_id");
    $markTokenUsed->bindParam(':reset_id', $resetRecord['reset_id']);
    $markTokenUsed->execute();

    $invalidateOthers = $db->prepare("UPDATE password_resets SET used_at = NOW() WHERE user_id = :user_id AND used_at IS NULL");
    $invalidateOthers->bindParam(':user_id', $resetRecord['user_id']);
    $invalidateOthers->execute();

    $db->commit();

    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => "Password reset successful. You can now login with your new password."
    ]);
} catch (Exception $e) {
    if ($db->inTransaction()) {
        $db->rollBack();
    }

    error_log('Reset password error: ' . $e->getMessage());

    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Unable to reset password at the moment"
    ]);
}
?>