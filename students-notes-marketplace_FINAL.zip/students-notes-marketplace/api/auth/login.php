<?php
/**
 * User Login API Endpoint
 * POST: api/auth/login.php
 */

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

include_once '../config/database.php';
include_once '../models/User.php';
include_once '../config/email.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Get posted data
$data = json_decode(file_get_contents("php://input"));

// Validate required fields
if(empty($data->email) || empty($data->password)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Email and password are required"
    ]);
    exit();
}

// Set user properties
$user->email = $data->email;
$user->password = $data->password;

// Attempt login
if($user->login()) {
    // Check if email verification is required
    if(EmailConfig::$require_verification && !$user->isEmailVerified()) {
        http_response_code(403);
        echo json_encode([
            "success" => false,
            "message" => "Please verify your email address before logging in",
            "email_verified" => false,
            "email" => $user->email
        ]);
        exit();
    }
    
    // Create session
    $_SESSION['user_id'] = $user->id;
    $_SESSION['username'] = $user->username;
    $_SESSION['role'] = $user->role ?? 'user';
    
    // Generate session token (for stateless authentication)
    $session_token = bin2hex(random_bytes(32));
    $_SESSION['session_token'] = $session_token;
    
    http_response_code(200);
    echo json_encode([
        "success" => true,
        "message" => "Login successful",
        "user" => [
            "id" => $user->id,
            "username" => $user->username,
            "email" => $user->email,
            "avatar" => $user->avatar,
            "bio" => $user->bio,
            "university" => $user->university,
            "year" => $user->year,
            "subject" => $user->subject,
            "notes_uploaded" => $user->notes_uploaded,
            "notes_purchased" => $user->notes_purchased,
            "earnings" => $user->earnings,
            "join_date" => $user->join_date,
            "role" => $user->role ?? 'user'
        ],
        "session_token" => $session_token
    ]);
} else {
    http_response_code(401);
    echo json_encode([
        "success" => false,
        "message" => "Invalid email or password"
    ]);
}
?>
